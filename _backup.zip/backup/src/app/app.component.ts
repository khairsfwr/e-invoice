import { Component } from '@angular/core';
import { setTheme } from 'ngx-bootstrap/utils';
import {ModalId,ModalType} from './_components/modal/modal.component';
import {StorageService} from './_services/storage.service';
import * as bootstrap from 'bootstrap';
import {AccountService} from './_services';
import {Subscription} from 'rxjs';
import {Router} from '@angular/router';
import {UrlService} from './_services/url.service';
import {slideInAnimation} from './animation';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [slideInAnimation]
})
export class AppComponent {
  public title = 'E-Invoice System';
  public modal = { simple:{ id: ModalId.Simple, type: ModalType.Static }, developer:{ id: ModalId.Developer, type: ModalType.Static }, supplier: { id: ModalId.Supplier, type: ModalType.Static} }

  public isLogin: boolean = false;
  destroy!:Subscription;
  url!:string;

  constructor(protected storage:StorageService, protected auth:AccountService,protected router:Router,private _url:UrlService) {
    setTheme('bs5');
  }

  ngOnInit(){
    this.storage.config();
    this.storage.setStorageType(sessionStorage);
    this.configDataTable();
    this._url.previousUrl$.subscribe(x=>{
      // if(!this.isLogin && x.includes('new-user')) this.router.navigate(['/security/sign_in'])
      this.url  = x;
    });
    this.destroy = this.auth.account.subscribe(x=>{
      if(this.url.includes('new-user') && JSON.stringify(x) === '{}' ) return this.router.navigate(['/security/sign_in'])
      return this.isLogin = x && x.isPasswordChanged === 1 ? true: false;
    });

  }

  configDataTable(){
  }

  ngOnDestroy() {
    this.destroy.unsubscribe();
  }



  /*
  References Angular Life Cycle
   ngOnInit(){
     console.log("ngOnInit");
   }
   ngOnChanges() {
     console.log("ngOnChanges");
   }
   ngDoCheck() {
     console.log("ngDoCheck");
   }
   ngAfterContentInit() {
     console.log("ngAfterContentInit");
   }
   ngAfterContentChecked() {
     console.log("ngAfterContentChecked");
   }
   ngAfterViewInit() {
     console.log("ngAfterViewInit");
   }
   ngAfterViewChecked() {
     console.log("ngAfterViewChecked");
   }
   ngOnDestroy() {
     console.log("ngOnDestroy");
   }
   */

}
