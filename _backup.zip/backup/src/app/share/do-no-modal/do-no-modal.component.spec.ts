import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoNoModalComponent } from './do-no-modal.component';

describe('DoNoModalComponent', () => {
  let component: DoNoModalComponent;
  let fixture: ComponentFixture<DoNoModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DoNoModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DoNoModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
