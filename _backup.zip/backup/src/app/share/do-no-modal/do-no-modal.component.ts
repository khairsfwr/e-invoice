import {Component,OnInit,TemplateRef,ChangeDetectorRef} from '@angular/core';
import {InvoiceNewComponent} from '@app/module/invoice/page/invoice-new/invoice-new.component';
import {invoiceService} from '@app/_services/invoice-service';
import {FormBuilder} from '@angular/forms';
import {ToastrService} from 'ngx-toastr';
import {NgxSpinnerService} from 'ngx-spinner';
import {Router} from '@angular/router';
import {StorageService,AlertService} from '@app/_services';
import Swal from 'sweetalert2';
import * as bootstrap from 'bootstrap';
import {EKey} from '@app/_enum/storage-key';
import {UrlService} from '@app/_services/url.service';

@Component({
  selector: 'do-no-modal',
  templateUrl: './do-no-modal.component.html',
  styleUrls: ['./do-no-modal.component.scss']
})
export class DoNoModalComponent extends InvoiceNewComponent {

  doListModal: any[]=[]
  cancelChange!: any[];

  constructor(public invoice: invoiceService,public fb: FormBuilder,public toastr: ToastrService,
    public spinner: NgxSpinnerService,public router: Router,public storage: StorageService,
    public cd: ChangeDetectorRef,public url:UrlService, private alertService: AlertService) {
    super(invoice,fb,toastr,spinner,router,storage,cd,url);

    this.invoice.doNoList.subscribe(item => {
      this.cancelChange=[]; this.doListModal=[];
      this.cancelChange=item.map(a => {return {...a}}) //shalow clone
      this.doListModal=item.map(a => {return {...a}})
    });
  }

  async onSelectedCheckbox(item: any,event: any,index: any) {
    this.doValidationRequest=[];
    this.selectedDoList=[];
    if(event.target.checked) {
      if(item.doNo==='') {
        await Swal.fire({icon: 'error',text: 'Please provide DO No before selecting',confirmButtonText: 'OK'}).then(() => {event.target.checked=false; item.checked=false})
      } else {
        this.doValidationRequest.push({"doNumber": item.doNo,"supplierCode": sessionStorage.getItem(EKey.loginUser)})
        await this.validateSelectedDO(this.doValidationRequest,item,event,index);
      }
    }
    for(let i=0;i<this.doListModal.length;i++) {
      if(this.doListModal[i].checked) {
        this.doListModal[i].doListModal_index = i;
        this.selectedDoList.push({...this.doListModal[i]});
      }
    }
    this.saveButtonOfDO=(this.selectedDoList.length>0)? false:true;
    console.log('selected do no list::::::',this.selectedDoList);
  }

  cancel() {
    this.invoice.setDoList=[...this.cancelChange];
  }

  addNewRow() {
    this.doListModal.push({"doNo": '',"dosTrnDoHdrIid": '',checked: false,disabled: false});
  }

  save() {
    console.log('do modal list: ',this.doListModal);
    let value=this.prepareDoNoValue();
    this.invoice.setDoList=[...this.doListModal];
    this.invoice.setSelectedDoList={forField: value, forSend:this.selectedDoList };
  }

  prepareDoNoValue() {
    let doNoList=[];
    for(let i=0;i<this.selectedDoList.length;i++) {
      doNoList.push(this.selectedDoList[i].doNo);
    }
    return doNoList.join();
  }

  valueChangeEvent(item: {checked: any; doNo: any,disabled_check: boolean},i: number) {
    item.disabled_check=false;
    if(this.doListModal.map(x => x.doNo).sort().filter(x => x===item.doNo).length>1) { //duplicate do no
      item.disabled_check=true;
      item.checked=false;
      return this.alertService.error('Do No Duplicate!!!',{id: "do-no-modal",autoClose: true});
    }
  }
  removeCheck(item: {checked: any; doNo: any,disabled_check: boolean},i: number){
    if(item.checked) { //remove selected do no
      item.checked=false;
      this.selectedDoList = this.selectedDoList.filter(x=>x.doListModal_index !== i)
      return;
    }
  }
}
