import { NgModule } from '@angular/core';
import {DropdownComponent} from '@app/_components/dropdown/dropdown.component';
import {CommonModule, DatePipe} from '@angular/common';
import {ButtonsModule} from 'ngx-bootstrap/buttons';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatTooltipModule} from '@angular/material/tooltip';
import {SupplierDialogComponent} from './supplier-dialog/supplier-dialog.component';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { NgxPaginationModule } from 'ngx-pagination';
import {MatDialogModule} from '@angular/material/dialog';
import {ToastrModule} from 'ngx-toastr';
import {LoaderCustome} from '@app/_components/loader.component';
import { NgSelectModule } from '@ng-select/ng-select'
// import { NgSelectModule } from '@ng-select/ng-select';
// import { ChatComponent } from './chat/chat.component';
// import { DataTablesModule } from "angular-datatables";
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DoNoModalComponent } from './do-no-modal/do-no-modal.component';
import {AlertComponent} from '@app/_components';

export const MY_DATE_FORMATS = {
  parse: {
    dateInput: 'DD-MM-YYYY'
  },
  display: {
    dateInput: 'DD-MM-YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};

@NgModule({
  declarations: [
    DropdownComponent,
    SupplierDialogComponent,
    LoaderCustome,
    DoNoModalComponent,
    AlertComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule, //form
    FormsModule, //ngmodel etc
    ButtonsModule.forRoot(),
    MatTooltipModule,
    MatDialogModule, 
    NgxPaginationModule,
    ToastrModule.forRoot({
      positionClass :'toast-bottom-right',
      preventDuplicates: true,
    }),
    NgSelectModule
    // DataTablesModule
  ],
  exports: [
    //share module to other module
    NgSelectModule, //ngselect
    MatDatepickerModule,// matdatepicker
    
    DropdownComponent,
    SupplierDialogComponent,
    LoaderCustome,
    DoNoModalComponent,
    AlertComponent,
    NgxPaginationModule,

  ],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]},
    {provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS},
    DatePipe
  ],
})
export class ShareModule { }
