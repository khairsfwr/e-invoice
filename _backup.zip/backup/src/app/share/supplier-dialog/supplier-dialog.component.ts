import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { ToastrService } from 'ngx-toastr';

import { CommonService, setupService } from '@app/_services';
import {ModalService} from '@app/_services/modal.service';

@Component({
  selector: 'supplier-modal',
  templateUrl: './supplier-dialog.component.html',
  styleUrls: ['./supplier-dialog.component.css']
})
export class SupplierDialogComponent implements OnInit {

  // @Input() watchList:number
  @Output() data = new EventEmitter();
  @Input() allSupplierList:any[] = []
  @Input() copyOfAllSupplierList:any[] = []
  @Input() q!:number
  sample!:boolean;
  match:any = 'contains';
  supplierCode:any;
  supplierName:any;
  supplierWatchListCheckbox:boolean = false;
  selectedSuppliers: any[] = [];
  checkList:any[] = [];
  saveButton: boolean = true;
  // q:number;
  // allSupplierList: any[] = [];
  // copyOfAllSupplierList: any[] = [];
  allSuppliersApiCalled:boolean = false;
  allSupplierListStorage:any[] = [];
  supplierWatchList:any[]=[];
  characters:any[]=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
  getSupplierObject() {
      return {
        "addressBooksCode": '',
        "companyName": ''
      }
  }
  constructor(private toastr: ToastrService, private common: CommonService, private setup: setupService, private modalService: ModalService) {  }

  ngOnInit() { 
    this.common.supplier$.subscribe(x=>{
      if(!x)return;
      this.copyOfAllSupplierList = x;
      console.log(x);
      
      this.searchSuppliers();
    });
    
  }

  resetSupplierSearchValues(){
    // this.match = null;
    this.supplierCode = null;
    this.supplierName = null;
  }

  onSelectedCheckbox(item:any, event:any, index:any){
    console.log('selected supplier object:::::', item);
    console.log('selected checkbox event:::::', event);
    let obj = this.getSupplierObject();
    obj["addressBooksCode"] = item.addressBooksCode;
    obj["companyName"] = item.companyName;
    if(event.target.checked){
        console.log('entered into checked condition')
        this.selectedSuppliers.push(item);
        this.checkList[item.addressBooksCode] = true;
    }else{
        console.log('entered into un checked condition')
        this.checkList[item.addressBooksCode] = false;
        for(let i=0; i<this.selectedSuppliers.length; i++){
        if(this.selectedSuppliers[i].addressBooksCode === item.addressBooksCode)
            this.selectedSuppliers.splice(i--, 1);
        }
    }
    this.saveButton = (this.selectedSuppliers.length > 0) ? false : true;    
    console.log('supplier list::::::', this.selectedSuppliers);
}

  resetSelectedSuppliers(){
      this.q = 1;
      this.selectedSuppliers = [];
      this.checkList = [];
      this.saveButton = true;
      // this.allSupplierList = Array.from(this.copyOfAllSupplierList);
      this.modalService.setSupplierList([]);
  }

  filterStartsWith(letter:any){
      console.log('enetered into filterStartsWith method', letter)
      this.q = 1;
      this.allSupplierList = Array.from(this.copyOfAllSupplierList);
      this.allSupplierList = this.allSupplierList.filter(each => String(each.companyName).startsWith(letter))
      console.log('supplier list after filtered::::', this.allSupplierList)
  }

  searchSuppliers(){
    this.q = 1;
    if(this.match === null || this.match === '' || this.match === undefined){
      this.toastr.error('Please select match to search supplier')
    }else if(!this.supplierCode && !this.supplierName){
      this.allSupplierList = Array.from(this.copyOfAllSupplierList);
    }else if(this.supplierCode && this.supplierName){
      this.toastr.error('Please search with any one input')
    }else if(this.supplierCode && !this.supplierName){
      this.allSupplierList = Array.from(this.copyOfAllSupplierList);
      this.allSupplierList = (this.match === 'startsWith') ? this.allSupplierList.filter(each => String(each.addressBooksCode).startsWith(this.supplierCode)) :
                                    this.allSupplierList.filter(each => String(each.addressBooksCode).includes(this.supplierCode))
    }else if(!this.supplierCode && this.supplierName){
      this.allSupplierList = Array.from(this.copyOfAllSupplierList);
      this.allSupplierList = (this.match === 'startsWith') ? this.allSupplierList.filter(each => String(each.companyName).startsWith(this.supplierName)) :
                                    this.allSupplierList.filter(each => String(each.companyName).includes(this.supplierName))
    }
  }

  async saveSelectedSuppliers(){
    this.supplierWatchList=[];
    let count:number = 0;
    const response:any = await this.setup.getWatchlistCount();
    if(response.data){
      count = response.data.maxWatchListConfig;
    }
    for(let i=0; i<this.selectedSuppliers.length; i++){      
      if(this.supplierWatchList.length < count){
        this.supplierWatchList.push(this.selectedSuppliers[i]);
      }
    }
    // this.data.emit(this.supplierWatchList);
    this.modalService.setSupplierList(this.supplierWatchList);
  }

}
