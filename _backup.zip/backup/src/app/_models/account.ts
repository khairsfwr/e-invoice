﻿import { Role } from './role';


export class Account {
    id!: string;
    title!: string;
    firstName!: string;
    lastName!: string;
    role!: Role;
    projectCode!: string;

    // from api
    email!: string;
    empId!:string;
    isPasswordChanged!: number;
    jwtToken!: string;
    name!: string;
    passowrdExpiresOn?: any;
    supplierInfo?:any;
    userRole!: string;

    refresh_token?:string;
    

    constructor() {}
}

export interface IAccount {
    id: string;
    title: string;
    // firstName: string;
    // lastName: string;
    name: string;
    email: string;
    role: Role;
    jwtToken?: string;
    projectCode: string;
}

// ! definitely will be assign value
// ? may have undefine value