export enum Role {
    User = 'User',
    Admin = 'Admin'
}

/**Role of login user in database */
export enum ERole {
    "InvApOfficer"                   = "inv_ap_officer",
    "InvProcurementUser"             ="inv_procurement_user",
    // "InvSupplier"                 ="inv_supplier", not in use
    "InvEndUser"                     ="inv_end_user",
    "InvQaqcUser"                    ="inv_qaqc_user",
    "InvWarehouseUser"               ="inv_warehouse_user",
    "InvApSupervisor"                ="inv_ap_supervisor",
    "Supplier"                       ="SUPPLIER", // non scm
    "InvFinanceOwner"                ="inv_finance_owner",
  }