export enum StatusType {
  Draft="Draft",
  Approved="Approved"
}