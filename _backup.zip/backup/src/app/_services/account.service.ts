﻿import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient,HttpHeaders,HttpRequest,HttpEvent} from '@angular/common/http';
import {BehaviorSubject,Observable,of, concat} from 'rxjs';
import {map,finalize,first} from 'rxjs/operators';
import {environment} from '@environments/environment';
import {Account} from '@app/_models';
import {StorageService} from './storage.service';
import {EKey} from '@app/_enum/storage-key';
import {CKey} from '@app/_const/general';
import {LoggerService} from './logger.service';
import {IJwt,EMIME} from '@app/_enum/service';
import {apiService} from './api.service';

const baseUrl=`${environment.baseUrl}`;

@Injectable({providedIn: 'root'})
export class AccountService {
    private accountSubject: BehaviorSubject<Account>;
    public account: Observable<Account>;

    constructor(
        private router: Router,
        private http: HttpClient,
        private storage: StorageService,
        private msg: LoggerService,
        private api:apiService
    ) {
        this.accountSubject=new BehaviorSubject<Account>(new Account());
        this.account=this.accountSubject.asObservable();
    }

    public get sessionId(): string {
        return this.storage.getItem(EKey.sessionId);
    }

    getAccountObservable(){
    }

    public get accountValue(): Account | null {
        if(JSON.stringify(this.accountSubject.value) === '{}') return null;
        return this.accountSubject.value;
    }

    public get projectCode(): string |  null {
        return typeof this.accountValue===null? null:(this.accountValue as Account).projectCode;
    }

    public set setAccountProjectCode(projectCode: string) {
        let account=this.accountValue;
        if(account) {
            account.projectCode=projectCode;
            this.accountSubject.next(account);
        }
    }

    async getJWTAsyc(userName: string,password: string){
        const options={
            headers: {
                'Content-Type': 'application/json',
                'Authorization': CKey.AuthorizationBasic,
            }
        }
        const url=`${baseUrl}/oauth/token?username=${userName}&password=${password}&grant_type=password`;
        const body={};
        const promise:any = await this.http.post(url, body, options).toPromise().then((jwt)=>{
            this.msg.log(`===== Response api ${url} =====`,jwt);
            this.storage.setItem(EKey.jwt,JSON.stringify(jwt));
            return jwt;
        }).catch((ex: any)=> {});
        return promise;
    }

    getJWT(userName: string,password: string) {
        const options={
            headers: {
                'Content-Type': 'application/json',
                'Authorization': CKey.AuthorizationBasic,
            }
        }
        const url=`${baseUrl}/oauth/token?username=${userName}&password=${password}&grant_type=password`;
        const body={};
        return this.http.post<any>(url,body,options)
            .pipe(map(jwt => {
                this.msg.log(`===== Response api ${url} =====`,jwt);
                this.storage.setItem(EKey.jwt,JSON.stringify(jwt));
                return jwt;
            }));
    }

    async loginAsyc(userName: string){
        let access_token: string=this.storage.getItem(EKey.jwt)===null? '':JSON.parse(this.storage.getItem(EKey.jwt)).access_token;
        if(!access_token) return of(false);
        const options={
            headers: {
                'Content-Type': 'application/json',
                "Authorization": "Bearer "+access_token
            }
        }
        const url=`${baseUrl}/login`;
        const body={"email": userName}
        const promise:any = await this.http.post(url, body, options).toPromise().then((account:any)=>{
            this.msg.log(`===== Response api ${url} =====`,account);
            this.accountSubject.next({...account.data,jwtToken: JSON.parse(this.storage.getItem(EKey.jwt)).access_token});
            this.startRefreshTokenTimer();
            return account;
        }).catch((ex: any)=> {});
        return promise;
    }

    login(userName: string) {
        let access_token: string=this.storage.getItem(EKey.jwt)===null? '':JSON.parse(this.storage.getItem(EKey.jwt)).access_token;
        if(!access_token) return of(false);
        const options={
            headers: {
                'Content-Type': 'application/json',
                "Authorization": "Bearer "+access_token
            }
        }
        const url=`${baseUrl}/login`;
        const body={"email": userName}
        return this.http.post<any>(url,body,options)
            .pipe(map(account => {
                this.msg.log(`===== Response api ${url} =====`,account);
                this.accountSubject.next({...account.data,jwtToken: JSON.parse(this.storage.getItem(EKey.jwt)).access_token});
                this.startRefreshTokenTimer();
                return account;
            }));
    }

    logout() {
        let access_token: string=this.storage.getItem(EKey.jwt)===null? '':JSON.parse(this.storage.getItem(EKey.jwt)).access_token;
        if(!access_token) return of(false);
        const options: any={
            headers: {
                'Content-Type': EMIME.application_json,
                'Authorization': 'Bearer '+access_token,
                'Accept': EMIME.text_plain
            },
            withCredentials: false,
            responseType: EMIME.text_plain,
            reportProgress: false,
        }
        const url=`${baseUrl}/user/logout`;
        const body={}
        return this.http.get<any>(url,options).subscribe({
            next: (resp: HttpEvent<string>) => {
                this.msg.log(`===== Response api ${url} =====`,resp);
                localStorage.removeItem(EKey.userKey);
                this.stopRefreshTokenTimer();
                this.accountSubject.next(new Account());
                this.router.navigate(['/security/sign_in']);
            },
            error: () => {
                this.storage.clear();
            },
            complete: () => {}
        });
    }

    async refreshTokenAsync(){
        this.msg.log('account.service.ts refreshToken()');
        const options:any={
            headers: {
                'Content-Type': 'application/json',
                'Authorization': CKey.AuthorizationBasic,
            },
            withCredentials: false,
            responseType: EMIME.application_json,
            reportProgress: false,
        }
        const url=`${baseUrl}/oauth/token?grant_type=refresh_token&refresh_token=${(JSON.parse(this.storage.getItem(EKey.jwt)) as IJwt).refresh_token}`;
        const body={};
        const promise:any = await this.http.post(url, body, options).toPromise().then((jwt:any)=>{
            this.msg.log("Refresh token before: ", JSON.parse(this.storage.getItem(EKey.jwt)).refresh_token.split(".")[2])
            this.storage.setItem(EKey.jwt, jwt);
            this.msg.log("Refresh token after: ", JSON.parse(jwt).refresh_token.split(".")[2]);
            this.msg.log("If the jwt same??", JSON.parse(jwt) === JSON.parse(this.storage.getItem(EKey.jwt)));
        }).catch((ex: any)=> {});
        return promise;
    }

    refreshToken() {
        this.msg.log('account.service.ts refreshToken()');
        const options:any={
            headers: {
                'Content-Type': 'application/json',
                'Authorization': CKey.AuthorizationBasic,
            },
            withCredentials: false,
            responseType: EMIME.application_json,
            reportProgress: false,
        }
        const url=`${baseUrl}/oauth/token?grant_type=refresh_token&refresh_token=${(JSON.parse(this.storage.getItem(EKey.jwt)) as IJwt).refresh_token}`;
        const body={};
        
        return this.http.post<any>(url,body,options)
            .pipe(map((jwt:any) => {
                this.msg.log("Refresh token before: ", JSON.parse(this.storage.getItem(EKey.jwt)).refresh_token.split(".")[2])
                // this.storage.setItem(EKey.jwt,JSON.stringify(jwt));
                this.storage.setItem(EKey.jwt,jwt);
                this.msg.log("Refresh token after: ", jwt.refresh_token.split(".")[2]);
                this.msg.log("If the jwt same??", jwt === JSON.parse(this.storage.getItem(EKey.jwt)));
            }));
    }

    async refreshTokenAndSetAccountAsync() {
        await this.refreshTokenAsync();
        await this.loginAsyc(this.storage.getItem(EKey.loginUser));
        return;
    }

    refreshTokenAndSetAccount() {
        return new Promise((resolve,reject) => {
            this.refreshToken().subscribe(()=>{
                this.login(this.storage.getItem(EKey.loginUser)).subscribe(()=>{
                    resolve('done')
                })
            },()=>resolve('error'));
        });
    }

    

    async saveNewPassword(body: {"username": any; "password": any;}){
        let url = baseUrl + '/change-password';
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=> 
        {
            // this.spinner.hide();
        });
        return promise;
    }

    async forgotPassword(body: any){
        let url = baseUrl + '/forgot-password';
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=> {
            // this.spinner.hide();
        });
        return promise;
    }

    getProjectCodes() {
        return this.http.get<{data: any[]}>(`${baseUrl}/list/project-codes`);
    }

    getProjectCodesAsyncAwait() {
        return new Promise((resolve,reject) => {
            this.http.get<{data: any[]}>(`${baseUrl}/list/project-codes`).subscribe(data => {
                resolve(data);
            },e => {reject(e)});
        });
    }


    // helper methods

    private refreshTokenTimeout: string|number|NodeJS.Timeout|undefined;

    private startRefreshTokenTimer() {
        if(!this.accountValue) return;
        // parse json object from base64 encoded jwt token
        const jwtToken=JSON.parse(atob(this.accountValue.jwtToken!.split('.')[1]));

        // set a timeout to refresh the token a minute before it expires
        const expires=new Date(jwtToken.exp*1000);
        const timeout=expires.getTime()-Date.now()-(60*1000);
        this.refreshTokenTimeout=setTimeout(async () => await this.refreshTokenAsync(),timeout);
    }

    private stopRefreshTokenTimer() {
        clearTimeout(this.refreshTokenTimeout);
    }
}