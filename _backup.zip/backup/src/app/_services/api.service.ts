import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import {StorageService} from './storage.service';
import {EKey} from '@app/_enum/storage-key';

@Injectable({
    providedIn: 'root'
})
export class apiService {

    constructor(private http: HttpClient, private storage:StorageService) { }

    

    authenticate(url:any, body:any, headers:any): Observable<any> | any{
        try {
            return this.http.post(url, body, {headers});
        } catch (error) {
            console.log('error in api service: ', error);
            return error;
        }
        
    }

    commonPostApi(url:any, body:any): Observable<any> | any {
        const headers = {
            "content-type": "application/json",
            "Authorization": "Bearer " + this.storage.getItem(EKey.jwt)            
        };

        try {
            return this.http.post(url, body, {headers});
        } catch (error) {
            console.log('Error in commonPostApi: ', error);
            return error;
        }
        
    }

    commonUploadDocuments(url:any, files:any, namesArray:any, descriptionArray:any): Observable<any> {
        const formData: FormData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append('fileUpload', files[i])
        }
        for (let i = 0; i < namesArray.length; i++) {
            formData.append('attachmentName', namesArray[i])
        }
        for (let i = 0; i < descriptionArray.length; i++) {
            formData.append('fileDescription', descriptionArray[i])
        }
        let params = new HttpParams();
        let headers = new HttpHeaders({'Authorization': 'Bearer ' +this.storage.getItem(EKey.jwt)});
        headers.append('Content-Type', 'multipart/form-data');
        // headers.append();
        const options = { headers: headers, params: params, reportProgress: true };
        return this.http.post(url, formData, options);
    }
}