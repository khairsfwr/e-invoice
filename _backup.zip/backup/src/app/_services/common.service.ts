import {HttpClient,HttpHeaders} from "@angular/common/http";
import {HostListener,Injectable} from "@angular/core";
import {Router} from "@angular/router";
import {NgxSpinnerService} from "ngx-spinner";
import {ToastrService} from "ngx-toastr";
import {environment} from "src/environments/environment";
import {apiService} from './api.service';
import {BehaviorSubject,Observable} from 'rxjs';


@Injectable({
    providedIn: "root"
})
export class CommonService {
    baseUrl=environment.baseUrl+'/';
    user=sessionStorage.getItem('loginUser');
    supplierList: any[]=[];
    private httpOptions={
        headers: new HttpHeaders({
            "content-type": "application/json"
        })
    };

    private supplier$Subject: BehaviorSubject<any>;
    public supplier$: Observable<any>;

    constructor(private http: HttpClient,private api: apiService,private spinner: NgxSpinnerService,private router: Router) {
        this.supplier$Subject=new BehaviorSubject<any>(null);
        this.supplier$=this.supplier$Subject.asObservable();
    }

    public getSupplierSubjectValue(): any {
        return this.supplier$Subject.value;
    }
    async getGstCode(code: any) {
        let url=this.baseUrl+'po/gst-check';
        let body={"companyCode": code};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async getCompanyName(code: any) {
        let body={"companyCode": code}
        let url=this.baseUrl+'po/get-companyname';
        let promise: any=await this.api.commonPostApi(url,body).toPromise().catch(() => {this.spinner.hide();});
        return promise;
    }
    async getSupportingDocumentList(id: any,module: any) {
        let body={"internalId": id,"module": module}
        let url=this.baseUrl+'docs/all';
        let promise: any=await this.api.commonPostApi(url,body).toPromise().catch(() => {this.spinner.hide();});
        return promise;
    }
    async deleteSupportingDocuments(fileId: any) {
        let url=this.baseUrl+'file/delete?fileId='+fileId+'&user='+this.user;
        const promise: any=await this.api.commonPostApi(url,{}).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }
    async deleteMultipleSupportingDocuments(fileIds: any[]) {
        if(fileIds.length===0) return;
        let path='';
        fileIds.forEach(fileId => path=path===''? path+`fileId=${fileId}`:path+`&fileId=${fileId}`);
        let url=this.baseUrl+'file/delete/multiple?'+path+`&user=${this.user}`;
        const promise: any=await this.api.commonPostApi(url,{}).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }
    async getEvents(body: any) {
        let url=this.baseUrl+'events/fetch';
        let promise: any=await this.api.commonPostApi(url,body).toPromise().catch(() => {this.spinner.hide();});
        return promise;
    }
    async manuallyMatched(id: any,reason: any,module: any) {
        let url=this.baseUrl+'match/manual';
        let body={"internalId": id,"reason": reason,"user": this.user,"module": module};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async requestToVoid(id: any,reason: any,module: any) {
        let url=this.baseUrl+'request/void';
        let body={"internalId": id,"reason": reason,"user": this.user,"module": module};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async voidFinance(id: any,module: any) {
        let url=this.baseUrl+'void/finance';
        let body={"internalId": id,"user": this.user,"module": module};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async getSupplierWatchList() {
        let url=this.baseUrl+'user/watchlist';
        let body={"empId": sessionStorage.getItem('employeeId')}
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async getAllSuppliers(body: {"search": string; "supplierCode": string; "supplierName": string; "empId": string|null; "watchList": number; "role": string|null;}) {
        let url=this.baseUrl+'supplier/search';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async accept(id: any,gst: any,module: any,date: any,user: any) {
        let url=this.baseUrl+'button/accept';
        let body={"internalId": id,"user": user,"module": module,"gst": gst,"glDate": date};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async reject(id: any,reason: any,module: any,user: any) {
        let url=this.baseUrl+'button/reject';
        let body={"internalId": id,"reason": reason,"user": user,"module": module};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async getStatusDropdownValues() {
        let url=this.baseUrl+'invoice/status/dropdown';
        let body={"userRole": sessionStorage.getItem('userRole')};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async getReport(body: any,endPointUrl: string) {
        let url=this.baseUrl+endPointUrl;
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    // Home screen service
    async getHomeScreenReport(suppliers: any[],submissionYear: any,type: any) {
        let url=this.baseUrl+'report/home';
        let body={"suppliers": suppliers,"year": submissionYear,"poType": type};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async getAllErrorEvents(body: any) {
        let url=this.baseUrl+'error/event/all';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }
    async receiveDefaultSupplierList(body: {"search": string; "supplierCode": string; "supplierName": string; "empId": string|null; "watchList": number; "role": string|null;}) {
        this.supplierList=[];
        let url=this.baseUrl+'supplier/search';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        this.supplierList=promise.data as any;
        console.log('newwwwwwwwwwww: ',this.supplierList)

        this.supplier$Subject.next(promise.data as any);

        return promise;
    }
    async getEmailNotifications(body: any) {
        let url=this.baseUrl+'button/email';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }
    async getVoidButtonStatus(empId: any,internalId: any) {
        let url=this.baseUrl+'procurement/void';
        let body={"empId": empId,"internalId": internalId}
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }

}