import { HttpErrorResponse, HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Observable, throwError } from 'rxjs';
import { catchError, filter, take, switchMap, finalize, map } from "rxjs/operators";
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Injectable({
  providedIn: 'root'
})
export class AuthInterceptorService implements HttpInterceptor {

  constructor(private toaster: ToastrService, private spinner: NgxSpinnerService, private router: Router) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
    const headers = {
      'Content-Type': 'application/json', 
    };

    // req = req.clone({
    //   setHeaders: headers
    // });

    // console.log('entered into auth interceptor');
    return next.handle(req).pipe(catchError(x=>this.handleCatchError(x))) as Observable<HttpEvent<any>>;
    //return response;

  }

  handleCatchError(error: HttpErrorResponse) {
    this.spinner.hide();   
    if (error.status == 401) {
      Swal.fire({ icon: 'error', title: 'Expired!', text: 'Page expired, please login again'}).then(result=>{sessionStorage.clear(); this.router.navigateByUrl('')});
      return throwError(error);
    }else if(error.status == 400){
      if(typeof error.error.error === 'string' && error.error.error === 'invalid_grant'){
        Swal.fire({ icon: 'error', title: 'Failed', text: "Wrong username or password" });
        // return throwError(error);
      }else{
        Swal.fire({ icon: 'error', title: 'Error', text: error.error.message })
      }
    }else if(error.status != 200){
    }
  }

  errorHandling(error: any) {
    let msg = '';
    switch (error.status) {
      case 400: msg = '400 – Bad Request'; break;
      case 401: msg = '401 – Authorization Required'; break;
      case 403: msg = '403 – Forbidden'; break;
      case 404: msg = '404 – Not Found'; break;
      case 408: msg = '408 – Request Time-Out'; break;
      case 410: msg = '410 – Gone'; break;
      case 500: msg = '500 – Internal Server Error'; break;
      case 502: msg = '502 – Bad Gateway'; break;
      case 503: msg = '503 – Service Temporarily Unavailable'; break;
      case 504: msg = '504 – Gateway Time-Out'; break;
      default: msg = 'Unknown error'; break;
    }
    if (error.status != 401 && error.status != 400)
      this.toaster.error(error.error && typeof error.error === 'string' && error.error.includes('<!doctype html>') ? 'Server Down'
        : error.error ? error.error.message && !error.error.message.includes('http') ? error.error.message
          : error.message && !error.message.includes('http') ? error.message
            : error.error && typeof error.error === 'string' && !error.error.includes('http') ? error.error
              : error.error.error
          : 'Server Error', msg);


  }



}
