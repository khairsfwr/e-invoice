import {Injectable} from '@angular/core';
import {Observable,Subject, BehaviorSubject} from 'rxjs';
import {filter} from 'rxjs/operators';

import {Modal, ModalSize, ModalId, ModalType} from '@app/_components/modal/modal.component';

@Injectable({providedIn: 'root'})
export class ModalService {
  private subject=new Subject<Modal>();
  private defaultId=ModalId.Default;

  // supplier selection 
  private supplierSubject: BehaviorSubject<any>;
  public supplier: Observable<any>;

  constructor(){
    this.supplierSubject=new BehaviorSubject<any>(null);
    this.supplier=this.supplierSubject.asObservable();
  }

  public setSupplierList(supplierList:any[]){
    this.supplierSubject.next(supplierList);
  }
  public getSupplierList(){
    return this.supplierSubject.value;
  }

  // enable subscribing to alerts observable
  onModal(id=this.defaultId): Observable<Modal> {
    return this.subject.asObservable().pipe(filter(x => {
      return x&&x.id===id
    }));
  }

  // convenience methods
  simpleModal(data: {header: string, body: string}, options?: any): void {
    this.modal(new Modal({...options, id: ModalId.Simple, size: ModalSize.Medium, data}));
  }

  developerModal(options?: any): void {
    this.modal(new Modal({...options, id: ModalId.Developer, size: ModalSize.Small}));
  }
  // system modal
  supplierModal(data: {header: string, body: string}, options?: any): void {
    this.modal(new Modal({...options, id: ModalId.Supplier, size: ModalSize.Large, data}));
  }

  // core modal method
  modal(modal: Modal) {
    modal.id=modal.id||this.defaultId;

    this.subject.next(modal);
  }

}