import {HttpClient,HttpHeaders,HttpParams} from "@angular/common/http";
import {Injectable} from "@angular/core";
import {ToastrService} from "ngx-toastr";
import {Observable,BehaviorSubject} from "rxjs";
import {environment} from "src/environments/environment";
import {apiService} from "./api.service";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import {NgxSpinnerService} from "ngx-spinner";

@Injectable({
    providedIn: "root"
})

export class invoiceService {
    baseUrl=environment.baseUrl+"/";
    user=sessionStorage.getItem('loginUser');

    private doNoListSubject: BehaviorSubject<any[]>;
    public doNoList: Observable<any[]>;

    private selectedDoNoListSubject: BehaviorSubject<any>;
    public selectedDoNoList: Observable<any>;

    constructor(private http: HttpClient,private api: apiService,private toastr: ToastrService,private spinner: NgxSpinnerService) {
        this.doNoListSubject=new BehaviorSubject<any[]>([]);
        this.doNoList=this.doNoListSubject.asObservable();

        this.selectedDoNoListSubject=new BehaviorSubject<any>(null);
        this.selectedDoNoList=this.selectedDoNoListSubject.asObservable();
    }
 
    public set setSelectedDoList(selectedDoNoList: any) {
        this.selectedDoNoListSubject.next(selectedDoNoList);
    }

    public set setDoList(doNoList: any[]) {
        this.doNoListSubject.next(doNoList);
    }

    public get getDoListValue() {
        return this.doNoListSubject.value;
    }

    httpOptions={
        headers: new HttpHeaders({
            "content-type": "application/json"
        })
    };



    async getPoList(sCode: string,pONo?: string) {
        let body={"supplierCode": sCode,"purchaseOrderNo": pONo}
        let url=this.baseUrl+'po/get-po-details'
        let promise: any[]=await this.api.commonPostApi(url,body).toPromise().catch(() => {this.spinner.hide();})
        return promise;
    }

    async getDoList(poId: undefined) {
        let url=this.baseUrl+'do/get-do-details'
        let body={"purchaseOrderIid": poId}
        let promise: any[]=await this.api.commonPostApi(url,body).toPromise().catch(() => {this.spinner.hide();})
        return promise;
    }

    async getLocation(locationCode: any) {
        let body={"locationCode": locationCode}
        let url=this.baseUrl+'location'
        let promise: any=await this.api.commonPostApi(url,body).toPromise().catch(() => {this.spinner.hide();});
        return promise;
    }

    async getLocationCode(code: any,poNo: any) {
        let body={"supplierCode": code,"purchaseOrderNo": poNo}
        let url=this.baseUrl+'location/v2'
        let promise: any=await this.api.commonPostApi(url,body).toPromise().catch(() => {this.spinner.hide();});
        return promise;
    }

    async getDisclaimer(req: string) {
        let url=this.baseUrl+'disclaimer';
        let body={"disclaimerPage": req};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

    async invoiceNoValidation(invoiceNo: any,supplierCode: any) {
        let url=this.baseUrl+'invoice/validation';
        let body={"invoiceNo": invoiceNo,"supplierCode": supplierCode};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

    async doNoValidation(body: any[]) {
        let url=this.baseUrl+'do/validation';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

    async saveInvoiceDetails(body: any) {
        let url=this.baseUrl+'invoice/new';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {
            this.spinner.hide();
            Swal.fire({icon: 'error',text: 'Invoice Details not save successfully'})
        });
        return promise;
    }

    async getCompanyName(code: undefined) {
        let body={"companyCode": code}
        let url=this.baseUrl+'po/get-companyname';
        let promise: any=await this.api.commonPostApi(url,body).toPromise().catch(() => {this.spinner.hide();});
        return promise;
    }

    async getGstCode(code: any) {
        let url=this.baseUrl+'po/gst-check';
        let body={"companyCode": code};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

    async uploadingDocuments(files: any[]|(File|null)[],id: string,description: string,namesArray: any[],descriptionArray: any[]) {
        let url=this.baseUrl+'files/upload-multiple-files?id='+id+'&page=newinvoice&description='+description+'&path=invoice&user='+this.user;
        const promise: any=await this.api.commonUploadDocuments(url,files,namesArray,descriptionArray).toPromise().catch((ex: any) => {
            this.spinner.hide();
            Swal.fire({icon: 'error',text: 'Documents not uploaded properly'})
        });
        return promise;
    }

    async searchInvoiceList(body: any) {
        let url=this.baseUrl+'invoice/search';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

    async getGstNo(code: string) {
        let url=this.baseUrl+'gst?vendorCode='+code;
        const promise: any=await this.api.commonPostApi(url,{}).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

    async searchInvoiceDetails(body: any) {
        let url=this.baseUrl+'invoice/view';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

    downloadFiles(type: string,Iid: string,fileName: string) {
        return this.baseUrl+'download/file?id='+Iid+'&page=newinvoice&description='+type+'&fileName='+fileName;
    }

    async getEventDescriptions() {
        let url=this.baseUrl+'error/event/all';
        let body={}
        const promise: any[]=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }

    async updateEventDescription(Iid: any,desc: any,remarks: any,user: any) {
        let url=this.baseUrl+'invoice/event/update';
        let body={"invoiceIid": Iid,"eventDescription": desc,"remarks": remarks,"user": user};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }

    async invoiceAmountValidation(code: string|null,poNo: any,amount: any,netAmount: any) {
        let url=this.baseUrl+'invoice/amount/gross';
        let body={"companyCode": code,"poNo": poNo,"grossAmount": amount,"netAmount": netAmount};
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }

    async getEventAll() {
        let url=this.baseUrl+'error/event/all';
        let body={}
        const promise: any[]=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }

    async getErrorEventList() {
        let url=this.baseUrl+'error/event/search';
        let body={}
        const promise: any[]=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();})
        return promise;
    }

    //Invoice verification api methods

    async getGSTDropdown() {
        let url=this.baseUrl+'invoice/verification/gst/dropdown';
        const promise: any=await this.api.commonPostApi(url,{}).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

    async checkTolerance(body: any) {
        let url=this.baseUrl+'invoice/tolerance/check';
        const promise: any=await this.api.commonPostApi(url,body).toPromise().catch((ex: any) => {this.spinner.hide();});
        return promise;
    }

}