import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { environment } from "src/environments/environment";
import { apiService } from "./api.service";

@Injectable({
    providedIn: "root"
})
export class  setupService {
    baseUrl = environment.baseUrl + "/";
    user = sessionStorage.getItem('loginUser');
    empId = sessionStorage.getItem('employeeId');
    constructor(private http: HttpClient, private api: apiService, private toastr: ToastrService, private spinner: NgxSpinnerService){ }

    //AP Assignment services
    async getAllUsers(empId:any){
        let url = this.baseUrl + 'user/fetch';
        let body = {"empId": empId}
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{});
        return promise;
    }

    async getAllCodes(){
        let url = this.baseUrl + 'code/all';
        const promise:any = await this.api.commonPostApi(url, {}).toPromise().catch((ex: any)=>{});
        return promise;
    }

    async searchConditions(empId:any, assigned:any){
        let url = this.baseUrl + 'ap/assignment/search';
        let body = {"empId": empId, "assigned": assigned};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{});
        return promise;
    }

    async saveConditions(body:any){
        let url = this.baseUrl + 'ap/assignment/save';
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    // Error event type services

    async searchErrorEvent(events:any, distribution:any, nextEvent:any, persons:any){
        let url = this.baseUrl + 'error/event/search';
        let body = {"eventType": events, "distributionGroup": distribution, "nextEventType": nextEvent, "personIncharge": persons};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{});
        return promise;
    }

    async getProjectList(){
        let url = this.baseUrl + 'project/list';
        const promise:any = await this.api.commonPostApi(url, {}).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    async searchErrorEventConditionDropdownValues(){
        let url = this.baseUrl + 'code/error/event/condition';
        const promise:any = await this.api.commonPostApi(url, {}).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    async saveErrorEventDetails(obj:any){
        let url = this.baseUrl + 'error/event';
        const promise:any = await this.api.commonPostApi(url, obj).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    async fetchErrorEventConditions(list: any){
        let url = this.baseUrl + 'error/event/condition';
        const promise:any = await this.api.commonPostApi(url, list).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    async getErrorPdg(body: any){
        let url = this.baseUrl + 'error/event/pdg';
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    async getProjectDropdownValues(){
        let url = this.baseUrl + 'project/dropdown';
        const promise:any = await this.api.commonPostApi(url, {}).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    // Supplier watch list services
    async getSupplierWatchList(){
        let url = this.baseUrl + 'user/watchlist';
        let body = {"empId": sessionStorage.getItem('employeeId')}
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{});
        return promise;
    }

    async saveSupplierWatchList(body: any){
        let url = this.baseUrl + 'watchlist/save';
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    async getAllSuppliers(body: any){
        let url = this.baseUrl + 'supplier/search';
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

    async getWatchlistCount(){
        let url = this.baseUrl + 'watchlist/count';
        let body = {"empId": sessionStorage.getItem('employeeId')};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch((ex: any)=>{this.spinner.hide();});
        return promise;
    }

}