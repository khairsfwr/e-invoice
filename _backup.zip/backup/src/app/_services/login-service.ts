// import { HttpClient, HttpHeaders } from "@angular/common/http";
// import { Injectable } from "@angular/core";
// import { Observable, Subject } from "rxjs";
// import { environment } from "src/environments/environment";
// import { apiService } from "./api.service";
// // import { Swal } from 'sweetalert2/dist/sweetalert2.js';
// import { concatMap } from "rxjs/operators";
// // import { NgxSpinnerService } from "ngx-spinner";
// // import * as CryptoJS from 'crypto-js';
// // import * as bcrypt from 'bcryptjs';


// @Injectable({
//     providedIn: "root"
// })
// export class loginService{

//     baseUrl=environment.baseUrl;
    
//     constructor(private http: HttpClient,private api: apiService,private spinner: NgxSpinnerService) {}

//     httpOptions={headers: new HttpHeaders({"content-type": "application/json"})};

//     subject=new Subject();

//      login(userName){
//         let url = this.baseUrl + 'login';
//         let body = {"email": userName}
//         const promise:any = this.api.commonPostApi(url, body).toPromise().catch(ex=> {this.spinner.hide();});
//         return promise;
//     }

//     async authorize(userName, password){
//         const headers= {
//             'Content-Type':  'application/json',
//             'Authorization': 'Basic WkxiR2lxM2xRNmM3VXNTTHg5TlNJdz09OndFUGFVd0FFL2FDb0t6MFVPVVIxT3ZPVHNVeThzVC8zU0FhWFVMVTJaYTA9'
//         };
//         const promise:any = await this.api.authenticate({url: this.baseUrl+"oauth/token?username="+userName+"&password="+password+"&grant_type=password",body: {},headers}).toPromise().catch(ex=> {
//             this.spinner.hide();
//             console.log('catched exception: ', ex);
//             if(ex.status !== 200){
//                 if(ex.error.error_description)
//                 return Swal.fire({icon: 'error', title: 'Error', text: ex.error.error_description});
//                 if(ex.error_description)
//                 return Swal.fire({icon: 'error', title: 'Error', text: ex.error_description});
//             }
//         });
//         return promise;
//         // return this.http.post(this.baseUrl + "oauth/token?username=" + userName +"&password=" + password + "&grant_type=password", {}, {headers});
//     }

//     async saveNewPassword(body){
//         let url = this.baseUrl + 'change-password';
//         const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=> {this.spinner.hide();});
//         return promise;
//     }

//     async forgotPassword(body){
//         let url = this.baseUrl + 'forgot-password';
//         const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=> {this.spinner.hide();});
//         return promise;
//     }

// }