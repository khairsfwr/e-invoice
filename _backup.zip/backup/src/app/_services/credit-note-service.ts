import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { environment } from "src/environments/environment";
import { apiService } from "./api.service";
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Injectable({
    providedIn: "root"
})
export class creditNoteService {
    baseUrl = environment.baseUrl;
    user = sessionStorage.getItem('loginUser');
    constructor(private http:HttpClient, private api:apiService, private toastr: ToastrService, private spinner:NgxSpinnerService) {}

    // Credit Note New screen services
    async getInvoiceDropdownList(code){
        let url = this.baseUrl + 'credit/note/invoice';
        let body = {"supplierCode": code};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }

    async getDisclaimer(req){
        let url = this.baseUrl + 'disclaimer';
        let body = {"disclaimerPage": req};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }

    async getGstNo(code){
        let url = this.baseUrl + 'gst?vendorCode='+code;
        const promise:any = await this.api.commonPostApi(url, {}).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }

    async checkCreditNoteUniqueness(id){
        let url = this.baseUrl + 'credit/note/unique/check';
        let body = {"creditNoteNo": id};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }

    async fetchCreditNoteDetails(id){
        let url = this.baseUrl + 'credit/note/fetch';
        let body = {"creditNoteIid": id};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }

    async getReasonDropdownValues(){
        let url = this.baseUrl + 'code/table/dropdown';
        let body = {"dropdown": "reasonDropdown"};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }

    async saveCreditNoteDetails(body, apiName){
        let url = this.baseUrl + apiName;
        const promise: any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{
            this.spinner.hide();
            Swal.fire({title: 'Error', icon: 'error', text: 'Credit Note Details not save successfully'})
        });
        return promise;
    }

    async uploadingDocuments(files, id, description, namesArray:any[], descriptionArray:any[]){
        let url = this.baseUrl + 'files/upload-multiple-files?id=' + id + '&page=newCreditNote&description=' + description +'&path=creditNote&user=' + this.user;     
        const promise: any = await this.api.commonUploadDocuments(url, files, namesArray, descriptionArray).toPromise().catch(ex=>{
            this.spinner.hide();
            Swal.fire({title: 'Error', icon: 'error', text: 'Documents not uploaded properly'});
        });
        return promise;          
    }

    async getPOCurrency(id){
        let url = this.baseUrl + 'invoice/po/currency';
        let body = {"internalId": id};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }

    async getPONumber(id){
        let url = this.baseUrl + 'invoice/po/currency/v2';
        let body = {"internalId": id};
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }

    async getPoList(sCode){
        let body= {"supplierCode": sCode}
        let url = this.baseUrl + 'po/get-po-details'
        let promise:any[] = await this.api.commonPostApi(url, body).toPromise().catch(()=>{this.spinner.hide();})
        return promise;
    }

    async getCompanyName(code){
        let body = {"companyCode": code}
        let url = this.baseUrl + 'po/get-companyname';
        let promise:any = await this.api.commonPostApi(url, body).toPromise().catch(()=>{this.spinner.hide();});
        return promise;
    }

    async getAllCodes(){
        let url = this.baseUrl + 'code/all';
        const promise:any = await this.api.commonPostApi(url, {}).toPromise().catch(ex=>{});
        return promise;
    }

    async getDropdownCurrency(){
        let url = this.baseUrl + 'dropdown/currency';
        const promise:any = await this.api.commonPostApi(url, {}).toPromise().catch(ex=>{});
        return promise;
    }

    //Credit Note History services
    downloadFiles(type, Iid, fileName){
        return this.baseUrl + 'download/file?id=' + Iid +'&page=newCreditNote&description=' + type + '&fileName=' + fileName;
    }

    async getCreditNoteHistory(body){
        let url = this.baseUrl + 'credit/note/search';
        const promise:any = await this.api.commonPostApi(url, body).toPromise().catch(ex=>{this.spinner.hide();});
        return promise;
    }
    
}