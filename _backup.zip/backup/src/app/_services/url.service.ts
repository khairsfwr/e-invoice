import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
@Injectable({
    providedIn: 'root',
})
export class UrlService {
    private previousUrl: BehaviorSubject<string> = new BehaviorSubject<string>('');
    public previousUrl$: Observable<string> = this.previousUrl.asObservable();

    setPreviousUrl(previousUrl: string) {
        if (previousUrl.includes(`;`)) {
            previousUrl = previousUrl.substring(0, previousUrl.indexOf(`;`));
        }
        this.previousUrl.next(previousUrl);
    }
}