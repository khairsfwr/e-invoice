import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import * as CryptoJS from 'crypto-js';
import { environment } from '@environments/environment';
import {EKey} from '@app/_enum/storage-key';
/**Class for Session Storage and Local Storage service */
@Injectable({
  providedIn: 'root',
})
export class StorageService {
  private secretMsg: string = `:LS&SS=🔐`;
  private isEcrypt: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  private storage:Storage = sessionStorage;

  public config(): void {
    environment.production ? this.enabledEcrypt() : this.disabledEcrypt();
  }

  public setStorageType(type:Storage): void {
    this.storage = type;
  }

  public getStorageType(): Storage {
    return this.storage;
  }

  public enabledEcrypt(): void {
    this.isEcrypt.next(true);
  }

  public disabledEcrypt(): void {
    this.isEcrypt.next(false);
  }

  public getItem(key: string): any {
    let value =  this.storage.getItem(key);
    return value === null ? null : this.decrypt(value);
  }

  public setItem(key: string, value: string): void {
    this.storage.setItem(key, this.encrypt(value));
  }

  public removeItem(key: string): void {
    this.storage.removeItem(key);
  }

  public removeItems(keys: string[]): void {
    keys.forEach(key => {
      this.storage.removeItem(key);
    });
  }
  
  public clear(): void {
    this.storage.clear();
  }

  /**Remove local and session*/
  public reset(): void{
    localStorage.clear();
    sessionStorage.clear();
  }

  public key(index: number): string | null {
    return this.storage.key(index)
  }    

  private encrypt(msg: any): string {
    return this.isEcrypt.value ? CryptoJS.AES.encrypt(msg, this.secretMsg).toString() : msg;
  }

  private decrypt(ciphertext: string): string {
    return this.isEcrypt.value ? CryptoJS.AES.decrypt(ciphertext, this.secretMsg).toString(CryptoJS.enc.Utf8) : ciphertext;
  }

  /**Modify based on project */
  public get getKeyJwt() : boolean | string {
    if(typeof this.storage.getItem(EKey.jwt) != 'string') return false;
    return JSON.parse(this.storage.getItem(EKey.jwt) as string);
  }

  public set setKeyJwt(data:string) {
    this.storage.setItem(EKey.jwt, data);
  }

}