import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject,Observable} from 'rxjs';
import {map,finalize} from 'rxjs/operators';

import {environment} from '@environments/environment';

const baseUrl=`${environment.baseUrl}/security`;

@Injectable({providedIn: 'root'})
export class GeneralService {

  constructor(private http: HttpClient){
  }

  getAny() {
    return this.http.get<any[]>(baseUrl);
}

}