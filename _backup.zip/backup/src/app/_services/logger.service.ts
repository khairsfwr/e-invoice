import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {

  constructor() { }

  public log = ((message: any, ...optionalParams: any[]) => !environment.production ? console.log(message, ...optionalParams) : 0 );
  
  public logErr = ((message: any, ...optionalParams: any[]) => !environment.production ? console.error(message, ...optionalParams) : 0 );

}
