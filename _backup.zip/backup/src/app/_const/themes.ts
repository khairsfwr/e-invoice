export const themes = [
  {
    name: 'light-theme'
  },
  {
    name: 'dark-theme'
  }
];
