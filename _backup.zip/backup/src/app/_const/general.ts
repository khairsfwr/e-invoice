
export const CKey = {
    AuthorizationBasic: 'Basic WkxiR2lxM2xRNmM3VXNTTHg5TlNJdz09OndFUGFVd0FFL2FDb0t6MFVPVVIxT3ZPVHNVeThzVC8zU0FhWFVMVTJaYTA9',
}