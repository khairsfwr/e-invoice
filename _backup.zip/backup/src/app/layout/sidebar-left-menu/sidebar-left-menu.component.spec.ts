import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SidebarLeftMenuComponent } from './sidebar-left-menu.component';

describe('SidebarLeftMenuComponent', () => {
  let component: SidebarLeftMenuComponent;
  let fixture: ComponentFixture<SidebarLeftMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SidebarLeftMenuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SidebarLeftMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
