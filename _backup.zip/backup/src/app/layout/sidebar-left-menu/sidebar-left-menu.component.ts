import { Component, OnInit } from '@angular/core';

declare var $: any; // to declare use jquery in angular, add jquery inside angular.json script or npm install jquery

@Component({
  selector: 'layout-sidebar-left-menu',
  templateUrl: './sidebar-left-menu.component.html',
  styleUrls: ['./sidebar-left-menu.component.scss']
})
export class SidebarLeftMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    $(function () {
      $(".btn-toggle-menu").click(function () {
        $("#wrapper").toggleClass("toggled");
      });
    })

  }

}


