import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminlteMainSidebarComponent } from './adminlte-main-sidebar.component';

describe('AdminlteMainSidebarComponent', () => {
  let component: AdminlteMainSidebarComponent;
  let fixture: ComponentFixture<AdminlteMainSidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminlteMainSidebarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminlteMainSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
