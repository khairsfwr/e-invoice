import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '@app/_services';

@Component({
  selector: 'layout-adminlte-main-sidebar',
  templateUrl: './adminlte-main-sidebar.component.html',
  styleUrls: ['./adminlte-main-sidebar.component.scss']
})
export class AdminlteMainSidebarComponent implements OnInit {

  constructor(
    private router: Router,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {
    // redirect to home if already logged in
    if (this.accountService.accountValue) {
      this.router.navigate(['/']);
    }
  }

}
