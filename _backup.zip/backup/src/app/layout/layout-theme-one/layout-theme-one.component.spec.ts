import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LayoutThemeOneComponent } from './layout-theme-one.component';

describe('LayoutThemeOneComponent', () => {
  let component: LayoutThemeOneComponent;
  let fixture: ComponentFixture<LayoutThemeOneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LayoutThemeOneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LayoutThemeOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
