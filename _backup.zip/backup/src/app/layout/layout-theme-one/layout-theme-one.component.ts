import { Component } from '@angular/core';
import {UrlService} from '@app/_services/url.service';
import {AccountService} from '@app/_services';
import {slideInAnimation} from '@app/animation';

@Component({
  selector: 'app-layout-theme-one',
  templateUrl: './layout-theme-one.component.html',
  styleUrls: ['./layout-theme-one.component.scss'],
  animations: [
    slideInAnimation
  ]
})
export class LayoutThemeOneComponent {
  isLogin: boolean = false;
  url:string = '';
  role:string = '';
 
  constructor(private _url:UrlService, private _auth:AccountService) {
    _url.previousUrl$.subscribe(url=> this.url = url);
    _auth.account.subscribe((acc)=>{
      if(JSON.stringify(acc)==='{}' || !acc || acc.isPasswordChanged===0){
        this.isLogin = false;
        return this.role = '';
      } 
      this.isLogin = true;
      return this.role = acc.userRole;
    });
  }

  initResponsiveArrow(){
    let arrow = document.querySelectorAll(".arrow");
    for (var i = 0; i < arrow.length; i++) {
      arrow[i].addEventListener("click", (e) => {
        if (e && e.target && (e.target as any).parentElement) {
          let arrowParent = (e.target as any).parentElement.parentElement;//selecting main parent of arrow
          arrowParent.classList.toggle("showMenu");
        }
      });
    }
  }
  initResponsiveSideBar(){
    let sidebar = document.querySelectorAll(".sidebar");
    let sidebarBtn = document.querySelectorAll(".toggle-sidebar");
    if (sidebarBtn)
      sidebarBtn.forEach(x=>x.addEventListener("click", () => {
        if (sidebar.length>0)
          sidebar.forEach(x=>x.classList.toggle("close"));
      }));
  }

  ngAfterViewInit() {
    this.initResponsiveArrow();
    this.initResponsiveSideBar();
  }

  logout() {
  }

}
