import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  openNav() {
    // let sidebar_app:Element = document.getElementsByClassName("sidebar-app")[0];
    // if (sidebar_app){
    //   (sidebar_app as HTMLElement).style.width = "250px";
    //   // (sidebar_app as HTMLElement).style.transition = "0.5s";
    // }
    // let content:Element = document.getElementsByClassName("content")[0];
    // if (content) {
    //   (content as HTMLElement).style.marginLeft = "250px";
    //   // (content as HTMLElement).style.transition = "0.5s";
    document.getElementById("mySidenav")!.style.width = "250px";
  }

  closeNav() {
    document.getElementById("mySidenav")!.style.width = "0";
    // let sidebar_app:Element = document.getElementsByClassName("sidebar-app")[0];
    // if (sidebar_app) (sidebar_app as HTMLElement).style.width = "0px";
    // let content:Element = document.getElementsByClassName("content")[0];
    // if (content) (content as HTMLElement).style.marginLeft = "70px";
  }
}

