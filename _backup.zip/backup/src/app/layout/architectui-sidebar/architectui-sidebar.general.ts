export const templateSidebar = [
  {
    "heading": "Overview",
    "parent": [
      {
        "icon": "pe-7s-home",
        "name": "Home",
        "routerLink": "/home",
        "child": []
      },
      {
        "icon": "pe-7s-home",
        "name": "List",
        "routerLink": "/list",
        "child": []
      }
    ]
  },
  {
    "heading": "Modules",
    "parent": [
      {
        "icon": "pe-7s-note",
        "name": "Invoice",
        "routerLink": "",
        "child": [
          {
            "name": "New",
            "routerLink": "/invoice/new"
          },
          {
            "name": "History",
            "routerLink": "/dcn/history"
          }
        ]
      },
      {
        "icon": "pe-7s-drawer",
        "name": "Change Request",
        "routerLink": "",
        "child": [
          {
            "name": "New",
            "routerLink": "/cr/new"
          },
          {
            "name": "History",
            "routerLink": "/cr/history"
          }
        ]
      },
      {
        "icon": "pe-7s-anchor",
        "name": "Techniqal Query",
        "routerLink": "",
        "child": [
          {
            "name": "New",
            "routerLink": "/tq/new"
          },
          {
            "name": "History",
            "routerLink": "/tq/history"
          }
        ]
      }
    ]
  },
  {
    "heading": "Developer Mode",
    "parent": [
      {
        "icon": "pe-7s-home",
        "name": "Insight",
        "routerLink": "/developer/insight",
        "child": [
        ]
      },
      {
        "icon": "pe-7s-home",
        "name": "Components",
        "routerLink": "",
        "child": [
          {
            "name": "Form",
            "routerLink": "/developer/component/form"
          }
        ]
      }
    ]
  },
]