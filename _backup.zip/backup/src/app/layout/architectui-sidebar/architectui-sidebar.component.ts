import {Component,OnInit,ChangeDetectorRef,TemplateRef} from '@angular/core';
import {Router} from '@angular/router';
import {AccountService,AlertService, StorageService} from '@app/_services';
import {templateSidebar} from './architectui-sidebar.general';
import {slideInAnimation} from '@app/animation';
import {log} from '@app/_helpers/function.general';
import {Account} from '@app/_models';
import {BsModalRef,BsModalService} from 'ngx-bootstrap/modal';
import {ModalService} from '@app/_services/modal.service';
import {Subscription} from 'rxjs';
import {LoggerService} from '@app/_services/logger.service';

@Component({
    selector: 'layout-architectui-sidebar',
    templateUrl: './architectui-sidebar.component.html',
    styleUrls: ['./architectui-sidebar.component.scss'],
    animations: [
        slideInAnimation
    ]
})
export class ArchitectuiSidebarComponent implements OnInit {

    public sidebarList=templateSidebar;

    isLogin!: boolean;
    loading: boolean=false;
    uiItem: any;
    projectCode: any;

    get url() {
        return this.router.url;
    }

    get accountValue() {
        return this.accountService.accountValue;
    }

    setUiItem() {
        this.uiItem={
            account: new Account()
        }
    }

    setObservableItem() {
        console.log(":::::::::::::::::::::setObservableItem");
        this.destroy = this.accountService.account.subscribe((item: Account|null) => {
            this.uiItem.account=item;
        })
    }

    constructor(
        private router: Router,
        private accountService: AccountService,
        private alertService: AlertService,
        private cdr: ChangeDetectorRef,
        private modalService: ModalService,
        private storage:StorageService,
        private msg:LoggerService
    ) {
    }

    ngOnInit(): void {
        this.msg.log("Account ::", this.accountValue);
        this.isLogin=this.accountValue? true:false;
        this.setUiItem();
        this.setObservableItem();
    }

    ngAfterViewInit(): void {
        let arrow=document.querySelectorAll(".arrow");
        // console.log(arrow);
        for(var i=0;i<arrow.length;i++) { 
            arrow[i].addEventListener("click",(e) => {
                if(e&&e.target&&(e.target as any).parentElement) {
                    let arrowParent=(e.target as any).parentElement.parentElement;//selecting main parent of arrow
                    arrowParent.classList.toggle("showMenu");
                }
            });
        }
    }

    transform(): void {
        let sidebar=document.querySelector(".app-sidebar");
        if(!sidebar) return;
        !sidebar.classList.contains('transform')? sidebar.classList.add('transform'):sidebar.classList.remove('transform');
    }


    logout() {
        // reset alerts on submit
        this.alertService.clear();

        // this.loading = true;
        this.accountService.logout();

        this.storage.clear();

        this.isLogin=false;
    }

    ngAfterContentChecked() {
        this.isLogin=this.accountValue? true:false;
    }

    /**Bases can be use in all file */
    openModalById(id?: string) {
        // this.modalService.developerModal(' I am a child modal, opened from parent component!',{ignoreBackdropClick: false});
    }
    
    clickOpenDeveloperModal(){
        this.modalService.developerModal();
    }
    destroy!:Subscription;
    ngOnDestroy() {
        this.destroy.unsubscribe();
      }
}
