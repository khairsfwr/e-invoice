import { Component, OnInit } from '@angular/core';

declare var $: any; // to declare use jquery in angular, add jquery inside angular.json script or npm install jquery

@Component({
  selector: 'private-layout',
  templateUrl: './private.component.html',
  styleUrls: ['./private.component.scss']
})
export class PrivateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    (function(){
      $('#msbo').on('click', function(){
        $('body').toggleClass('msb-x');
      });
    }());
  }

}

