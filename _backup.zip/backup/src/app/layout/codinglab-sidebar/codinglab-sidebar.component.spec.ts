import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CodinglabSidebarComponent } from './codinglab-sidebar.component';

describe('CodinglabSidebarComponent', () => {
  let component: CodinglabSidebarComponent;
  let fixture: ComponentFixture<CodinglabSidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CodinglabSidebarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CodinglabSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
