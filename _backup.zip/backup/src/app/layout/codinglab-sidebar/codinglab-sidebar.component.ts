import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'layout-codinglab-sidebar',
  templateUrl: './codinglab-sidebar.component.html',
  styleUrls: ['./codinglab-sidebar.component.scss']
})
export class CodinglabSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    let arrow = document.querySelectorAll(".arrow");
    for (var i = 0; i < arrow.length; i++) {
      arrow[i].addEventListener("click", (e) => {
        if (e && e.target && (e.target as any).parentElement) {
          let arrowParent = (e.target as any).parentElement.parentElement;//selecting main parent of arrow
          arrowParent.classList.toggle("showMenu");
        }

      });
    }
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".toggle-sidebar");
    console.log(sidebarBtn);
    if (sidebarBtn)
      sidebarBtn.addEventListener("click", () => {
        if (sidebar)
          sidebar.classList.toggle("close");
      });
  }

}
