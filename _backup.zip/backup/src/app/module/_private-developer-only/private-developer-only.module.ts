import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PrivateDeveloperOnlyRoutingModule } from './private-developer-only-routing.module';
import { PrivateDeveloperOnlyComponent } from './page/private-developer-only/private-developer-only.component';


@NgModule({
  declarations: [
    PrivateDeveloperOnlyComponent
  ],
  imports: [
    CommonModule,
    PrivateDeveloperOnlyRoutingModule
  ]
})
export class PrivateDeveloperOnlyModule { }
