import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {PrivateDeveloperOnlyComponent} from './page/private-developer-only/private-developer-only.component';

const routes: Routes = [
  { path: '', redirectTo: 'insight'},
  { path: 'insight', component: PrivateDeveloperOnlyComponent },
  { path: 'component', children: [
    { path: 'form', component: PrivateDeveloperOnlyComponent },
  ] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrivateDeveloperOnlyRoutingModule { }
