import {Component,OnInit} from '@angular/core';
import {AccountService} from '@app/_services';

@Component({
  selector: 'app-private-developer-only',
  templateUrl: './private-developer-only.component.html',
  styleUrls: ['./private-developer-only.component.scss']
})
export class PrivateDeveloperOnlyComponent implements OnInit {

  allLocalStorage: any[]=[];
  allObservable: any[]=[];

  constructor(private accountService: AccountService) {}

  ngOnInit(): void {
    // config Local Storage
    this.getAllLocalStorage();
    this.getAllObservable();
  }

  getAllLocalStorage() {
    let result: any=[];
    for(let i=0;i<localStorage.length;i++) {
      result.push({key: localStorage.key(i),value: JSON.parse(localStorage.getItem(localStorage.key(i) as string) as string)})
    }
    this.allLocalStorage=[...result];
  }

  getAllObservable() {
    this.allObservable=[{class: 'AccountService',property: [{variable: 'account',value: null}]}]
    this.accountService.account.subscribe((account) => {
      // this.allObservable.filter(x=>x.class!='AccountService');
      this.allObservable.map(x => x.class==='AccountService'? x.property.map((y:any)=>y.variable==='account' ? y.value=account: y.value): x);
    });
  }

}
