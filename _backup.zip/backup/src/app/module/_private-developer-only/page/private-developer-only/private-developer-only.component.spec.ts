import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivateDeveloperOnlyComponent } from './private-developer-only.component';

describe('PrivateDeveloperOnlyComponent', () => {
  let component: PrivateDeveloperOnlyComponent;
  let fixture: ComponentFixture<PrivateDeveloperOnlyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrivateDeveloperOnlyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivateDeveloperOnlyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
