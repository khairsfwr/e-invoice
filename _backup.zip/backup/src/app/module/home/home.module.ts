import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';

import { HomeComponent } from './page/home/home.component';
import { HomePendingRequestComponent } from './page/home-pending-request/home-pending-request.component';
import { HomeStatusSummaryComponent } from './page/home-status-summary/home-status-summary.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
// import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {MatTooltipModule} from '@angular/material/tooltip';
import { ListComponent } from './page/list/list.component';
import { ListTableComponent } from './page/list-table/list-table.component';
import { ListFilterComponent } from './page/list-filter/list-filter.component';
import {ShareModule} from '@app/share/share.module';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {ButtonsModule} from 'ngx-bootstrap/buttons';
import { HomeTableComponent } from './page/home-table/home-table.component';

import { NgxChartsModule } from '@swimlane/ngx-charts';
import { HomeSearchComponent } from './page/home-search/home-search.component';
import { DataTablesModule } from 'angular-datatables';
import {NgxSpinnerModule} from 'ngx-spinner';

// import { NgxPaginationModule } from 'ngx-pagination';
@NgModule({
  declarations: [
    HomeComponent,
    HomePendingRequestComponent,
    HomeStatusSummaryComponent,
    HomeTableComponent,
    ListComponent,
    ListTableComponent,
    ListFilterComponent,
    HomeSearchComponent,
  ],
  imports: [
    DataTablesModule,
    ButtonsModule.forRoot(),
    PaginationModule.forRoot(),
    CommonModule,
    HomeRoutingModule,
    FormsModule,
    MatTooltipModule,
    // NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule,
    NgxChartsModule,
    NgxSpinnerModule,
    ShareModule,
  ]
})
export class HomeModule { }
