import {Component,OnInit} from '@angular/core';
import {IPendingRequestReformatItem,  IPendingRequestReformat, IPendingRequesFetchtItem, IPendingRequestFetch, dcnPendingRequestFetch, IPendingRequestTable} from './home-pending-request.general';

type TModule = "DCN"|"CR"|"TQ"

@Component({
  selector: 'home-pending-request',
  templateUrl: './home-pending-request.component.html',
  styleUrls: ['./home-pending-request.component.scss']
})
export class HomePendingRequestComponent implements OnInit {

  list: any[]=[];

  dcnPendingRequestTableTbl: IPendingRequestTable[]=[]

  // dcnPendingCategory: IPendingRequestCategory={"Pending actual effort update": [],"pending submission": []}

  constructor() {}

  ngOnInit(): void {
    let items:any = null;
    items  = this.fetchItems();
    this.setItems(items, "DCN");
    // this.getItems();

  }

  fetchItems(){
    return dcnPendingRequestFetch;
  }

  setItems(items:any, module: TModule) {
    if(!items) return;

    //Reformat
    if(module==='DCN'){
      const dcnPendingRequestReformat: IPendingRequestReformat = {pendingSubmission: (items as IPendingRequestFetch)["pendin submission"], pendingActualEffortUpdate: (items as IPendingRequestFetch)["Pending actual effort update"]};
      this.dcnPendingRequestTableTbl = dcnPendingRequestReformat.pendingSubmission.concat(dcnPendingRequestReformat.pendingActualEffortUpdate).map(x => x).sort((x,y) => x.internalId-y.internalId);
    }
  }

  getItems(module: TModule, state: "fetch"|"reformat") {
    return 
    // this.dcnTbl=dcnPending["Pending actual effort update"].concat(dcnPending["pendin submission"]).map(x => x).sort((x,y) => x.internalId-y.internalId);
    // console.log(this.dcnTbl);
// 
    // return this.list;
  }

}


