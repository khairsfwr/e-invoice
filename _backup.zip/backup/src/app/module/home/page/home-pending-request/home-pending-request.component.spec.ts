import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomePendingRequestComponent } from './home-pending-request.component';

describe('HomePendingRequestComponent', () => {
  let component: HomePendingRequestComponent;
  let fixture: ComponentFixture<HomePendingRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomePendingRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomePendingRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
