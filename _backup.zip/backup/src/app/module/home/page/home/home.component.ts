import {Component,OnInit,TemplateRef} from '@angular/core';
import {slideInAnimation} from '@app/animation';
import {AccountService, CommonService, StorageService} from '@app/_services';
import {IAccount, Account} from '@app/_models';
import {ModalService} from '@app/_services/modal.service';
import {ModalId} from '@app/_components/modal/modal.component';
import {NgForm} from '@angular/forms';
import {UrlService} from '@app/_services/url.service';
import {Router} from '@angular/router';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  animations: [
    slideInAnimation
  ]
})
export class HomeComponent implements OnInit {

  public account: IAccount = this.accountService.accountValue ? this.accountService.accountValue : new Account() ;
  public message: any;
  public loading:boolean = true;
  
  constructor(
    private accountService: AccountService,
    private modalService: ModalService,
    private commonService: CommonService,
    private storage:StorageService,
    private url:UrlService,
    private router:Router,
    private toast:ToastrService
  ) {

    if(!this.account) return;
    this.message={welcome: `Welcome ${this.account.name} 😊.`}
    this.url.previousUrl$.subscribe((x:string)=> x.includes('sign_in') ? this.toast.show(this.message.welcome): '');
  }

  async ngOnInit(): Promise<void> {
    this.url.setPreviousUrl(this.router.url);
  }

  clickOpenSimpleModal() {
    this.modalService.simpleModal({header: 'Header...',body: 'Body...'})
  }

  onSubmit(f: NgForm) {
    console.log(f.value);  // { first: '', last: '' }
    console.log(f.valid);  // false
  }

}

