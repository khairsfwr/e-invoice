import {CommonSystem} from '@app/module/common/common-system';


export class chartDetails extends CommonSystem {
    submissionYearList: any[]=["2013","2014","2015","2016","2017","2018","2019","2020","2021","2022"]
    poTypeList: any[]=["OP","ON","OS"]
    getStatusCountObject() {return {"status": null,"count": 0,"amount": 0}}
    getReportListObject(): {"name": any,"series": any[]} {return {"name": null,"series": []}}
    statusCountList: any[]=[];

    loading: boolean=false;
    statusData: any[]=[];
    statusDataFooter: any={};


   
    // view: any[]=[700,400];

    // options
    gradient: boolean=true;
    showLegend: boolean=true;
    showLabels: boolean=true;
    isDoughnut: boolean=false;
    legendPosition: string='below';

    // colorScheme={
    //     domain: ['#5AA454','#A10A28','#C7B42C','#AAAAAA']
    // };

    constructor() {
        super();
        // var single = [
        //     {
        //       "name": "Germany",
        //       "value": 8940000
        //     },
        //     {
        //       "name": "USA",
        //       "value": 5000000
        //     },
        //     {
        //       "name": "France",
        //       "value": 7200000
        //     },
        //       {
        //       "name": "UK",
        //       "value": 6200000
        //     }
        //   ];
        // Object.assign(this,{single});
    }

    async prepareStatusCountObject(list: any) {
        this.loading=true;
        let totalCount: number=0;
        let totalAmount: number=0;
        console.log('list before remove duplicates: ',list);
        let unique=list.reduce((arr: any,item: any) => {
            let exist=!!arr.find((x: any) => x.status===item.status);
            if(!exist) {arr.push(item)};
            return arr;
        },[]);
        console.log('unique: ',unique);
        for(let i=0;i<unique.length;i++) {
            let count: number=0;
            let amount: number=0;
            let obj=this.getStatusCountObject();
            obj["status"]=unique[i].status;
            for(let j=0;j<list.length;j++) {
                if(unique[i].status===list[j].status) {
                    count=Number(count)+Number(list[j].count);
                    amount=Number(amount)+Number(list[j].amount);
                    totalCount=Number(totalCount)+Number(list[j].count);
                    totalAmount=Number(totalAmount)+Number(list[j].amount);
                    obj["count"]=count;
                    obj["amount"]=amount;
                }
            }
            this.statusData.push(obj);
        }
        // this.statusData.push({"status": 'Total', "count": totalCount, "amount": totalAmount});
        this.statusDataFooter={"status": 'Total',"count": totalCount,"amount": totalAmount};
        this.loading=false;
    }

    onSelect(data: any): void {
        console.log('Item clicked', JSON.parse(JSON.stringify(data)));
      }
    
      onActivate(data: any): void {
        console.log('Activate', JSON.parse(JSON.stringify(data)));
      }
    
      onDeactivate(data: any): void {
        console.log('Deactivate', JSON.parse(JSON.stringify(data)));
      }
}