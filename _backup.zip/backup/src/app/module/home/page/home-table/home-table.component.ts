import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {FormGroup,FormBuilder} from '@angular/forms';
import {CommonService} from '@app/_services/common.service';
import {chartDetails} from './home.modal';
import {NgxSpinner, NgxSpinnerService} from 'ngx-spinner';
import {LegendPosition, ScaleType} from '@swimlane/ngx-charts';
import {StorageService} from '@app/_services';
import {ModalService} from '@app/_services/modal.service';

@Component({
  selector: 'home-table',
  templateUrl: './home-table.component.html',
  styleUrls: ['./home-table.component.scss']
})
export class HomeTableComponent extends chartDetails implements OnInit {
  @Output() data = new EventEmitter();
  homeForm!: FormGroup;
  role:any; 
  // allSuppliersApiCalled:boolean = false;
  // allSupplierListStorage:any[] = [];
  reportDetailList:any[]=[];
  chartData:any[]=[];

  // chart options
  view:[number,number] = [1000, 750]
  legendTitle: string = 'Status'
  // legendTitleMulti: string = 'Months'
  legendPosition: LegendPosition = LegendPosition.Below;
  legend:boolean = true

  xAxis:boolean = true
  yAxis:boolean = true

  xAxisLabel: string = 'Status'
  yAxisLabel: string = 'Amount'
  showXAxisLabel: boolean = true
  showYAxisLabel: boolean = true

  maxXAxisTickLength: number = 60
  maxYAxisTickLength: number = 60
  trimXAxisTicks: boolean = false
  trimYAxisTicks: boolean = false
  rotateXAxisTicks: boolean = false

  // xAxisTicks: any[] = ['Genre 1', 'Genre 2', 'Genre 3', 'Genre 4', 'Genre 5', 'Genre 6', 'Genre 7']
  // yAxisTicks: any[] = [10000, 100000, 200000, 500000, 700000, 1000000]

  animations: boolean = true
  showGridLines: boolean = true
  showDataLabel: boolean = true

  gradient: boolean = false

  colorScheme: any = {
    domain: ['#20c997', '#1e8081', '#C7B42C', '#BF9D76','#A5D7C6','#F5E5B9','#A8385D','#8796C0'],
  }
  schemeType: ScaleType = ScaleType.Ordinal;
  activeEntries:any[] = ['book']
  barPadding: number = 15
  tooltipDisabled: boolean = false

  yScaleMax: number = 9000
  roundEdges: boolean = false

  barMaxWidth: number = 20

  // @HostListener("window:beforeunload", ["$event"]) unloadHandler(event: Event){
  //   // this.router.navigateByUrl('')
  //   console.log('windows reloaded from home ');
    
  // }

  chartType:any = 'column';


  single!: any[];

  setChart(event:any){
    this.chartType = event.target.value;
  }
  constructor(public fb:FormBuilder,public spinner: NgxSpinnerService, public common: CommonService, 
    public storage:StorageService, public modalService:ModalService) {
    super();
   }

  async ngOnInit() {
    this.role = sessionStorage.getItem('userRole');
    await this.initForm();
    if(this.role === 'SUPPLIER'){
      this.homeForm.patchValue({supplierName: sessionStorage.getItem('userName')});
    }else{
      // let suppliers = Array.from(this.common.supplierList);
      this.modalService.supplier.subscribe(item=>{
        if(!item)return;
        return this.saveSelectedSuppliers(item);
      })

      // this.selectedSuppliers = [];
      // this.selectedSuppliers = this.common.getSupplierSubjectValue();
      // let name = this.selectedSuppliers.map(e => e.companyName).join(", ");
      // console.log('selected supplier name with comma seperator:::', name);
      // this.homeForm.patchValue({supplierName: name})
      await this.getHomeReport('', '');
    }
  }

  async initForm(){
    this.homeForm = this.fb.group({
      supplierName: null,
      submissionYear: "",
      poType: ""
    });
    
  }

  onSelectedSupplierWatchList(event:any){
    this.supplierWatchListCheckbox = event.target.checked ? true : false;
    this.watchList = event.target.checked ? 1 : 0;
    console.log('Supplier watch list check box:', this.supplierWatchListCheckbox);
  }

  async getAllSupplierDetails(){
    this.selectedSuppliers = [];
    this.q = 1;
    this.allSupplierList = [];
    this.copyOfAllSupplierList = [];
    if(this.watchList == 1){
      let obj = {
        "search": 'all',
        "supplierCode": '',
        "supplierName": '',
        "empId": sessionStorage.getItem('employeeId'),
        "watchList": 1,
        "role": sessionStorage.getItem('userRole')
      }
      let response: any = await this.common.getAllSuppliers(obj);
      this.allSupplierList = response.data as any;
    }else{
      this.allSupplierList = Array.from(this.common.supplierList);
    }    
    this.copyOfAllSupplierList = Array.from(this.allSupplierList);
    console.log('newwwwwwwww supplier list: ', this.allSupplierList);
  }

  async saveSelectedSuppliers(data:any){
    console.log('value from child: ',data);
    this.selectedSuppliers = [];
    this.selectedSuppliers = Array.from(data);
    let name = this.selectedSuppliers.map(e => e.companyName).join(", ");
    console.log('selected supplier name with comma seperator:::', name);
    this.homeForm.patchValue({supplierName: name})
    await this.getReport();
  }

  async getReport(){
    this.loading = true;
    this.reportDetailList = [];
    this.chartData = [];
    this.spinner.show;
    await this.getHomeReport(this.homeForm.value.submissionYear, this.homeForm.value.poType);
    this.spinner.hide();
    this.loading = false;
  }

  async resetSearchValues(){
    this.selectedSuppliers = [];
    this.homeForm.reset();
    await this.getHomeReport('', '');
  }

  async getHomeReport(year:any, poType:any){
    this.loading = true;
    this.spinner.show();
    this.statusData = [];
    if(this.common.getSupplierSubjectValue.length === 0){
      
      if(this.common.supplierList.length === 0){
        let obj = {
          "search": 'all',
          "supplierCode": '',
          "supplierName": '',
          "empId":  this.storage.getItem('employeeId'),
          "watchList": 0,
          "role":  this.storage.getItem('userRole')
        }
        
        this.spinner.show();
        await this.common.receiveDefaultSupplierList(obj);
        
        this.spinner.hide();
        this.loading = false;
      }
    }



    const response:any = await this.common.getHomeScreenReport((this.selectedSuppliers.length > 0) ? this.selectedSuppliers : this.common.supplierList, year, poType);
    if(response.data.length > 0){
      this.reportDetailList = response.data as any;
      
      for(let i=0; i<this.reportDetailList.length; i++){
        for(let j=0; j<this.reportDetailList[i].series.length; j++){
          let object = this.getStatusCountObject();
          object["status"] = this.reportDetailList[i].series[j].name;
          object["count"] = this.reportDetailList[i].series[j].count;
          object["amount"] = this.reportDetailList[i].series[j].value;
          this.chartData.push(object);
        }
      }
      await this.prepareStatusCountObject(this.chartData);
      this.organizeReportList();
      this.spinner.hide();
      console.log("Chart Data for display:", this.statusData);
    }
    this.spinner.hide();
  }

  organizeReportList(){
    let totalCount:number = 0;
    let totalAmount:number = 0;  
    let sampleReportList: any[] = [];      
    console.log('list before remove duplicates: ', this.reportDetailList);
    for(let j=0; j<this.reportDetailList.length; j++){
      let reportObject = this.getReportListObject();
      let unique = this.reportDetailList[j].series.reduce((arr:any[], item:any)=>{
        let exist = !!arr.find(x => x.name === item.name);
        if(!exist){arr.push(item)};
        return arr;
      }, []);
      console.log('unique: ', unique);
      for(let i=0; i<unique.length; i++){
        let count:number = 0;
        let value:number = 0;
        let series:{
          "name": null;
          "count": null | number;
          "value": null | number; 
      } = {"name": null, "count": null, "value": null};
        series["name"] = unique[i].name;
        for(let k=0; k<this.reportDetailList[j].series.length; k++){                
          if(unique[i].name === this.reportDetailList[j].series[k].name){
              count = Number(count) + Number(this.reportDetailList[j].series[k].count);
              value = Number(value) + Number(this.reportDetailList[j].series[k].value);
              // totalCount = Number(totalCount) + Number(this.reportDetailList[j].count);
              totalAmount = Number(totalAmount) + Number(this.reportDetailList[j].amount);               
              
              series["count"] = count;
              series["value"] = value;
          }
        }
        reportObject['series'].push(series);
      }
      reportObject['name'] = this.reportDetailList[j].name;
      sampleReportList.push(reportObject);
      totalCount = Number(totalCount) + Number(reportObject.series.length);
    }
    console.log('final report list: ', sampleReportList);
    this.reportDetailList = [];
    this.reportDetailList = Array.from(sampleReportList);
    console.log('finalsssssss: ', this.reportDetailList);
    console.log('count final: ', totalCount);
    
    if(totalCount < 7) {
      for(let i = this.reportDetailList[0].series.length; i<7; i++){
        this.reportDetailList[0].series.push({"name": '', "count": 0, "value": 0});
      }
    }
    let copy:any[] =  [...this.reportDetailList];


    // this.single = copy.map((item:any)=>{
    //   // return {"name":item.name,"value":(item.series as any[]).reduce((accumulator, currentValue:any)=>accumulator+currentValue.value,0)}
    // });
    let newCopy:any[]=[];
    copy.forEach(item=>{
      item.series.forEach((item2:any)=>{
      let temp = newCopy.find(x=>x.name===item2.name);
      if(temp){
        temp.value = temp.value+ item2.value;
        newCopy = newCopy.filter(y=>y.name != temp.name);
        newCopy.push(temp);
      }else{
        newCopy.push({name: item2.name, value: item2.value});
      }
      });
    });
    this.single = newCopy;
  }
  downloadFile(filename:string): void {
    let link:string = '';
    link = (filename === 'User Manual') ? 'assets/files/User Manual.pdf':
           (filename === 'Keppel') ? 'assets/files/keppel einvoice system -terms and conditions of use.pdf':
           (filename === 'AGD') ? 'assets/files/AGD TermsOfUse.pdf':
           '';
    window.open(link);
  }


}
