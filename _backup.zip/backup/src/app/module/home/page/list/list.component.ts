import { Component, OnInit } from '@angular/core';
import {slideInAnimation} from '@app/animation';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  animations: [
    slideInAnimation
  ]
})
export class ListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
