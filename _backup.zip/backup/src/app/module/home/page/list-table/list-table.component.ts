import {Component,OnInit} from '@angular/core';
import {slideInAnimation} from '@app/animation';
import {IPendingRequestTable,dcnPendingRequestFetch,TModule,IPendingRequestReformat,IPendingRequestFetch,TPendingRequestReformatStatus} from '../list-table/list-table.general';

import {StatusType} from '@app/_models';
import {PageChangedEvent} from 'ngx-bootstrap/pagination';
interface dcnStatus {
  title: string,
  color: string
}

@Component({
  selector: 'list-table',
  templateUrl: './list-table.component.html',
  styleUrls: ['./list-table.component.scss']
})
export class ListTableComponent implements OnInit {
  checkModel: {left?: boolean; middle?: boolean; right?: boolean}={left: false,middle: true,right: false};
  dcnPendingRequestTable: IPendingRequestTable[]=[];
  //pagination
  returnPendingRequestTable: IPendingRequestTable[]=[];
  startItem: number=0;
  endItem: number=20;

  constructor() {}

  ngOnInit(): void {
    let items: any=null;
    items=this.fetchItems();
    this.setItems(items,"DCN");
  }

  fetchItems() {
    return dcnPendingRequestFetch;
  }

  setItems(items: any,module: TModule) {
    if(!items) return;

    //Reformat
    if(module==='DCN') {
      const dcnPendingRequestReformat: IPendingRequestReformat={pendingSubmission: (items as IPendingRequestFetch)["pendin submission"],pendingActualEffortUpdate: (items as IPendingRequestFetch)["Pending actual effort update"]};
      this.dcnPendingRequestTable=dcnPendingRequestReformat.pendingSubmission.concat(dcnPendingRequestReformat.pendingActualEffortUpdate).map(x => x).sort((x,y) => x.internalId-y.internalId);
      this.returnPendingRequestTable=this.dcnPendingRequestTable.slice(this.startItem,this.endItem);
    }
  }

  setSortByItem(sortBy: {main: string,child: string},module: TModule) {
    if(!sortBy) return;

    const main=sortBy.main;
    const sub=sortBy.child;

    //Reformat
    if(module==='DCN') {
      this.dcnPendingRequestTable=this.dcnPendingRequestTable.sort((x,y) => {
        if(sub==='Ascending') {
          if(main==='Status') {
            return +(y.status<x.status)||-(y.status>x.status);
          } else {
            return x.internalId-y.internalId
          }
        } else {
          if(main==='Status') {
            return +(y.status>x.status)||-(y.status<x.status);
          } else {
            return y.internalId-x.internalId;
          }
        }
      });
    }

    this.returnPendingRequestTable=this.dcnPendingRequestTable.slice(this.startItem,this.endItem);
  }


  getItems(module: TModule,state: "fetch"|"reformat") {
  }

  changeCheckboxCheckOne() {
  }

  changeCheckboxCheckAll(checked: boolean) {
    this.dcnPendingRequestTable.forEach(x => x.checkbox=checked)
  }

  setStatusColor(status: TPendingRequestReformatStatus) {
    if(!status) return;

    const classes=['d-inline-block','px-2','h-25','bg-opacity-25','shadow-sm','small','lh-base','font-monospace','bg-gradient ','border '];

    const statusTypeClass={
      [StatusType.Draft]: 'bg-primary text-primary border-primary',
      [StatusType.Approved]: 'bg-scm text-scm border-scm'
    }

    classes.push(statusTypeClass[status]);

    return classes.join(' ');
  }

  pageChanged(event: PageChangedEvent): void {
    this.startItem=(event.page-1)*event.itemsPerPage;
    this.endItem=event.page*event.itemsPerPage;
    this.returnPendingRequestTable=this.dcnPendingRequestTable.slice(this.startItem,this.endItem);
  }

  setTableViewSetting(value: string) {
    if(value==='') {
      document.getElementsByTagName('table')[0].classList.remove('table-sm');
    } else {
      document.getElementsByTagName('table')[0].classList.add('table-sm');
    }
  }

  test(a: any) {
  }
  // realtime search in progress
  keyupSearh(value: string) {
    value = value.toString().toLowerCase();
    this.returnPendingRequestTable=this.dcnPendingRequestTable.filter(ls=>{
      if(ls.dcnNo.toString().toLowerCase().includes(value) || ls.dcnStatus.toString().toLowerCase().includes(value) || ls.status.toString().toLowerCase().includes(value)
      || ls.internalId.toString().toLowerCase().includes(value)
      ){
        return ls;
      }
      return;
    })
    // var $rows=document.querySelectorAll("table tr");
    // var val=value.toLowerCase().toString();
    // for(let i=0;i<$rows.length;i++) {
    //   const row=$rows[i];
    //   var text = (row.textContent as string).toLowerCase();
    //   if(text.indexOf(val)!=-1){
    //   }
    // }
  }

}




