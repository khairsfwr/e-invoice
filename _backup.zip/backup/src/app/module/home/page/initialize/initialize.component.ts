import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {CommonService, StorageService} from '@app/_services';


@Component({
  selector: 'initialize',
  templateUrl: './initialize.component.html'
})
export class InitializeComponent implements OnInit {

  constructor(private router: Router, private commonService:CommonService, private storage:StorageService) {
   }

  async ngOnInit() {
    let obj = {
      "search": 'all',
      "supplierCode": '',
      "supplierName": '',
      "empId":  this.storage.getItem('employeeId'),
      "watchList": 0,
      "role":  this.storage.getItem('userRole')
    }
    let resp:any = await this.commonService.receiveDefaultSupplierList(obj);
    if(resp.status === '200')this.goToHome();
    
  }

  goToHome(){
    this.router.navigate(['/home']);
  }

}
