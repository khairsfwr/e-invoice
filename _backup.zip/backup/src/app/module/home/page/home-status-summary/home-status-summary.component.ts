import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-status-summary',
  templateUrl: './home-status-summary.component.html',
  styleUrls: ['./home-status-summary.component.scss']
})
export class HomeStatusSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
