import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeStatusSummaryComponent } from './home-status-summary.component';

describe('HomeStatusSummaryComponent', () => {
  let component: HomeStatusSummaryComponent;
  let fixture: ComponentFixture<HomeStatusSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomeStatusSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeStatusSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
