import { Component, OnInit, TemplateRef } from '@angular/core';
import {HomeTableComponent} from '../home-table/home-table.component';
import {FormBuilder} from '@angular/forms';
import {NgxSpinnerService} from 'ngx-spinner';
import {CommonService} from '@app/_services/common.service';
import {StorageService} from '@app/_services';
import {ModalService} from '@app/_services/modal.service';
import {SupplierDialogComponent} from '@app/share/supplier-dialog/supplier-dialog.component';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import {BsModalService, BsModalRef} from 'ngx-bootstrap/modal';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'home-search',
  templateUrl: './home-search.component.html',
  styleUrls: ['./home-search.component.scss']
})
export class HomeSearchComponent extends HomeTableComponent  {

  public loading:boolean = false;
  public submitted:boolean = true;
  modalRef?: BsModalRef;
  
  constructor(public fb:FormBuilder, public spinner: NgxSpinnerService, public common: CommonService, private bsModalService: BsModalService
    ,public storage:StorageService, public modalService:ModalService,private matDialog: MatDialog) { 
      super(fb,spinner,common,storage,modalService) 
    }

  get f() { return (this.homeForm.controls); }

  clickOpenSupplierModal(template?: TemplateRef<any>) {
    let options: bootstrap.Modal.Options = {
      backdrop:'static',
      keyboard:true,
      focus:true
    }
    var myModal = new bootstrap.Modal(document.getElementById('staticBackdrop') as HTMLElement, options)
    myModal.toggle();
    // this.modalRef = this.bsModalService.show(template);
    // this.modalService.supplierModal({header: 'Header...',body: 'Body...'})

    // this.matDialog.open(SupplierDialogComponent, {
    //   "width": '6000px',
    //   "maxHeight": '90vh',
    //   "data": "John",
    //   "autoFocus": false
    // });
  }
  

}
