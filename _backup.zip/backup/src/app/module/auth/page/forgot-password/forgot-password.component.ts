import {Component,OnInit,ChangeDetectorRef} from '@angular/core';
import {FormGroup,FormBuilder, FormControl, Validators} from '@angular/forms';
import {ActivatedRoute,Router} from '@angular/router';
import {AccountService,AlertService,StorageService,CommonService} from '@app/_services';
import {LoginComponent} from '../login/login.component';
import {UrlService} from '@app/_services/url.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent extends LoginComponent implements OnInit {
  constructor(
    formBuilder: FormBuilder,
    route: ActivatedRoute,
    router: Router,
    accountService: AccountService,
    alertService: AlertService,
    cdr: ChangeDetectorRef,
    storage: StorageService,
    common: CommonService,
    url:UrlService
  ) {
    super(formBuilder,route,router,accountService,alertService,cdr,storage,common,url);
  }

  initForgotForm(){
    this.loginForm = this.formBuilder.group({
      userName: new FormControl(null, [Validators.required]),
      email: [{ value: '', disabled: false }, [Validators.required, Validators.email]]
    });
    console.log('set form =====>',this.loginForm.value);
  }

  ngOnInit(): void {
    this.initForgotForm();
  }

}
