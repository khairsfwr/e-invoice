import {FormGroup, FormControl, Validators, FormBuilder} from "@angular/forms";

class LoginForm {
  loginForm!: FormGroup;
  constructor(private formBuilder: FormBuilder) {
    this.loginForm = this.formBuilder.group({
      userName: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required]),
      newPassword: new FormControl(null, [Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{7,}$")]),
      confirmPassword: new FormControl(null, [Validators.required])
    },{
      // validator: this.mustMatch('newPassword', 'confirmPassword')
    });

  }
}

// not done yet