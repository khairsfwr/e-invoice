import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AccountService, AlertService, CommonService } from '@app/_services';
import { first } from 'rxjs/operators';
import {StorageService} from '@app/_services/storage.service';
import {EKey} from '@app/_enum/storage-key';
import {UrlService} from '@app/_services/url.service';
import {slideInOutAnimation} from '@app/animation';
// import * as pj from '../../../../../../package.json';
const pj = require("package.json");

// exclusive for 'Form'
interface ILoginForm {
  email: AbstractControl;
  password: AbstractControl;
  userName: AbstractControl;
  newPassword: AbstractControl;
  confirmPassword: AbstractControl;
}
// structure on submit
interface ILoginSignIn {
  email: string;
  password: string;
}
class LoginForm {
  private email!: string;
  private password!: string;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations: [
    slideInOutAnimation
  ]
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  loading: boolean = false;
  submitted: boolean = false;

  dcmsAdmin: boolean = false;
  svrErr: string = '';
  // loginForm!: FormGroup;
  // userInfo: any | UserInfo = {};
  app_version: string = pj.version;
  app_name: string = pj.name;
  sessionExpired: boolean = false;

  constructor(
    protected formBuilder: FormBuilder,
    protected route: ActivatedRoute,
    protected router: Router,
    protected accountService: AccountService,
    protected alertService: AlertService,
    protected cdr: ChangeDetectorRef,
    // private formBuilder: FormBuilder,
    // private router: Router,
    // private authService: AuthService,
    // private spinner: NgxSpinnerService,
    protected storage: StorageService,
    protected common: CommonService,
    protected url:UrlService
  ) {  }

  /////////////////////////////////////// Login Function     ///////////////////////////////////////

  // convenience getter for easy access to form fields
  get f() { return (this.loginForm.controls as unknown as ILoginForm); }

  get fEmail() { return this.f.email; }

  get fPassword() { 
    if(!this.f.password.value)return this.f.password;
    this.f.password.setValue(this.f.password.value.trim()); 
    return this.f.password; 
  }

  get fUserName() {
    if(!this.f.userName.value)return this.f.userName;
    this.f.userName.setValue(this.f.userName.value.trim()); 
    return this.f.userName;
   }

  onSubmit() {
    this.submitted = true;

    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    this.loading = true;
    this.accountService.getJWT(this.fUserName.value, this.fPassword.value)
    .pipe(first())
    .subscribe({
      next: (data) => {
        this.accountService.login(this.fUserName.value)
          .pipe(first())
          .subscribe({
            next: (resp) => {
              this.storage.setItem(EKey.loginUser,this.fUserName.value);
              if(resp.data.isPasswordChanged===0) return this.router.navigate(['security/new-user']);
              this.storage.setItem(EKey.password,this.fPassword.value);
              this.storage.setItem(EKey.userRole,resp.data.userRole);
              this.storage.setItem(EKey.employeeId,resp.data.empId);
              this.storage.setItem(EKey.email,resp.data.email);
              this.storage.setItem(EKey.supplierInfo,JSON.stringify(resp.data.supplierInfo));
              this.storage.setItem(EKey.userName,resp.data.name);
              // Session Id - Track for refresh token
              this.storage.setItem(EKey.sessionId,"INV ID"+new Date()+" "+Math.random());
              // get return url from query parameters or default to home page
              const returnUrl=this.route.snapshot.queryParams['returnUrl']||'/';
              this.router.navigateByUrl(returnUrl);
              return;
            },
            error: error => {
              this.alertService.error(error);
              this.loading=false;
              this.submitted=false;
            }
          });
      },
      error: error => {
        this.alertService.error(error,{autoClose: false});
        this.loading = false;
        this.submitted = false;
      }
    });

  }
  
  initLoginForm(){
    this.loginForm = this.formBuilder.group({
      userName: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required]),
      // email: [{ value: '', disabled: false }, [Validators.required, Validators.email]]
    });

    // this.loginForm = this.formBuilder.group({
    //   email: [{ value: '', disabled: false }, [Validators.required, Validators.email]],
    //   password: [{ value: '', disabled: false }, Validators.required]
    // });

    console.log('set form =====>',this.loginForm.value);
  }

  initForgetPasswordForm(){
    this.loginForm = this.formBuilder.group({
      userName: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required]),
      newPassword: new FormControl(null, [Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{7,}$")]),
      confirmPassword: new FormControl(null, [Validators.required])
    },{
      validator: this.mustMatch('newPassword', 'confirmPassword')
    });

    // this.loginForm = this.formBuilder.group({
    //   email: [{ value: '', disabled: false }, [Validators.required, Validators.email]],
    //   password: [{ value: '', disabled: false }, Validators.required]
    // });

    console.log('set form =====>',this.loginForm.value);
  }

  mustMatch(password: string, matchedPassword: string){
    return(formGroup: FormGroup)=> {
      const psw = formGroup.controls[password];
      const matchedPsw = formGroup.controls[matchedPassword];
      if(matchedPsw.errors && !matchedPsw.errors['mustMatch']){
        return;
      }
      if(psw.value !== matchedPsw.value){
        matchedPsw.setErrors({mustMatch: true});
      }else{
        matchedPsw.setErrors(null);
      }
    }
  }

  validationMessages = {
    isCapsLock:false,
    isNumber:false,
    charctersLength:false,
    isSmallLetter:false,
    isSpecialCharcter:false
  }

  specialCharctersformat = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~[0-9][a-z][A-Z]]/;

  validatePassword1(){
     let value:string= this.loginForm.value.newPassword.trim();
     let values:string[] = value.split("");
     console.log(values);   
     this.validationMessages.isSmallLetter =  this.specialCharctersformat.test(value) ? true :false;
     this.validationMessages.isCapsLock =  this.specialCharctersformat.test(value) ? true :false;
     this.validationMessages.charctersLength =  this.specialCharctersformat.test(value) ? true :false;
     this.validationMessages.isNumber =  this.specialCharctersformat.test(value) ? true :false;
     this.validationMessages.isSpecialCharcter = this.specialCharctersformat.test(value) ? true :false;
     this.validationMessages.isSpecialCharcter = this.specialCharctersformat.test(value) ? true :false;
  }

  /////////////////////////////////////// Angular Life Cycle /////////////////////////////////////// 
  ngOnInit() {
    this.url.setPreviousUrl(this.router.url);
    this.initLoginForm();
    // if(!this.accountService.accountValue)return this.storage.clear();
  }

}
