import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import {LoginComponent} from '../login/login.component';
import {FormBuilder, Form, FormControl, Validators} from '@angular/forms';
import {ActivatedRoute,Router} from '@angular/router';
import {AccountService,AlertService,StorageService,CommonService} from '@app/_services';
import Swal from 'sweetalert2';
import {UrlService} from '@app/_services/url.service';
import {EKey} from '@app/_enum/storage-key';
import {slideInOutAnimation, slideInAnimation} from '@app/animation';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss'],
  animations: [
    slideInAnimation,slideInOutAnimation
  ]
})
export class NewUserComponent extends LoginComponent implements OnInit {
  isValidPassword:boolean = false;

  constructor(
    formBuilder: FormBuilder,
    route: ActivatedRoute,
    router: Router,
    accountService: AccountService,
    alertService: AlertService,
    cdr: ChangeDetectorRef,
    storage: StorageService,
    common: CommonService,
    url:UrlService
  ) {
    super(formBuilder,route,router,accountService,alertService,cdr,storage,common,url);
    if(this.accountService.accountValue === null ) this.router.navigateByUrl('/security/sign_in');
  }

  onSubmit(){
  }

  initNewUserForm(){
    this.loginForm = this.formBuilder.group({
      newPassword: new FormControl(null, [Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{7,}$")]),
      confirmPassword: new FormControl(null, [Validators.required])
    },{
      validator: this.mustMatch('newPassword', 'confirmPassword')
    });
    console.log('set form =====>',this.loginForm.value);
  }

  get fConfirmPassword(){
    return this.f.confirmPassword;
  }

  get fNewPassword(){
    return this.f.newPassword;
  }

  ngOnInit(): void {
    this.initNewUserForm();
    this.url.setPreviousUrl(this.router.url);
  }

  showPasswordConditionPanel(){
    if(document.getElementById('passwordConditionId')===null)return;

    document.getElementById('passwordConditionId')!.style.display = "block";
  }

  hidePasswordCondition(){
    if(document.getElementById('passwordConditionId')===null)return;

    document.getElementById('passwordConditionId')!.style.display = "none";
  }

  validatePassword(){
    let lowerCase = /[a-z]/g;
    let upperCase = /[A-Z]/g;
    let number = /[0-9]/g;
    let specialChar = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
    let password = this.loginForm.value.newPassword.trim();


    password.match(lowerCase) ? document.getElementById('letter')!.classList.replace('invalid','valid') : document.getElementById('letter')!.classList.replace('valid','invalid');
    password.match(upperCase) ? document.getElementById('capital')!.classList.replace('invalid','valid') : document.getElementById('capital')!.classList.replace('valid','invalid');
    password.match(number) ? document.getElementById('number')!.classList.replace('invalid','valid') : document.getElementById('number')!.classList.replace('valid','invalid');
    (password.length >= 8) ? document.getElementById('length')!.classList.replace('invalid','valid') : document.getElementById('length')!.classList.replace('valid','invalid');
    password.match(specialChar) ? document.getElementById('special')!.classList.replace('invalid','valid') : document.getElementById('special')!.classList.replace('valid','invalid');
    this.isValidPassword = true;
    ['letter','capital','number','length','special'].forEach((x:string)=>{
      if((document.getElementById(x)!.classList.contains('invalid'))){
        this.isValidPassword = false;
      }
    });

    
  }

  gotoLoginPage(){
    this.router.navigateByUrl('sign_in');
  }

  async saveNewPassword(){
    this.loading = false;
    console.log('login form: ', this.loginForm);
    if(this.loginForm.controls.newPassword.status === 'INVALID' || this.loginForm.controls.confirmPassword.status === 'INVALID' || !this.isValidPassword || this.loginForm.controls.newPassword.value !== this.loginForm.controls.confirmPassword.value ){
      this.submitted = true
      return;
    }
    this.loading = true;
    // this.spinner.show();
    let body = {"username": this.storage.getItem(EKey.loginUser).trim(), "password": this.loginForm.value.newPassword.trim()};
    const response:any = await this.accountService.saveNewPassword(body);
    console.log('response of save new password: ', response);
    // this.spinner.hide();
    if(response.status == 200){
      Swal.fire({icon: 'success', title: 'Success', text: 'Password updated successfully, please login with new password.'})
      .then(()=>{this.loading = false; this.router.navigate(['/security/sign_in'])});
    }else{
      Swal.fire({icon: 'error', title: 'Error', text: response.message})
    }
    this.loading = false;
    return 
  }
}
