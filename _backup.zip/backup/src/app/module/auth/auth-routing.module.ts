import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './page/login/login.component';
import { LayoutComponent } from './page/layout/layout.component';
import {ForgotPasswordComponent} from './page/forgot-password/forgot-password.component';
import {NewUserComponent} from './page/new-user/new-user.component';

const routes: Routes = [
  { path: '', redirectTo: 'sign_in' },
  {
    path: '', component: LayoutComponent,
    children: [
        { path: 'sign_in', component: LoginComponent },
        { path: 'forgot_password', component: ForgotPasswordComponent },
        { path: 'new-user', component: NewUserComponent },
    ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
