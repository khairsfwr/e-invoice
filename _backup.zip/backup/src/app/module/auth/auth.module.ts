import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AuthRoutingModule } from './auth-routing.module';

import { LoginComponent } from './page/login/login.component';
import { LayoutComponent } from './page/layout/layout.component';
import {ShareModule} from '@app/share/share.module';
import { ForgotPasswordComponent } from './page/forgot-password/forgot-password.component';
import { NewUserComponent } from './page/new-user/new-user.component';


@NgModule({
  declarations: [
    LoginComponent,
    LayoutComponent,
    ForgotPasswordComponent,
    NewUserComponent
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    ShareModule
  ]
})
export class AuthModule { }
