import {NgModule} from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import {InvoiceComponent} from './page/invoice/invoice.component';
import {InvoiceNewComponent} from './page/invoice-new/invoice-new.component';
import {InvoiceLayoutComponent} from './page/invoice-layout/invoice-layout.component';
// import {LayoutComponent} from '@app/account/layout.component';

const routes: Routes=[
  // {path: '',redirectTo: 'init'},
  // {path: 'init',component: InitializeComponent},
  // {path: 'home',component: HomeComponent},
  {
    path: '',component: InvoiceLayoutComponent,
    children: [
      {path: 'new',component: InvoiceNewComponent},
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InvoiceRoutingModule {}
