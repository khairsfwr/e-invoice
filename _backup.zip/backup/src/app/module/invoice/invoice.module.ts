import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InvoiceRoutingModule } from './invoice-routing.module';
import {InvoiceComponent} from './page/invoice/invoice.component';
import {ShareModule} from '@app/share/share.module';
import {ReactiveFormsModule,FormsModule} from '@angular/forms';
import {ButtonsModule} from 'ngx-bootstrap/buttons';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatDialogModule} from '@angular/material/dialog';
import {NgxPaginationModule} from 'ngx-pagination';
import {ToastrModule} from 'ngx-toastr';
import {InvoiceNewComponent} from './page/invoice-new/invoice-new.component';
import {InvoiceLayoutComponent} from './page/invoice-layout/invoice-layout.component';
import {RouterModule} from '@angular/router';


@NgModule({
  declarations: [InvoiceComponent,InvoiceNewComponent,InvoiceLayoutComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule, //form
    FormsModule, //ngmodel etc
    ButtonsModule.forRoot(),
    MatTooltipModule,
    MatDialogModule, 
    NgxPaginationModule,
    ToastrModule.forRoot({
      positionClass :'toast-bottom-right'
    }),
    RouterModule,
    InvoiceRoutingModule,
    ShareModule, 
  ]
})
export class InvoiceModule { }
