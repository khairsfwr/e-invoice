import {Component,OnInit, TemplateRef, ChangeDetectorRef, ViewChild} from '@angular/core';
import {invoiceService} from '@app/_services/invoice-service';
import {FormBuilder,FormControl,Validators,FormGroup,FormArray} from '@angular/forms';
import {ToastrService} from 'ngx-toastr';
import {NgxSpinnerService} from 'ngx-spinner';
import {Router} from '@angular/router';
import {StorageService} from '@app/_services';
import {EKey} from '@app/_enum/storage-key';
import Swal from 'sweetalert2';
import {invoiceDetails} from '../invoice-modal';
import {debounce} from '@app/_helpers/function.general';
import * as bootstrap from 'bootstrap';
import {Subscription} from 'rxjs';
import {NgSelectComponent} from '@ng-select/ng-select';
import {UrlService} from '@app/_services/url.service';


@Component({
  selector: 'invoice-new',
  templateUrl: './invoice-new.component.html',
  styleUrls: ['./invoice-new.component.scss'] 
})
export class InvoiceNewComponent extends invoiceDetails implements OnInit {
  @ViewChild(NgSelectComponent) ngSelect!: NgSelectComponent;
  
  cssColorForSuccess:string = 'is-valid bg-scm-100 shadow-sm bg-opacity-50';
  cssColorForFail:string = 'is-invalid';

  cancelChange!:any[];

  isPOLoading=false;  

  addressBooksCode: any;

  constructor(public invoice: invoiceService,public fb: FormBuilder,public toastr: ToastrService,public spinner: NgxSpinnerService,public router: Router,public storage: StorageService, public cd:ChangeDetectorRef,
    public url:UrlService) {
    super();
    var tooltipTriggerList=[].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList=tooltipTriggerList.map(function(tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl)
    })
  } 

  async ngOnInit() {
    this.url.setPreviousUrl(this.router.url);
    await this.initForm();
    let supplierInfo=JSON.parse(this.storage.getItem(EKey.supplierInfo));
    if(supplierInfo) {
      this.newInvoiceForm.patchValue({supplierName: supplierInfo.companyName,gstNo: supplierInfo.taxId})
      this.gstApplicable=(supplierInfo.taxId===null)? true:false;
      this.addressBooksCode=supplierInfo.addressBooksCode;
      if(this.gstApplicable) {
        this.gstPercentage=0;
      } else {await this.getGstNo(this.addressBooksCode);}
    }
    // await this.getPODetails();
    await this.getDisclaimer();
    await this.getGstTaxCode();
    console.log(this.newInvoiceForm.controls.tableRow);
  }

  private destroyInvoiceObservable!:Subscription;
  ngOnDestroy(){
    console.log('destroy...');
    this.destroyInvoiceObservable.unsubscribe();
  }

  initForm() {
    this.newInvoiceForm=this.fb.group({
      supplierName: new FormControl({value: '',disabled: true},Validators.required),
      supplierCode: new FormControl(null),
      gstNo: new FormControl({value: '',disabled: true}),
      poNo: [null,Validators.required],
      poType: [{value: null, disabled: true},Validators.required],
      billTo: [{value: null, disabled: true},Validators.required],
      location: new FormControl({value: '',disabled: true}),
      doNo: [{value: null, disabled: true},Validators.required],
      invoiceNo: [null,Validators.required],
      invoiceDate: [null,Validators.required],
      invoiceFile: [null,Validators.required],
      invoiceFileOriginal:  [null,Validators.required],
      exchangeRate: [{value: null, disabled: true}],
      netAmount: [{value: null, disabled: true},Validators.required],
      gstAmount: [{value: null, disabled: true},Validators.required],
      grossAmount: [{value: null, disabled: true},Validators.required],
      localGstAmount: [{value: null, disabled: true},Validators.required],
      desclaimer: new FormControl({value: '',disabled: true}),
      poCurrencyCode: null,
      companyCurrencyCode: null,
      gstTaxCode: [null,Validators.required],
      tableRow: this.fb.array([])
    });
    
    this.invoice.setSelectedDoList = null;

    this.destroyInvoiceObservable = this.invoice.selectedDoNoList.subscribe((item:any)=>{
      if(!item) return;
      console.log("doNo for field:", item.forField);
      this.f.doNo.setValue(item.forField);
      console.log("doNo for send:", item.forSend);
      this.selectedDoList = item.forSend;
    });

  }

  get f() {return this.newInvoiceForm.controls}

  createSupportingDocumentObject(): FormGroup {
    return this.fb.group({
      attachmentName: new FormControl(null,[Validators.required]),
      documentName: new FormControl(null),
      description: new FormControl(''),
      file: new FormControl(null)
    });
  }
  get g() {return this.newInvoiceForm.controls.tableRow}

  get getTableControls() {
    return this.newInvoiceForm.get('tableRow') as FormArray;
  }

  async getCompanyCurrencyCode(companyCode: undefined,currencyCode: undefined) {
    let response: any=await this.invoice.getCompanyName(companyCode);
    if(response.data.companyCodeFrom) {
      this.newInvoiceForm.patchValue({companyCurrencyCode: response.data.companyCodeFrom,exchangeRate: (response.data.companyCodeFrom===currencyCode)? 1:null})
    }
    this.isCurrencyDifferent=(this.newInvoiceForm.value.companyCurrencyCode===currencyCode)? false:true;
    console.log('is currency differ from po selected company currency code::',this.isCurrencyDifferent);
  }

  async getGstNo(code: any) {
    const response: any=await this.invoice.getGstNo(code);
    console.log("getGstNo:"+JSON.stringify(response));
    if(response) {
      this.gstPercentage=response.codeTableValue;
    }
  }
  async getPODetails() {
    this.poList=[];
    this.isPOLoading=true;
    // this.spinner.show();
    this.poList=await this.invoice.getPoList(this.storage.getItem(EKey.loginUser));
    this.poListCopy=this.poList;
    // this.spinner.hide();
    this.isPOLoading=false;
    console.log('Po Details:::::',this.poList);
  }

  async getPODetailsWithPO(event: any) {
    this.poList=[];
    this.isPOLoading=true;
    // this.spinner.show();
    this.poList=await this.invoice.getPoList(this.storage.getItem(EKey.loginUser), event.target.value);
    this.poListCopy=this.poList;
    // this.spinner.hide();
    this.isPOLoading=false;
    console.log('Po Details:::::',this.poList);
  }

  // async getPODetails(event: {"term": string,items: any[]}) {
  //   this.poList=[];
  //   this.isPOLoading=true;
  //   // this.spinner.show();
  //   this.poList=await this.invoice.getPoList(this.storage.getItem(EKey.loginUser),event.term);
  //   this.poListCopy=this.poList;
  //   // this.spinner.hide();
  //   this.isPOLoading=false;
  //   console.log('Po Details:::::',this.poList);
  // }

  async onSelectedPONo(event: any) {
    console.log('event of selected po method::',event)
    this.clearValuesAfterChangingPONo();
    if(!event) {return }
    this.spinner.show();
    let billToCodeList: any[]=[];
    this.newInvoiceForm.patchValue({poNo: event.purchaseOrderNo,exchangeRate: null});
    this.f.poNo.setValue( event.purchaseOrderNo);
    let poNo=this.newInvoiceForm.value.poNo;
    let locationCode: any,currencyCode: any,internalId: any;
    let compCode: any;
    console.log('po list in onSelectedPONo',this.poList);
 
    this.poList.forEach(item => {
      if(item.purchaseOrderNo===poNo) {
        this.supplierCode=item.supplierCode;
        this.poTypeList.push(item.orderType);
        currencyCode=item.currencyCode;
        internalId=item.internalId;
        compCode=item.companyCode;

        billToCodeList.push(compCode as any);
      }
    }) 
    locationCode=await this.getLocation(this.supplierCode,poNo);
    if(locationCode!==null) {
      this.addNewDOButtonEnabled=locationCode==='01'? false:true;
      this.getLocationName(locationCode);
    } else {this.addNewDOButtonEnabled=true}
    this.getDeliveryOrderList(internalId);

    sessionStorage.setItem('Selected PO Internal Id',internalId);
    sessionStorage.setItem('Supplier Company Code',compCode);
    this.newInvoiceForm.patchValue({poCurrencyCode: currencyCode,doNo: null,supplierCode: this.supplierCode})
    await this.getCompanyCurrencyCode(compCode,currencyCode);
    (this.poTypeList.length==1)? this.newInvoiceForm.patchValue({poType: this.poTypeList[0]}):this.newInvoiceForm.patchValue({poType: null});
    billToCodeList.forEach(element => {this.getCompanyName(element);});
    billToCodeList.length===1? this.newInvoiceForm.patchValue({billTo: compCode}):'';
    this.spinner.hide();


    console.log();
    
  }

  isfieldsEnablePONoHaveValue(){
    if(this.f.poNo.value!=null){
      this.f.poType.enable();
      this.f.billTo.enable();
      this.f.doNo.enable();
      this.f.netAmount.enable();
      this.f.gstAmount.enable();
      this.f.grossAmount.enable();
    }else{
      this.f.poType.disable();
      this.f.billTo.disable();
      this.f.doNo.disable();
      this.f.netAmount.disable();
      this.f.gstAmount.disable();
      this.f.grossAmount.disable();
    }

    if(this.isCurrencyDifferent){
      this.f.localGstAmount.enable();
      this.f.exchangeRate.enable();
    }else{
      this.f.localGstAmount.disable();
      this.f.exchangeRate.disable();
      this.f.exchangeRate.setValue(null);
    }


    // (this.f.poType as any)[flag]();
    // (this.f.billTo as any)[flag]();
  }

  onSelectPO($event: any) {
    let value=$event.target.value;
    if(!isNaN(value)) {
      this.poList=this.poListCopy.filter((x) => {return x.purchaseOrderNo.substring(0,value.length)==value});
      if(value.length==0) {
        this.poList=Array.from(this.poListCopy);
      }
    }
  }

  async getLocation(supplierCode: any,poNo: any) {
    const response: any=await this.invoice.getLocationCode(supplierCode,poNo);
    if(response.data!==null) {
      return response.data.locationCode;
    }
  }

  async getLocationName(locationCode: any) {
    let result: any=await this.invoice.getLocation(locationCode);
    if(result.data!==null) {
      this.newInvoiceForm.patchValue({location: result.data.name})
      this.spinner.hide();
    }
  }

  async getDisclaimer() {
    const response: any=await this.invoice.getDisclaimer('INV');
    if(response) {
      this.newInvoiceForm.patchValue({desclaimer: response.codeTableValue})
    }
  }

  async getDeliveryOrderList(poId: undefined) {
    this.spinner.show();
    this.invoice.setDoList = [];
    let deliveryOrderList=[];
    this.doList=[];
    const response: any=await this.invoice.getDoList(poId);
    this.spinner.hide();
    deliveryOrderList=(response as any)
    deliveryOrderList.forEach((item: {deliveryOrderNo: string; internalId: string;}) => {
      this.deliveryObject={"doNo": '',"dosTrnDoHdrIid": '',checked: false, disabled: true};
      this.deliveryObject["doNo"]=item.deliveryOrderNo;
      this.deliveryObject["dosTrnDoHdrIid"]=item.internalId;
      this.doList.push(this.deliveryObject);
      this.invoice.setDoList = [...this.doList];
    })
  }

  async validateInvoiceNo() {
    this.spinner.show();
    let invoiceNo=this.newInvoiceForm.value.invoiceNo;
    const response: any=await this.invoice.invoiceNoValidation(invoiceNo,this.addressBooksCode);
    this.spinner.hide();
    if(response.message==='invoiceNo duplicate') {
      this.newInvoiceForm.patchValue({invoiceNo: null})
      Swal.fire({icon: 'error',text: 'Invoice number duplicated, please give another invoice number'})
    }
  }

  async getCompanyName(code: any) {
    this.billToList=[];
    let response: any=await this.invoice.getCompanyName(code);
    if(response) {
      this.lovObject["code"]=response.data.companyCode;
      this.lovObject["value"]=response.data.companyName;
      this.billToList.push(this.lovObject)
    }
  }

  // async getGstCheck(compCode) {
  //   this.spinner.show();
  //   const response: any = await this.invoice.getGstCode(compCode);
  //   if (response.data) {
  //     this.gstApplicable = (response.data.taxId === null) ? true : false;
  //     this.newInvoiceForm.patchValue({ supplierName: response.data.companyName, gstNo: response.data.taxId })
  //   }
  //   this.spinner.hide();
  // }

  onUploadedInvoiceFile(event: any) {
    if(event.target.validity.valueMissing) return;

    this.spinner.show();
    console.log('lower case:',event.target.files[0].name.toString().toLowerCase())
    if(event.target.files[0].name.toString().toLowerCase().split('.').pop()=='pdf') {
      if(this.isFileMoreThan10MB(event.target.files[0].size)) {
        event.target.files = null;
        debugger
        this.f.invoiceFileOriginal.setValue(null);
        this.toastr.error('Maximum allowed file size is 10MB');
      } else {
        let fileName=event.target.files[0].name.split('.').shift();
        // this.f.invoiceFile.setValue(fileName);
        this.newInvoiceForm.patchValue({invoiceFile: fileName});
        this.invoiceFile=event.target.files[0]
        console.log('invoice file::::::::',this.invoiceFile)
        this.fileUploadLabel=true;
      }
    } else {
      Swal.fire({icon: 'error',text: 'Only pdf files are allowed'})
    }
    this.spinner.hide();
  }

  onDeleteInvoiceFile() {
    this.newInvoiceForm.patchValue({invoiceFile: null})
    this.fileUploadLabel=false;
    this.invoiceFile=null;
    console.log('invoice file after deleted::::::::',this.invoiceFile)
  }



  async validateSelectedDO(request: any[],item: any,event: {target: {checked: boolean;};},i: number) {
    const response: any=await this.invoice.doNoValidation(request);
    if(response) {
      if(response.status==200) {
        response.data.forEach((element: {status: string;}) => {
          if(element.status!=='00') {
            Swal.fire({icon: 'error',text: 'DO Number Duplicate, please select another'}).then((result) => {event.target.checked=false;})
            this.doList[i].checked=false;
          }
        })
      }
    }
  }

  async onChangeNetAmount() {
    if(this.f.netAmount.value === '' || this.f.netAmount.value === null ) 
    this.f.netAmount.setValue(0);

    console.log('gst percentage:::',this.gstPercentage);
    let net: any=parseFloat(this.newInvoiceForm.value.netAmount).toFixed(2)
    net=net.slice(0,18)
    let gstAmount=(net*this.gstPercentage)/100;
    console.log('gstAmount:::',gstAmount);
    this.newInvoiceForm.patchValue({gstAmount: gstAmount,netAmount: net});
    this.onChangeGSTAmount();
    this.newInvoiceForm.patchValue({netAmount: this.amountFormat(net)})
  }

  onChangeGSTAmount() {
    console.log('entered into onChangeGSTAmount')
    let gst: any=parseFloat(this.newInvoiceForm.value.gstAmount).toFixed(2);
    gst=gst.slice(0,18)
    let amount: any=this.removeComma(this.newInvoiceForm.value.netAmount)+parseFloat(gst)
    amount=parseFloat(amount).toFixed(2);
    amount=amount.slice(0,18)
    this.newInvoiceForm.patchValue({
      gstAmount: this.amountFormat(gst),
      grossAmount: this.amountFormat(amount),
      localGstAmount: (this.isCurrencyDifferent)? '':this.amountFormat(gst)
    })
  }

  onProvideLocalGstAmount() {
    let gst: any=parseFloat(this.newInvoiceForm.value.localGstAmount).toFixed(2);
    gst=gst.slice(0,18)
    this.newInvoiceForm.patchValue({localGstAmount: this.amountFormat(gst)})
  }

  addNewDocument() {
    let controls=this.newInvoiceForm.get('tableRow') as any;
    if(controls.valid) {
      this.getTableControls.push(this.createSupportingDocumentObject());
    } else {
      Swal.fire({icon: 'error',text: 'Please provide required information before adding a row'})
    }
  }

  onUploadedSupportingDocument(event: any) {
    this.spinner.show();
    let index: number=0;
    for(let i=0;i<event.target.files.length;i++) {
      if(event.target.files[i].name.toString().toLowerCase().split('.').pop()=='pdf') {
        if(this.isFileMoreThan10MB(event.target.files[i].size)) {
          this.toastr.error('Maximum allowed file size is 10MB');
        } else {
          let tableForm=this.createSupportingDocumentObject();
          tableForm.patchValue({
            documentName: event.target.files[i].name.split('.').shift(),
            file: event.target.files[i]
          })
          this.getTableControls.push(tableForm);
        }
      } else {
        index=index+1;
      }
    }
    if(index>0) {
      Swal.fire({icon: 'error',text: 'Only pdf files are allowed'})
    }
    this.spinner.hide();
  }

  onDeleteSupportingDocument(i: number) {
    this.getTableControls.removeAt(i);
  }
  validateAllFormFields(formGroup: FormGroup) {     
    var forms = document.querySelectorAll('.needs-validation')

    Array.prototype.slice.call(forms)
    .forEach(function (forms) {
      forms.addEventListener('submit', function (event:any) {
        if (!forms.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }
        forms.classList.add('was-validated');
      }, false)})
    
                                                        //{1}
    Object.keys(formGroup.controls).forEach(field => {  //{2}
      const control = formGroup.get(field);             //{3}
      if (control instanceof FormControl) {             //{4}
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {        //{5}
        this.validateAllFormFields(control);            //{6}
      }
    });
  }
  async submitNewInvoice() {
    this.isOnSubmit=false;
    this.supportingDocumentsList=[];
    console.log('form::',this.newInvoiceForm);
    console.log('form value:::',this.getAllControlObjectValue(this.newInvoiceForm));
    if(this.newInvoiceForm.invalid) {
      this.validateAllFormFields(this.newInvoiceForm);
      this.submitted=true
      return
    }
    this.getConfirmCancel(async () => {
      this.spinner.show();
      let isDuplicate: any=await this.checkDONoDuplication(this.selectedDoList);
      if(isDuplicate) {
        this.spinner.hide();
        // this.submitted = true;
        return Swal.fire({icon: 'error',title: 'Error',text: 'Duplicate DO No will not allowed'});
      }
      let res: any=await this.grossAmountValidation();
      if(res.data==1) {
        this.spinner.hide();
        Swal.fire({icon: 'warning',title: 'Warning',showCancelButton: true,confirmButtonText: `Confirm`,text: res.message}).then((result) => {if(result.isConfirmed) this.localGstValidation()});
      } else {
        this.spinner.hide();
        this.localGstValidation();
      }
      return
    });
  }

  clearValuesAfterChangingPONo() {
    console.log('entered into clearValuesAfterChangingPONo method')
    this.billToList=[];
    this.supplierCode=null;
    this.poTypeList=[];
    this.doNoList=[];
    this.doList=[];
    this.selectedDoList=[];
    this.saveButtonOfDO=true;
    this.newInvoiceForm.patchValue({billTo: null,location: null,poType: null,poCurrencyCode: null,doNo: null});
    this.f.poNo.setValue(null);
  }
  updateDo(){
    this.newInvoiceForm.patchValue({doNo: 'abc'})
  }
  // insertDONo() {
  //   console.log('do list: ',this.doList);
  //   let value=this.prepareDoNoValue();
  //   this.invoice.setDoList = [...this.doList];
  //   this.invoice.setSelectedDoList = value;
  // }

  async grossAmountValidation() {
    let amount: any=this.removeComma(this.newInvoiceForm.value.grossAmount);
    let netAmount: any=this.removeComma(this.newInvoiceForm.value.netAmount);
    const response: any=await this.invoice.invoiceAmountValidation(sessionStorage.getItem('Supplier Company Code'),this.newInvoiceForm.value.poNo,amount,netAmount);
    return response;
  }

  getAllControlObjectValue(form:FormGroup){
    let object:any = {};
    for (const field in form.controls) { // 'field' is a string
    console.log(form.controls[field].value);
    object[field] = form.controls[field].value;
    }
    return object;
  }
  async proceedWithSubmission() {
    this.isOnSubmit=true;
    let attachmentNameArray: any[]=[];
    let descriptionArray: any[]=[];
    this.spinner.show();
    let formValue = this.getAllControlObjectValue(this.newInvoiceForm);
    let body=this.prepareBodyForSubmitInvoice(formValue,null);
    console.log('new invoice request::',body);
    for(let i=0;i<this.newInvoiceForm.value.tableRow.length;i++) {
      this.supportingDocumentsList.push(this.newInvoiceForm.value.tableRow[i].file);
      attachmentNameArray.push(this.newInvoiceForm.value.tableRow[i].attachmentName);
      descriptionArray.push(this.newInvoiceForm.value.tableRow[i].description? this.newInvoiceForm.value.tableRow[i].description:'');
    }
    console.log('supporting document list::::',this.supportingDocumentsList);
    const response=await this.invoice.saveInvoiceDetails(body);
    if(response) {
      // this.spinner.show();     
      if(response.data.internalId!==null) {
        const result: any=await this.invoice.uploadingDocuments([this.invoiceFile],response.data.internalId,"InvoiceFile",[],[]);
        if(result) {
          // this.spinner.hide();
          if(this.supportingDocumentsList.length>0) {
            // this.spinner.show();
            const res: any=await this.invoice.uploadingDocuments(this.supportingDocumentsList,response.data.internalId,"attachments",[attachmentNameArray],[descriptionArray]);
            if(res) {
              this.spinner.hide();
              Swal.fire({icon: 'success',text: 'Invoice Submitted Successfully'}).then((result) => {this.router.navigateByUrl(this.router.url);})
            }
            this.spinner.hide();
          } else {
            this.spinner.hide();
            Swal.fire({icon: 'success',text: 'Invoice Submitted Successfully'}).then((result) => {this.router.navigateByUrl(this.router.url);})
          }
        }
      }
      this.spinner.hide();
    }
    this.spinner.hide(); this.isOnSubmit=false;
  }

  onChangeExchangeRate() {
    let rate: any=parseFloat(this.newInvoiceForm.value.exchangeRate).toFixed(7)
    rate=rate.slice(0,21)
    this.newInvoiceForm.patchValue({exchangeRate: this.amountFormat(rate)})
  }

  async getGstTaxCode() {
    this.gstTaxCodeList=[];
    const response: any=await this.invoice.getGSTDropdown();
    if(response) {
      this.gstTaxCodeList=response.data as any;
    }
  }

  localGstValidation() {
    let local=this.newInvoiceForm.value.localGstAmount;
    if(this.newInvoiceForm.value.exchangeRate!==null) {
      let gst=this.newInvoiceForm.value.gstAmount*this.newInvoiceForm.value.exchangeRate;
      if(this.isCurrencyDifferent&&(local!=gst)) {
        Swal.fire({
          icon: 'warning',title: 'Warning',text: 'Your Local GST Amount is not equals to GST Amount multiply with Exchange Rate. Are you confirm to continue?',
          showCancelButton: true,confirmButtonText: 'Yes',cancelButtonText: 'No'
        }).then(result => {if(result.isConfirmed) {this.proceedWithSubmission();} })
      } else {this.proceedWithSubmission();}
    } else {this.proceedWithSubmission();}
  }

  getInvoiceDate() {
    console.log("Get Invoice date:"+this.f.invoiceDate.value);
  }

  clickOpenSupplierModal(template?: TemplateRef<any>) {
    // this.cancelChange = [...this.doList]
    let options: bootstrap.Modal.Options = {
      backdrop:'static',
      keyboard:true,
      focus:true
    }
    var myModal = new bootstrap.Modal(document.getElementById('doNoModal') as HTMLElement, options)
    myModal.toggle();
    
  }

}
