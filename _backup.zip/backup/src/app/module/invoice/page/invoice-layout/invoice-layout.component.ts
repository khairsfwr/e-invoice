import {Component,OnInit} from '@angular/core';
import {slideInAnimation} from '@app/animation';

@Component({
  selector: 'invoice-layout',
  templateUrl: './invoice-layout.component.html',
  styleUrls: ['./invoice-layout.component.scss'],
  animations: [
    slideInAnimation
  ]
})
export class InvoiceLayoutComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {
  }

}
