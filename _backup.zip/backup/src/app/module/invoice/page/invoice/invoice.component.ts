import { Component, OnInit } from '@angular/core';
import {invoiceDetails} from '../invoice-modal';
import {invoiceService} from '@app/_services/invoice-service';
import {FormBuilder,FormControl,Validators,FormGroup,FormArray} from '@angular/forms';
import {ToastrService} from 'ngx-toastr';
import {NgxSpinnerService} from 'ngx-spinner';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';
import {StorageService} from '@app/_services';
import {EKey} from '@app/_enum/storage-key';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent  extends invoiceDetails implements OnInit {


  addressBooksCode:any;
  constructor(private invoice: invoiceService, private fb: FormBuilder, public toastr: ToastrService, public spinner: NgxSpinnerService, private router: Router, private storage:StorageService) {
    super();
  }

  async ngOnInit() {
    await this.initForm();    
    let supplierInfo=JSON.parse(this.storage.getItem(EKey.supplierInfo)); 
    if(supplierInfo){
      this.newInvoiceForm.patchValue({ supplierName: supplierInfo.companyName, gstNo: supplierInfo.taxId })
      this.gstApplicable = (supplierInfo.taxId === null) ? true : false;
      this.addressBooksCode=supplierInfo.addressBooksCode;
      if(this.gstApplicable){
        this.gstPercentage = 0;
      }else{await this.getGstNo(this.addressBooksCode);}      
    }   
    await this.getPODetails();
    await this.getDisclaimer();
    await this.getGstTaxCode();    

    console.log(this.newInvoiceForm.controls.tableRow);
    
  }

  initForm() {
    this.newInvoiceForm = this.fb.group({
      supplierName: new FormControl({ value: '', disabled: true }, Validators.required),
      supplierCode: new FormControl(null),
      gstNo: new FormControl({ value: '', disabled: true }),
      poNo: [null, Validators.required],
      poType: [null, Validators.required],
      billTo: [null, Validators.required],
      location: new FormControl({ value: '', disabled: true }),
      doNo: [null, Validators.required],
      invoiceNo: [null, Validators.required],
      invoiceDate: [null, Validators.required],
      invoiceFile: [null, Validators.required],
      exchangeRate: null,
      netAmount: [null, Validators.required],
      gstAmount: [null, Validators.required],
      grossAmount: [null, Validators.required],
      localGstAmount: [null, Validators.required],
      desclaimer: new FormControl({value: '', disabled: true}),
      poCurrencyCode: null,
      companyCurrencyCode: null,
      gstTaxCode: [null, Validators.required],
      tableRow: this.fb.array([])
    });
  }

  get f() { return this.newInvoiceForm.controls }

  createSupportingDocumentObject(): FormGroup {
    return this.fb.group({
      attachmentName: new FormControl(null, [Validators.required]),
      documentName: new FormControl(null),
      description: new FormControl(''),
      file: new FormControl(null)
    });
  }
  get g() { return this.newInvoiceForm.controls.tableRow }

  get getTableControls() {
    return this.newInvoiceForm.get('tableRow') as FormArray;
  }

  async getCompanyCurrencyCode(companyCode: undefined, currencyCode: undefined) {
    let response: any = await this.invoice.getCompanyName(companyCode);
    if (response.data.companyCodeFrom){
      this.newInvoiceForm.patchValue({ companyCurrencyCode: response.data.companyCodeFrom, exchangeRate: (response.data.companyCodeFrom === currencyCode) ? 1 : null })
    }
    this.isCurrencyDifferent = (this.newInvoiceForm.value.companyCurrencyCode === currencyCode) ? false : true;
    console.log('is currency differ from po selected company currency code::', this.isCurrencyDifferent);
  }

  async getGstNo(code: any) {
    const response: any = await this.invoice.getGstNo(code);
    console.log("getGstNo:"+JSON.stringify(response));
    if (response) {
      this.gstPercentage = response.codeTableValue;
    }
  }

  async getPODetails() {
    // this.poList = [];
    // this.spinner.show();
    // this.poList = await this.invoice.getPoList(this.storage.getItem(EKey.loginUser));
    // this.poListCopy = this.poList;
    // this.spinner.hide();
    // console.log('Po Details:::::', this.poList);
  }

  async onSelectedPONo(event: any) {
    console.log('event of selected po method::', event)
    await this.clearValuesAfterChangingPONo();
    if (!event) { return }
    this.spinner.show();
    let billToCodeList: any[] = [];
    this.newInvoiceForm.patchValue({ poNo: event.purchaseOrderNo, exchangeRate: null });
    let poNo = this.newInvoiceForm.value.poNo;
    let locationCode:any, currencyCode:any, internalId:any;
    let compCode :any;
    console.log('po list in onSelectedPONo', this.poList);

    this.poList.forEach(item => {
      if (item.purchaseOrderNo === poNo) {
        this.supplierCode = item.supplierCode;
        this.poTypeList.push(item.orderType);        
        currencyCode = item.currencyCode;
        internalId = item.internalId;
        compCode = item.companyCode;

        billToCodeList.push(compCode as any);
      }
    })    
    locationCode = await this.getLocation(this.supplierCode, poNo);
    if(locationCode !== null){
      this.addNewDOButtonEnabled = locationCode === '01' ? false : true;
      this.getLocationName(locationCode);
    }else{this.addNewDOButtonEnabled = true}
    this.getDeliveryOrderList(internalId);
    sessionStorage.setItem('Selected PO Internal Id', internalId);
    sessionStorage.setItem('Supplier Company Code', compCode);
    this.newInvoiceForm.patchValue({ poCurrencyCode: currencyCode, doNo: null, supplierCode: this.supplierCode })
    await this.getCompanyCurrencyCode(compCode, currencyCode);
    (this.poTypeList.length == 1) ? this.newInvoiceForm.patchValue({ poType: this.poTypeList[0] }) : this.newInvoiceForm.patchValue({ poType: null });
    billToCodeList.forEach(element => {this.getCompanyName(element);});
    billToCodeList.length === 1 ? this.newInvoiceForm.patchValue({ billTo: compCode }) : '';
    this.spinner.hide();
  }

  onSelectPO($event:any) {
    let value = $event.target.value;
    if (!isNaN(value)) {
      this.poList = this.poListCopy.filter((x) => { return x.purchaseOrderNo.substring(0, value.length) == value });
      if (value.length == 0) {
        this.poList = Array.from(this.poListCopy);
      }
    }
  }

  async getLocation(supplierCode: any, poNo: any) {    
    const response:any = await this.invoice.getLocationCode(supplierCode, poNo);
    if(response.data !== null){
      return response.data.locationCode;      
    }
  }

  async getLocationName(locationCode: any){
    let result: any = await this.invoice.getLocation(locationCode);
    if (result.data !== null) {
      this.newInvoiceForm.patchValue({ location: result.data.name })
      this.spinner.hide();
    }
  }

  async getDisclaimer() {
    const response: any = await this.invoice.getDisclaimer('INV');
    if (response) {
      this.newInvoiceForm.patchValue({ desclaimer: response.codeTableValue })
    }
  }

  async getDeliveryOrderList(poId: undefined) {
    this.spinner.show();
    let deliveryOrderList = [];
    this.doList = [];
    const response:any = await this.invoice.getDoList(poId);
    this.spinner.hide();
    deliveryOrderList = (response as any)
    deliveryOrderList.forEach((item: {deliveryOrderNo: string; internalId: string;}) => {
      this.deliveryObject = { "doNo": '', "dosTrnDoHdrIid": '', checked: false, disabled: true };
      this.deliveryObject["doNo"] = item.deliveryOrderNo;
      this.deliveryObject["dosTrnDoHdrIid"] = item.internalId;
      this.doList.push(this.deliveryObject);
    })
  }

  async validateInvoiceNo() {
    this.spinner.show();
    let invoiceNo = this.newInvoiceForm.value.invoiceNo;
    const response:any = await this.invoice.invoiceNoValidation(invoiceNo, this.addressBooksCode);
    this.spinner.hide();
    if (response.message === 'invoiceNo duplicate') {
      this.newInvoiceForm.patchValue({ invoiceNo: null })
      Swal.fire({icon: 'error', text: 'Invoice number duplicated, please give another invoice number'})
    }
  }

  async getCompanyName(code: any) {
    this.billToList = [];
    let response: any = await this.invoice.getCompanyName(code);
    if (response) {
      this.lovObject["code"] = response.data.companyCode;
      this.lovObject["value"] = response.data.companyName;
      this.billToList.push(this.lovObject)
    }
  }

  // async getGstCheck(compCode) {
  //   this.spinner.show();
  //   const response: any = await this.invoice.getGstCode(compCode);
  //   if (response.data) {
  //     this.gstApplicable = (response.data.taxId === null) ? true : false;
  //     this.newInvoiceForm.patchValue({ supplierName: response.data.companyName, gstNo: response.data.taxId })
  //   }
  //   this.spinner.hide();
  // }

  onUploadedInvoiceFile(event:any) {
    this.spinner.show();
    console.log('lower case:', event.target.files[0].name.toString().toLowerCase())
    if (event.target.files[0].name.toString().toLowerCase().split('.').pop() == 'pdf') {
      if (this.isFileMoreThan10MB(event.target.files[0].size)) {
        this.toastr.error('Maximum allowed file size is 10MB');
      } else {
        let fileName = event.target.files[0].name.split('.').shift();
        this.newInvoiceForm.patchValue({ invoiceFile: fileName })
        this.invoiceFile = event.target.files[0]
        console.log('invoice file::::::::', this.invoiceFile)
        this.fileUploadLabel = true;
      }
    } else {
      Swal.fire({icon: 'error', text: 'Only pdf files are allowed'})
    }
    this.spinner.hide();
  }

  onDeleteInvoiceFile() {
    this.newInvoiceForm.patchValue({ invoiceFile: null })
    this.fileUploadLabel = false;
    this.invoiceFile = null;
    console.log('invoice file after deleted::::::::', this.invoiceFile)
  }

  async onSelectedCheckbox(item: any, event: any, index: any) {
    this.doValidationRequest = [];
    this.selectedDoList = [];
    if (event.target.checked) {
      if (item.doNo === '') {
        Swal.fire({ icon: 'error', text: 'Please provide DO No before selecting', confirmButtonText: 'OK' }).then((result) => { event.target.checked = false; })
      } else {
        this.doValidationRequest.push({ "doNumber": item.doNo, "supplierCode": sessionStorage.getItem('loginUser') })
        await this.validateSelectedDO(this.doValidationRequest, item, event, index);
      }
    } 
    for (let i = 0; i < this.doList.length; i++) {
      if (this.doList[i].checked) {
        this.selectedDoList.push(this.doList[i]);
      }
    }
    this.saveButtonOfDO = (this.selectedDoList.length > 0) ? false : true;
    console.log('selected do no list::::::', this.selectedDoList);
  }

  async validateSelectedDO(request: any[], item: any, event: {target: {checked: boolean;};}, i: number) {
    const response: any = await this.invoice.doNoValidation(request);
    if (response) {
      if (response.status == 200) {
        response.data.forEach((element: {status: string;}) => {
          if (element.status !== '00') {
            Swal.fire({icon: 'error', text: 'DO Number Duplicate, please select another'}).then((result) => {event.target.checked = false;})
            this.doList[i].checked = false;
          }
        })
      }
    }
  }

  async onChangeNetAmount() {
    console.log('gst percentage:::', this.gstPercentage);
    let net: any = parseFloat(this.newInvoiceForm.value.netAmount).toFixed(2)
    net = net.slice(0, 18)
    let gstAmount = (net * this.gstPercentage) / 100;
    console.log('gstAmount:::', gstAmount);
    this.newInvoiceForm.patchValue({ gstAmount: gstAmount, netAmount: net });
    this.onChangeGSTAmount();
    this.newInvoiceForm.patchValue({ netAmount: this.amountFormat(net) })
  }

  onChangeGSTAmount() {
    console.log('entered into onChangeGSTAmount')
    let gst: any = parseFloat(this.newInvoiceForm.value.gstAmount).toFixed(2);
    gst = gst.slice(0, 18)
    let amount: any = this.removeComma(this.newInvoiceForm.value.netAmount) + parseFloat(gst)
    amount = parseFloat(amount).toFixed(2);
    amount = amount.slice(0, 18)
    this.newInvoiceForm.patchValue({
      gstAmount: this.amountFormat(gst),
      grossAmount: this.amountFormat(amount),
      localGstAmount: (this.isCurrencyDifferent) ? '' : this.amountFormat(gst)
    })
  }

  onProvideLocalGstAmount() {
    let gst:any = parseFloat(this.newInvoiceForm.value.localGstAmount).toFixed(2);
    gst = gst.slice(0, 18)
    this.newInvoiceForm.patchValue({ localGstAmount: this.amountFormat(gst) })
  }

  addNewDocument() {
    let controls = this.newInvoiceForm.get('tableRow') as any;
    if (controls.valid) {
      this.getTableControls.push(this.createSupportingDocumentObject());
    } else {
      Swal.fire({icon: 'error', text: 'Please provide required information before adding a row'})
    }
  }

  onUploadedSupportingDocument(event: any) {
    this.spinner.show();
    let index: number = 0;
    for (let i = 0; i < event.target.files.length; i++) {
      if (event.target.files[i].name.toString().toLowerCase().split('.').pop() == 'pdf') {
        if (this.isFileMoreThan10MB(event.target.files[i].size)) {
          this.toastr.error('Maximum allowed file size is 10MB');
        } else {
          let tableForm = this.createSupportingDocumentObject();
          tableForm.patchValue({
            documentName: event.target.files[i].name.split('.').shift(),
            file: event.target.files[i]
          })
          this.getTableControls.push(tableForm);
        }
      } else {
        index = index + 1;
      }
    }
    if (index > 0) {
      Swal.fire({icon: 'error', text: 'Only pdf files are allowed'})
    }
    this.spinner.hide();
  }

  onDeleteSupportingDocument(i: number) {
    this.getTableControls.removeAt(i);
  }

  async submitNewInvoice() {
    this.isOnSubmit = false;
    this.supportingDocumentsList = [];    
    console.log('form::', this.newInvoiceForm)
    if (this.newInvoiceForm.invalid) {
      this.submitted = true
      return
    }
    this.getConfirmCancel(async ()=>{
      this.spinner.show();
      let isDuplicate: any = await this.checkDONoDuplication(this.selectedDoList);
      if (isDuplicate) {
        this.spinner.hide();
        // this.submitted = true;
        return Swal.fire({ icon: 'error', title: 'Error', text: 'Duplicate DO No will not allowed' });
      }
      let res: any = await this.grossAmountValidation();
      if (res.data == 1) {
        this.spinner.hide();
        Swal.fire({icon: 'warning',title: 'Warning',showCancelButton: true,confirmButtonText: `Confirm`,text: res.message}).then((result)=>{if(result.isConfirmed)this.localGstValidation()});
      }else{
        this.spinner.hide();
        this.localGstValidation();
      }
      return
    });
  }

  clearValuesAfterChangingPONo() {
    console.log('entered into clearValuesAfterChangingPONo method')
    this.billToList = [];
    this.supplierCode = null;
    this.poTypeList = [];
    this.doNoList = [];
    this.doList = [];
    this.selectedDoList = [];
    this.saveButtonOfDO = true;
    this.newInvoiceForm.patchValue({ billTo: null, location: null, poType: null, poCurrencyCode: null, doNo: null })
  }

  // insertDONo() {
  //   console.log('do list: ', this.doList);
  //   let value = this.prepareDoNoValue();
  //   this.newInvoiceForm.patchValue({ doNo: value })
  // }

  async grossAmountValidation() {
    let amount: any = this.removeComma(this.newInvoiceForm.value.grossAmount);
    let netAmount: any = this.removeComma(this.newInvoiceForm.value.netAmount);
    const response: any = await this.invoice.invoiceAmountValidation(sessionStorage.getItem('Supplier Company Code'), this.newInvoiceForm.value.poNo, amount, netAmount);
    return response;
  }

  async proceedWithSubmission(){
    this.isOnSubmit = true;   
    let attachmentNameArray: any[] = [];
    let descriptionArray: any[] = []; 
    this.spinner.show();
    let body = this.prepareBodyForSubmitInvoice(this.newInvoiceForm.value, null);
    console.log('new invoice request::', body);
    for (let i = 0; i < this.newInvoiceForm.value.tableRow.length; i++) {
      this.supportingDocumentsList.push(this.newInvoiceForm.value.tableRow[i].file);
      attachmentNameArray.push(this.newInvoiceForm.value.tableRow[i].attachmentName);
      descriptionArray.push(this.newInvoiceForm.value.tableRow[i].description ? this.newInvoiceForm.value.tableRow[i].description : '');
    }
    console.log('supporting document list::::', this.supportingDocumentsList);
    const response = await this.invoice.saveInvoiceDetails(body);
    if (response) {
      // this.spinner.show();     
      if (response.data.internalId !== null) {
        const result: any = await this.invoice.uploadingDocuments([this.invoiceFile], response.data.internalId, "InvoiceFile", [], []);
        if (result) {
          // this.spinner.hide();
          if (this.supportingDocumentsList.length > 0) {
            // this.spinner.show();
            const res: any = await this.invoice.uploadingDocuments(this.supportingDocumentsList, response.data.internalId, "attachments", [attachmentNameArray], [descriptionArray]);
            if (res) {
              this.spinner.hide();
              Swal.fire({ icon: 'success', text: 'Invoice Submitted Successfully' }).then((result) => {  this.router.navigateByUrl(this.router.url); })
            }
            this.spinner.hide();
          } else {
            this.spinner.hide();
            Swal.fire({ icon: 'success', text: 'Invoice Submitted Successfully' }).then((result) => {  this.router.navigateByUrl(this.router.url); })
          }
        }
      }
      this.spinner.hide();
    }
    this.spinner.hide(); this.isOnSubmit = false; 
  }

  onChangeExchangeRate(){
    let rate: any = parseFloat(this.newInvoiceForm.value.exchangeRate).toFixed(7)
    rate = rate.slice(0, 21)
    this.newInvoiceForm.patchValue({exchangeRate: this.amountFormat(rate)})
  }

  async getGstTaxCode(){
    this.gstTaxCodeList = [];
    const response:any = await this.invoice.getGSTDropdown();
    if(response){
      this.gstTaxCodeList = response.data as any;
    }
  }

  localGstValidation(){
    let local = this.newInvoiceForm.value.localGstAmount;
    if(this.newInvoiceForm.value.exchangeRate !== null){
      let gst = this.newInvoiceForm.value.gstAmount * this.newInvoiceForm.value.exchangeRate;
      if(this.isCurrencyDifferent && (local != gst)){
        Swal.fire({icon: 'warning', title: 'Warning', text: 'Your Local GST Amount is not equals to GST Amount multiply with Exchange Rate. Are you confirm to continue?',
              showCancelButton: true, confirmButtonText: 'Yes', cancelButtonText: 'No'}).then(result => {if(result.isConfirmed){this.proceedWithSubmission();}})
      }else{this.proceedWithSubmission();}
    }else{this.proceedWithSubmission();}    
  }

  getInvoiceDate(){
    console.log("Get Invoice date:"+this.f.invoiceDate.value);
  }

}
