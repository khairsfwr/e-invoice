import { FormGroup, Validators, FormControl } from "@angular/forms"
import * as moment from 'moment';
import {CommonSystem} from '@app/module/common/common-system';

export abstract class invoiceDetails extends CommonSystem{
    p: number = 1;
    poList: any [] = [];
    poListCopy: any [] = [];
    doList: any[] = [];
    poTypeList: any [] = [];
    billToList: any [] = [];
    newInvoiceForm!: FormGroup;
    gstApplicable: boolean = false;
    addNewDOButtonEnabled!: boolean;
    invoiceFile!: File | null; // variable for invoice upload 
 // variable for invoice upload 
    fileUploadLabel: boolean = false;
    doNoList: any[] = [];
    selectedDoList: any[] = [];
    deliveryObject = {
        "doNo": '',
        "dosTrnDoHdrIid": '',
        checked: false,
        disabled: true
    }
    supportingDocumentsList: any[] = [];
    showUpload: any[] = [];
    lovList: any[] = [];
    lovObject = {
        "code": '',
        "value": ''
    }
    submitted: boolean = false;
    supplierDetailsPanel!: boolean;
    invoiceHistoryList: any[] = [];
    invoiceHistoryListCopy: any[] = [];
    eventsList:any[] = [];
    gstPercentage: any;
    isCurrencyDifferent!: boolean;
    fileNames!: String;
    filesArray:any[]=[];
    doValidationRequest:any[]=[];
    saveButtonOfDO: boolean = true;
    statusList:any[] = [];
    currencyList:any[] = [];
    reasonForVoid:any;
    apOfficer!: boolean;
    manuallyMatchButton!: boolean;
    voidButton!: boolean;
    updateEventButton!: boolean;
    requestToVoidButton!: boolean;
    submitButton!: boolean;
    emailButton!: boolean;
    deleteButton: boolean = false;
    openDetailsButton: boolean = true;
    manuallyMatchReason: any;
    eventDescList: any[] = [];
    eventDesc:any;
    eventRemarks: any;
    invoiceNo: any;
    editInvoiceDetails: boolean = true;
    poListForInvoiceDetails: any[] = [];
    poListForInvoiceDetailsCopy: any[] = [];
    poTypeListForInvoiceDetails: any[] = [];
    billToListForInvoiceDetails: any[] = [];
    showDownload:any[] = [];
    downloadButton: boolean = false;
    role: any;
    status: any;
    gstTaxCodeList:any[] = [];
    acceptButton!: boolean;
    message:any;
    emailList:any[]=[];
    toCode:any;
    recipientList:any[]=[];
    supplierNameFromSelectedInvoice:any;
    isOnSubmit: boolean=false;
    eventType!: string;
    buyerCode!: string;
    filesToDelete: any[] = [];
    rejectedReason!: string;

    constructor(){
      super();
    }

    getInvoiceForm(){
        return {
            supplierName: [null, Validators.required],
            gstNo: null,
            poNo: [null, Validators.required],
            poType: [null, Validators.required],
            billTo: [null, Validators.required],
            location: null,
            doNo: [null, Validators.required],
            invoiceNo: [null, Validators.required],
            invoiceDate: [null, Validators.required],
            invoiceFile: [null, Validators.required],
            exchangeRate: [null, Validators.required],
            netAmount: [null, Validators.required],
            gstAmount: [null, Validators.required],
            grossAmount: [null, Validators.required],
            localGstAmount: [null, Validators.required],
            desclaimer: [null, Validators.required],
            poCurrencyCode: null,
            companyCurrencyCode: null
        }
    }

    buttonsVisibility(){
        this.role = sessionStorage.getItem('userRole');
        this.status = sessionStorage.getItem('statusOfSelectedInvoice');
        // this.apOfficer = (this.role === 'SUPPLIER') ? false : true;
        this.downloadButton = (this.role === 'inv_ap_officer' || this.role === 'inv_ap_supervisor' || this.role === 'inv_finance_owner' || this.role === 'inv_procurement_user') ? true : false;        
        if(this.role === 'inv_ap_officer' || this.role === 'inv_ap_supervisor'){
          this.emailButton = true;
          this.manuallyMatchButton = (this.status === 'No Match') ? true : false;
          this.voidButton = (this.status !== 'Void' && this.status !== 'Paid') ? true : false;
          this.updateEventButton = (this.status === 'No Match') ? true : false;
        }else if(this.role === 'SUPPLIER'){
          this.requestToVoidButton = (this.status === 'Rejected' || this.status === 'Accepted') ? true : false;
          this.submitButton = (this.status === 'Rejected') ? true : false;
          this.editInvoiceDetails = (this.status === 'Rejected') ? false : true;
          this.deleteButton = (this.status === 'Rejected') ? true : false;
          this.downloadButton = (this.status === 'Pending' || this.status === 'Pending Verification' || this.status === 'Rejected') ? true : false;
          this.emailButton = true;
        }else if(this.role === 'inv_procurement_user' || this.role === 'inv_qaqc_user' || this.role === 'inv_end_user' || this.role === 'inv_warehouse_user'){
          this.updateEventButton = (this.status === 'No Match') ? true : false;
          this.emailButton = true;
        }
        this.supplierDetailsPanel = true;
    }

    prepareBodyForSubmitInvoice(obj: {supplierName: any; supplierCode: any; gstNo: any; poNo: any; poType: any; billTo: any; location: any; invoiceNo: string; invoiceDate: any; exchangeRate: any; netAmount: any; gstAmount: any; grossAmount: any; localGstAmount: any; gstTaxCode: any;}, internalId: null){
        return {
            "internalId": internalId, 
            "supplierName" : obj.supplierName,
            "supplierCode" : obj.supplierCode,
            "gstNo" : obj.gstNo,
            "cmnPurchaseOrdersIID" : sessionStorage.getItem('Selected PO Internal Id'),
            "poNo" : obj.poNo,
            "poType" : obj.poType,
            "billTo" : obj.billTo,
            "location" : obj.location,
            "doNo" : this.selectedDoList,
            "invoiceNo" : (obj.invoiceNo as string).toUpperCase().trim(),
            "invoiceDate" : this.getDateFormatYYYYMMDD(obj.invoiceDate),
            "exchangeRate" : obj.exchangeRate ? this.removeComma(obj.exchangeRate) : null,
            "netAmount" : this.removeComma(obj.netAmount),
            "gstAmount" : this.removeComma(obj.gstAmount),
            "grossAmount" : this.removeComma(obj.grossAmount),
            "localGstAmount" : this.removeComma(obj.localGstAmount),
            "gstTaxCode": obj.gstTaxCode,
            "gst": this.gstPercentage,
            "submittedBy": sessionStorage.getItem('loginUser'),
            "submissionDate": this.getDateFormatYYYYMMDD(new Date()),
        }
    }

    addNewRow(){
      this.doList.push({"doNo": '', "dosTrnDoHdrIid": '', checked: false, disabled: false});
    }

    valueChangeEvent(item: {checked: any;}, i: number){
      console.log('do object after value change', item)
      if(item.checked){
        this.doList.splice(i, 1, item);
        console.log('do list after replacing', this.doList)
      }
    }



    async prepareBodyForInvoiceSearch(obj: {poNo: {purchaseOrderNo: any;}; poType: any; poCurrencyCode: any; doNo: any; jobNo: any; submissionFromDate: any; submissionToDate: any; invoiceFromDate: any; invoiceToDate: any; invoiceNo: any; status: any;}, suppliers: any, pipe: {transform: {(arg0: any,arg1: string): void; (arg0: any,arg1: string): void; (arg0: any,arg1: string): void; (arg0: any,arg1: string): void;};}){
      return {
        "suppliers": suppliers,
        "poNo": (obj.poNo) ? obj.poNo.purchaseOrderNo : '', 
        "poType": (obj.poType) ? obj.poType : '', 
        "poCurrencyCode": (obj.poCurrencyCode) ? obj.poCurrencyCode : '',
        "doNo": (obj.doNo) ? obj.doNo : '',
        "jobNo": (obj.jobNo) ? obj.jobNo : '',
        "submissionDateFrom": (obj.submissionFromDate) ? pipe.transform(obj.submissionFromDate, 'yyyy-MM-dd') : '',
        "submissionDateTo": (obj.submissionToDate) ? pipe.transform(obj.submissionToDate, 'yyyy-MM-dd') : '',        
        "invoiceDateFrom": (obj.invoiceFromDate) ? pipe.transform(obj.invoiceFromDate, 'yyyy-MM-dd') : '',
        "invoiceDateTo": (obj.invoiceToDate) ? pipe.transform(obj.invoiceToDate, 'yyyy-MM-dd') : '',
        "invoiceNo": (obj.invoiceNo) ? obj.invoiceNo : '',
        "status": (obj.status) ? obj.status : '',
        "userRole": sessionStorage.getItem('userRole'),
        "searchCon": (obj.status) ? obj.status : '' 
      }
    }   

    prepareTableDataForExportExcel(){
      this.invoiceHistoryListCopy = [];
      this.invoiceHistoryList.forEach(item => {
        this.invoiceHistoryListCopy.push({
          "Supplier Name": item.supplierName,
          "GST No.": item.gstNo,
          "PO No.": item.poNumber,
          "PO Type": item.poType,
          "Bill To": item.billTo,
          "Location": item.location,
          "DO No.": item.doNo,
          "Invoice No.": item.invoiceNo,
          "Invoice Date": item.inoiceDate,
          "Currency Code": item.poCurrencyCode,
          "Net Amount": item.invoiceData.netAmount,
          "Gross Amount": item.invoiceData.grossAmount,
          "GST Amount": item.invoiceData.gstAmount,
          "Local GST Amount": item.invoiceData.localGstAmount,
          "Exchange Rate": item.invoiceData.exchangeRate
        })
      });
    }

    checkDONoDuplication(list: any[]){
      let uniqueSet = list.reduce((arr: any[], item: {doNo: {toString: () => {toUpperCase: () => void;};};})=>{
        let exist = !!arr.find((x: {doNo: {toString: () => {toUpperCase: () => void;};};}) => x.doNo.toString().toUpperCase() === item.doNo.toString().toUpperCase());
        if(!exist){arr.push(item)};
        return arr;
      }, []);
      if(uniqueSet.length < list.length){
        return true;
      }
      return
    }

    async prepareBodyForInvoiceVerificationSearch(obj:any, suppliers: any, pipe: {transform: {(arg0: any,arg1: string): void; (arg0: any,arg1: string): void; (arg0: any,arg1: string): void; (arg0: any,arg1: string): void;};}){
      return {
        "suppliers": suppliers,
        "poNo": (obj.poNo.value) ? obj.poNo.value.purchaseOrderNo : '', 
        "poType": (obj.poType.value) ? obj.poType.value : '', 
        "poCurrencyCode": (obj.poCurrencyCode.value) ? obj.poCurrencyCode.value : '',
        "doNo": (obj.doNo.value) ? obj.doNo.value : '',
        "jobNo": (obj.jobNo.value) ? obj.jobNo.value : '',
        "submissionDateFrom": (obj.submissionFromDate.value) ? pipe.transform(obj.submissionFromDate.value, 'yyyy-MM-dd') : '',
        "submissionDateTo": (obj.submissionToDate.value) ? pipe.transform(obj.submissionToDate.value, 'yyyy-MM-dd') : '',        
        "invoiceDateFrom": (obj.invoiceFromDate.value) ? pipe.transform(obj.invoiceFromDate.value, 'yyyy-MM-dd') : '',
        "invoiceDateTo": (obj.invoiceToDate.value) ? pipe.transform(obj.invoiceToDate.value, 'yyyy-MM-dd') : '',
        "invoiceNo": (obj.invoiceNo.value) ? obj.invoiceNo.value : '',
        "status": (obj.status.value) ? obj.status.value : '',
        "userRole": sessionStorage.getItem('userRole'),
        "searchCon": (obj.status.value) ? obj.status.value : '' 
      }
    }
    
}