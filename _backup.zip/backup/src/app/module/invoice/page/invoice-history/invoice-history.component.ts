import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-history',
  templateUrl: './invoice-history.component.html',
  styleUrls: ['./invoice-history.component.scss']
})
export class InvoiceHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
