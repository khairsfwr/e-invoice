import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SupportRoutingModule } from './support-routing.module';
import { HelpComponent } from './page/help/help.component';
import { WelcomeComponent } from './page/welcome/welcome.component';
import { AboutComponent } from './page/about/about.component';


@NgModule({
  declarations: [
    HelpComponent,
    WelcomeComponent,
    AboutComponent
  ],
  imports: [
    CommonModule,
    SupportRoutingModule
  ]
})
export class SupportModule { }
