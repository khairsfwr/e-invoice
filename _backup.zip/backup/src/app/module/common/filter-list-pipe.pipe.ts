import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterListPipe'
})
export class FilterListPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    console.log("Fired");
  }

}
