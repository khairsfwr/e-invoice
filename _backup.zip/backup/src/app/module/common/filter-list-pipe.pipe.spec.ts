import { FilterListPipe } from './filter-list-pipe.pipe';

describe('FilterListPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterListPipe();
    expect(pipe).toBeTruthy();
  });
});
