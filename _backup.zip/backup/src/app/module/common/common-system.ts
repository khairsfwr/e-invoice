import * as moment from 'moment';
import Swal from 'sweetalert2';

export class CommonSystem{
    supplierWatchListCheckbox:boolean = false;
    supplierCode: any;
    supplierName: any;
    match: any;
    selectedSuppliers: any[] = [];
    checkList:any[] = [];
    saveButton: boolean = true;
    q:number = 0;
    allSupplierList: any[] = [];
    copyOfAllSupplierList: any[] = [];
    watchList:number = 0;
    allSuppliersApiCalled:boolean = false;
    allSupplierListStorage:any[] = [];
    getSupplierObject() {
        return {
         "addressBooksCode": '',
         "companyName": ''
        }
    }

    constructor() {}

    onSelectedSupplierWatchList(event:any){
        this.supplierWatchListCheckbox = event.target.checked ? true : false;
        this.watchList = event.target.checked ? 1 : 0;
        console.log('Supplier watch list check box:', this.supplierWatchListCheckbox);
    }    

    resetSupplierSearchValues(){
        this.match = null;
        this.supplierCode = null;
        this.supplierName = null;
    }

    onSelectedCheckbox(item:any, event:any, index:any){
      // this.selectedSuppliers = [];
        console.log('selected supplier object:::::', item);
        console.log('selected checkbox event:::::', event);
        let obj = this.getSupplierObject();
        obj["addressBooksCode"] = item.addressBooksCode;
        obj["companyName"] = item.companyName;
        if(event.target.checked){
            console.log('entered into checked condition')
            this.selectedSuppliers.push(item);
            this.checkList[item.addressBooksCode] = true;
        }else{
            console.log('entered into un checked condition')
            this.checkList[item.addressBooksCode] = false;
            for(let i=0; i<this.selectedSuppliers.length; i++){
            if(this.selectedSuppliers[i].addressBooksCode === item.addressBooksCode)
                this.selectedSuppliers.splice(i--, 1);
            }
        }
        this.saveButton = (this.selectedSuppliers.length > 0) ? false : true;    
        console.log('supplier list::::::', this.selectedSuppliers);
    }

    resetSelectedSuppliers(){
        this.selectedSuppliers = [];
        this.checkList = [];
        this.saveButton = true;
    }
    
    filterStartsWith(letter:any){
        console.log('enetered into filterStartsWith method', letter)
        this.q = 1;
        this.allSupplierList = this.copyOfAllSupplierList;
        this.allSupplierList = this.allSupplierList.filter(each => String(each.companyName).startsWith(letter))
        console.log('supplier list after filtered::::', this.allSupplierList)
    }

    amountFormat(amount:any){
        console.log('enter into amountFormat method and the amount is', amount)
        let toString = amount + ''
        let remain = ''
        if(toString.includes('.')){
          remain = '.' + toString.split('.')[1]
          toString = toString.split('.')[0]
        }
        let convertString = ''
        let stringLength = toString.length
        while(stringLength >= 0){
          if(stringLength === toString.length){
            if(stringLength > 3){
              convertString = ',' + toString.substring(stringLength - 3, stringLength)
            }else{
              convertString = toString
            }
            stringLength -= 3
          }else if((stringLength - 3) <= 0){
            convertString = toString.substring(0, stringLength) + convertString
            stringLength -= 3
          }else{
            convertString = ',' + toString.substring(stringLength - 3, stringLength) + convertString
            stringLength -= 3
          }
        }
        console.log('amount after conversion:::', convertString + remain)
        let stringAmount = convertString + remain
        return stringAmount
    }

    removeComma(amount:any){
        console.log('amount after remove of comma', amount)
        return parseFloat(amount.toString().replace(/,/g, ''));
    }

    isFileMoreThan10MB(size:any){
        if(size > 10485760)
          return true;
        else
          return false;
    }

    getDateFormatYYYYMMDD(date:any){
      // 2022-11-24T16:00:00.000Z
      console.log("date:",date);
      return moment(date).format('YYYY-MM-DD');
    }

    sortDateFormatYYYYMMDD(date1:string,date2:any){
      var split1=date1.split('.');
      var split2=date2.split('.');
      var date1compare=split1[2]+split1[1]+split1[0];
      var date2compare=split2[2]+split2[1]+split2[0];
      return (date1compare>date2compare? 1:-1)
    }

    deleteAll(){
      return null;
    }

    getConfirmCancel(callback:Function){
      Swal.fire({
        icon:`warning`,
        title:`Submit`,
        text:`Do you want to save the changes?`,
        showDenyButton: false,
        showCancelButton: true,
        confirmButtonText: `Save`,
        denyButtonText: `Don't save`,
      }).then(async (result:any) => {
        /* Read more about isConfirmed, isDenied below */
        if(result.isConfirmed) {
          callback();
        } else if(result.isDenied) {
          Swal.fire('Changes are not saved','','info')
        }
      });
    }
}