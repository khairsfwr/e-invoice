import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './_helpers';
import { PagenotfoundComponent } from './module/support/page/pagenotfound/pagenotfound.component';
import {ERole} from './_models';

// import { WelcomeComponent } from './module/support/page/welcome/welcome.component';


const homeModule = () => import('./module/home/home.module').then(m => m.HomeModule);
const invoiceModule = () => import('./module/invoice/invoice.module').then(m => m.InvoiceModule);
const developerModule = () => import('./module/_private-developer-only/private-developer-only.module').then(m => m.PrivateDeveloperOnlyModule);
const authModule = () => import('./module/auth/auth.module').then(m => m.AuthModule);
const supportModule = () => import('./module/support/support.module').then(m => m.SupportModule);

const routes: Routes = [
  { path: '', loadChildren: homeModule, canActivate: [AuthGuard]},
  { path: 'invoice', loadChildren: invoiceModule, canActivate: [AuthGuard]},
  { path: 'developer', loadChildren: developerModule, canActivate: [AuthGuard]  },
  { path: 'support', loadChildren: supportModule },
  { path: 'security', loadChildren: authModule },
  // { path: 'init', pathMatch: 'full', component: InitializeComponent },
  
  //Wild Card Route for 404 request
  { path: '**', pathMatch: 'full', component: PagenotfoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
