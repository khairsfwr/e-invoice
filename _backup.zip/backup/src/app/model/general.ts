export interface UserInfo {
    username?: string,
    disciplineId?: any,
    disciplineCodeValue?: any,
    disciplineCodeName?: string,
    discipline$?: any[],
    role?: any[],
    // role?: string[],
    loginUser?: string,
    userId?: any,
    codeValue?:string,
    departmentCodeList?:any[],
    departmentList?:any[],
    employeeNo?:any,
    isUserHasDisc?:boolean
    defaultDisc?:boolean//if user has only one
    jwtToken?: string;
  }



