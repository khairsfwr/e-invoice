import { ITQtqDtl } from "./tq";

export interface IWorkFlow {
    workFlowHdr: Partial<IWorkFlowHdr>,
    workFlowHdrList: Partial<IWorkFlowHdr>[],
    workFlowDtlList: Partial<IWorkFlowDtl>[],
    tqDtlList: Partial<ITQtqDtl>[],
    /**The current process/ This variable is to track the log and access in system*/
    userFlowRow?:Partial<IWorkFlowDtl>
    // userFlowRowCL?:Partial<IWorkFlowDtl> // add this because have some trouble with the additional requirement
    nextUserFlowRow?:Partial<IWorkFlowDtl>
}

export interface IWorkFlowHdr {
    "internalId": number,
    "dcnId": {
        "internalId": 663,
        "dcnNo": "DCN-09J110014-00166",
        "projectCode": "09J110014",
        "status": "Pending acceptance and approval",
        "leadEngineer": "DCM_ENG_LEAD_E",
        "leadDiscipline": "ECIT",
        "mCodeCategory": {
            "internalId": 202,
            "codeType": "Source",
            "codeValue": "B",
            "codeName": "BFE VENDOR AND NON-COMPLIANCE",
            "codeSequence": 0,
            "codeDesc": null,
            "codeValue2": null,
            "codeValuec3": null,
            "codeValue4": null,
            "codeRadio1": 0,
            "codeRadio2": 1,
            "codeRadio3": 0,
            "codeRadio4": 0,
            "codeRadio5": 0,
            "status": 1,
            "rowStatus": 0,
            "rowVersion": 0,
            "createdBy": "dcm_eng_lead_p",
            "createdOn": "2021-06-27T04:21:59.000+00:00",
            "modifiedBy": "dcm_eng_lead_p",
            "modifiedOn": "2021-08-27T02:52:37.000+00:00",
            "projectCode": null
        },
        "category": 202,
        "origin": 484,
        "requestor": "Requestor",
        "tqIid": null,
        "tqId": null,
        "crId": null,
        "crIid": null,
        "engVariationOrder": "0",
        "engImpactList": "1",
        "receiptDate": "2021-06-28T16:00:00.000+00:00",
        "subject": "dadd",
        "originalDesignShortDesc": "dasdsad",
        "designChangeShortDesc": "asd",
        "impactDesc": null,
        "expectedCompDate": null,
        "rowStatus": 0,
        "rowVersion": 0,
        "createdBy": "dcm_eng_lead_e",
        "createdOn": "2021-06-29T09:41:30.000+00:00",
        "modifiedBy": "dcm_con_mgr",
        "modifiedOn": "2021-10-07T01:18:32.000+00:00",
        "holdOn": null,
        "voidOn": null,
        "closeOn": null,
        "holdComment": null,
        "voidComment": null,
        "closeComment": null,
        "approvedOn": null,
        "finalCloseOn": null,
        "evoEilNo": null,
        "chargableToClient": null,
        "requireQAQCAcceptance": 0,
        "critical": null,
        "chargableToVendor": null
    },
    "crId": null,
    "crIid": null,
    "tqDtlId": number,
    "dcnIid": 663,
    "flowStartDate": Date,
    "flowEndDate": Date,
    "isLatest": number,
    "rowStatus": 0,
    "rowVersion": 0,
    "createdBy": "dcm_eng_lead_e",
    "createdOn": "2021-10-06T12:07:33.000+00:00",
    "modifiedBy": "dcm_con_mgr",
    "modifiedOn": "2021-10-07T01:18:32.000+00:00",
    "status": string
}

export interface IWorkFlowDtl {
    "internalId": number,
    "workFlowHdrId": IWorkFlowHdr,
    "workFlowHdrIid": number,
    "approverRole": string,
    "sequence": number,
    "status": string,
    "approvedBy": string,
    "approvalOn": Date,
    "comments": string,
    "rowStatus": number,
    "rowVersion": number,
    "createdBy": string,
    "createdOn": string,
    "modifiedBy": string,
    "modifiedOn": string
    "discipline": string,
    "isLatest": number,
    "acknowledgeBy": string,
    "acknowledgeOn": Date,
    "entryBy": string,
    "entryOn": Date
    "actualEffortUpdatedOn": string,
    "type": string,

    revisionNum?: number
}

export interface IWorkFlowHdrId {
    workFlowHdrId: any;
}

/**ALL module have some workflow**/