export interface IDCNChanges {

  discipline: string;
  predecess: string;
  drawingNo: any;
  drawingTitle: string;
  revNo: string;
  procurementType: string;
  packageName: string;
  vcd: string;
  megaBlock: string;
  contructionBlock: string;
  compartment: string;
  location: string;
  externalParty: string | any;
  type: string;

  isNew?: boolean;
  isErr?: any;
  completeStatus?:any;
  dcnId?:any;
  internalId?:any;

}
