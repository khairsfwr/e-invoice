/**Form control for tq form */
export interface IFCTQ {
    "clientName": string, // refer to To
    "affectedDiscipline": string,
    "closureIssuedOn": string,
    "critical": number,
    "discipline": string,
    // "employeeNum": string,
    "fromEmpNum": string,
    "issueDate": string,
    "pmoInvolvement": number,
    "projectcode": string,
    "replyDueDate": string,
    "requestor": string,
    "status": string,
    "subject": string,
    "tqNo": string,
    "revisionNum": number,
    "clientNo": string,
    "clientRev": string,
}