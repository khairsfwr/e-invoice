export interface IDCNImpact {
  title: string;
  background: string;
  discipline: string;
  materialDesc: string;
  quantity: string;
  weight: string;
  unit: string;
  specCode: string;
  softwareStudy: string;
  manDay: string;
  manHour: string;
  travelAdmin: string;
  description: string;
  designation: string;
  drawingTsNo: any;
  drawingTitle: string;
  duration: string;
  type: string;
  
  dcnId?:any;
  internalId?:any;
  isNew?: boolean;
}
