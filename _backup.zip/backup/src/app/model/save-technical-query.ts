export interface ISaveTQ {
    tq: {
      closeComment: string,
      closeOn: string,
      closureIssuedBy: string,
      closureIssuedOn: string,
      createdBy: string,
      createdOn: string,
      discipline: string,
      employeeNum: string,
      fromEmpNum: string,
      modifiedBy: string,
      modifiedOn: string,
      projectCode: string,
      requestor: string,
      rowStatus: number,
      rowVersion: number,
      status: string,
      tqNo: string,
      voidComment: string,
      voidOn: string
    },
    tqCommnent: [
      {
        commentDesc: string,
        createdBy: string,
        createdOn: string,
        discipline: string,
        modifiedBy: string,
        modifiedOn: string,
        rowStatus: number,
        rowVersion: number,
        tqDtl: number
      }
    ],
    tqDtl: [
      {
        affectedDiscipline: string,
        createdBy: string,
        createdOn: string,
        critical: number,
        dcModifiedBy: string,
        dcModifiedOn: string,
        issueDate: string,
        issuedBy: string,
        modifiedBy: string,
        modifiedOn: string,
        pmoInvolvement: number,
        replyDate: string,
        replyDueDate: string,
        responder: string,
        revisionNum: number,
        rowStatus: number,
        rowVersion: number,
        subject: string,
        tqId: number
      }
    ]
}