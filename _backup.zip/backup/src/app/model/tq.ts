/**saveTechnicalQuery */
export interface ITQ {
    tq: Partial<ITQtq>,
    tqCommnent: Partial<ITQtqCommnent>[],
    tqDtl: Partial<ITQtqDtl>[],

    technicalQueryDetailComment?: Partial<ITQtqCommnent>[],
    technicalQueryDetail?: Partial<ITQtqDtl>[],
    technicalQuery?: Partial<ITQtq>

    TechnicalQueryCommentFileDetails?:  Partial<SPFile>[]
    TechnicalQueryFileDetails?:  Partial<SPFile>[]
    TechnicalQueryResponseFileDetails?:  Partial<SPFile>[]
}
export interface ITQtq {
    internalId?: number,
    closeComment: string,
    closeOn: Date,
    closeBy: string,
    closureIssuedBy: string,
    closureIssuedOn: Date,
    createdBy: string,
    createdOn: string,
    discipline: string,
    employeeNum: string,
    fromEmpNum: string,
    modifiedBy: string,
    modifiedOn: string,
    projectCode: string,
    requestor: string,
    rowStatus: number,
    rowVersion: number,
    status: string,
    tqNo: string,
    voidComment: string,
    voidOn: Date,
    clientNo: string,
    clientRev: string,
    tqCommencement: number
}

export interface ITQtqCommnent {
    commentDesc: string,
    createdBy: string,
    createdOn: string,
    discipline: string,
    modifiedBy: string,
    modifiedOn: string,
    rowStatus: number,
    rowVersion: number,
    tqDtl: number,

    /**needed in UI */
    revisionNum?: number,
    techQueryDtl?: ITQtqDtl,
    internalId?: number,
    checkFlag?: boolean,
    File?: File
    commentFile?: string
    disabledFlag?: boolean
}

export interface ITQtqDtl {
    internalId?: number,
    affectedDiscipline: string,
    createdBy: string,
    createdOn: string,
    critical: number,
    dcModifiedBy: string,
    dcModifiedOn: string,
    issueDate: string,
    issuedBy: string,
    modifiedBy: string,
    modifiedOn: Date,
    pmoInvolvement: number,
    replyDate: string,
    replyDueDate: string,
    responder: string,
    revisionNum: number,
    rowStatus: number,
    rowVersion: number,
    subject: string,
    tqId: number

   /**needed in UI */
   File?: any
}

/**saveTQDcnReq */
export interface ITQDCNReq {
    internalId: number,
    tqIID: number,
    status: string,
    discipline: string,
    approvedBy: string,
    approvedOn: Date,
    comments: string,
    rowStatus: number
    rowVersion: number,
    createdBy: string,
    createdOn: Date,
    modifiedBy: string,
    modifiedOn: Date

    dcnStatus?: string

}

export interface IWIPFileRes {
    "TQNoValidation": "Pass",
    "FromValidation": "Pass",
    "OriginatorValidation": "Pass",
    "DisciplineValidation": "Pass",
    "SubjectValidation": "Pass"
}


export interface SPFile {
    applicationId: string
    applicationName: "DCM"
    applicationPageId: "TQ_Comment"
    coverPageId: null
    cratedOn: "2021-12-13T07:45:49.000+00:00"
    createdBy: null
    docOwner: "svc_11_dev_dcm"
    docType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    fileId: "8c37dc25-c69a-4b9c-bd8a-e9fffef262a4"
    fileName: "TQ File(WIP) Templete (1)_211213154547.docx"
    folderId: "af6b9608-61ea-4950-a67e-0b72e7288dfd"
    folderName: "/Shared Documents/dcm/tq"
    internalId: number
    modifiedBy: null
    modifiedOn: null
    newIndicator: 0
    originalFileName: "TQ File(WIP) Templete (1).docx"
    path: "/sites/BespokeNon-ProdDocuments/Shared Documents/dcm/tq/TQ File(WIP) Templete (1)_211213154547.docx"
    revision: "1.0"
    rowStatus: 0
    rowVersion: 0
    sequence: 0
    url: "https://sembmarine.sharepoint.com"
}