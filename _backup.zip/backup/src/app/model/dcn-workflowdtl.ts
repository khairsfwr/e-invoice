import { IDCNWorkflowhdr } from "./dcn-workflowhdr";

export interface IDCNWFDtl {
	"internalId": number,
	"workFlowHdrId": IDCNWorkflowhdr,
	"workFlowHdrIid": number,
	"approverRole": string,
	"sequence": number,
	"status": string,
	"approvedBy": string,
	"approvalOn": Date,
	"comments": string,
	"rowStatus": number,
	"rowVersion": number,
	"createdBy": string,
	"createdOn": string,
	"modifiedBy": string,
	"modifiedOn": string
	"discipline": string,
	"isLatest": number,
	"acknowledgeBy": string,
	"acknowledgeOn": null,
	"entryBy": string,
	"entryOn": string
	"actualEffortUpdatedOn": string,
	"type": string
}