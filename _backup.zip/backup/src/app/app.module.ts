import {NgModule,APP_INITIALIZER} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

// used to create fake backend
import {fakeBackendProvider} from './_helpers';

import {AppRoutingModule} from './app-routing.module';

import {AppComponent} from './app.component';
import {ArchitectuiSidebarComponent} from './layout/architectui-sidebar/architectui-sidebar.component';

import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
import {appInitializer,JwtInterceptor,ErrorInterceptor} from './_helpers';
import {AccountService, StorageService} from './_services';
import {AlertComponent} from './_components';
import {HeaderComponent} from './layout/header/header.component';
import {FooterComponent} from './layout/footer/footer.component';
import {SidebarComponent} from './layout/sidebar/sidebar.component';
import {CodinglabSidebarComponent} from './layout/codinglab-sidebar/codinglab-sidebar.component';
import {PrivateComponent} from './layout/private/private.component';
import {FormsModule} from '@angular/forms';
import {ProjectList} from './_components/project-list.component';
import {LoaderCustome} from './_components/loader.component';
import {ModalModule} from 'ngx-bootstrap/modal';
import {ModalComponent} from './_components/modal/modal.component';
import {FormComponent} from './_components/form/form.component';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {ButtonsModule} from 'ngx-bootstrap/buttons';
import {ShareModule} from './share/share.module';
import { SearchComponent } from './_components/search/search.component';
import { ToastsComponent } from './_components/toasts/toasts.component';
import {SupplierDialogComponent} from './share/supplier-dialog/supplier-dialog.component';
import {NgxPaginationModule} from 'ngx-pagination';
import {ToastrModule} from 'ngx-toastr';
import { DataTablesModule } from 'angular-datatables';
import {NgxSpinnerModule} from 'ngx-spinner';
import { LayoutThemeOneComponent } from './layout/layout-theme-one/layout-theme-one.component';

@NgModule({
  declarations: [
    AppComponent,
    ArchitectuiSidebarComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    CodinglabSidebarComponent,
    PrivateComponent,
    ProjectList,
    ModalComponent,
    FormComponent,
    SearchComponent,
    ToastsComponent,
    LayoutThemeOneComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ModalModule.forRoot(),
    TooltipModule.forRoot(),
    NgxPaginationModule,
    ToastrModule.forRoot({
      positionClass :'toast-bottom-right'
    }),
    DataTablesModule,
    ShareModule
  ],
  providers: [
    {provide: APP_INITIALIZER,useFactory: appInitializer,multi: true,deps: [AccountService,StorageService]},
    {provide: HTTP_INTERCEPTORS,useClass: JwtInterceptor,multi: true},
    {provide: HTTP_INTERCEPTORS,useClass: ErrorInterceptor,multi: true},

    // provider used to create fake backend
    // fakeBackendProvider  // - developement only
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
