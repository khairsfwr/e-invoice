import { trigger, transition, style, animate, query, animateChild, group } from '@angular/animations';

// export const slideInAnimation =
//   trigger('routeAnimations', [
//     transition('HomePage <=> AboutPage', [
//       style({ position: 'relative' }),
//       query(':enter, :leave', [
//         style({
//           position: 'absolute',
//           top: 0,
//           left: 0,
//           width: '100%'
//         })
//       ]),
//       query(':enter', [
//         style({ left: '-100%' })
//       ]),
//       query(':leave', animateChild()),
//       group([
//         query(':leave', [
//           animate('300ms ease-out', style({ left: '100%' }))
//         ]),
//         query(':enter', [
//           animate('300ms ease-out', style({ left: '0%' }))
//         ]),
//       ]),
//     ]),
//     transition('* <=> *', [
//       style({ position: 'relative' }),
//       query(':enter, :leave', [
//         style({
//           position: 'absolute',
//           top: 0,
//           left: 0,
//           width: '100%'
//         })
//       ]),
//       query(':enter', [
//         style({ left: '-100%' })
//       ]),
//       query(':leave', animateChild()),
//       group([
//         query(':leave', [
//           animate('200ms ease-out', style({ left: '100%', opacity: 0 }))
//         ]),
//         query(':enter', [
//           animate('300ms ease-out', style({ left: '0%' }))
//         ]),
//         query('@*', animateChild())
//       ]),
//     ])
//   ]);

export const slideInAnimation =
  trigger('routeAnimations', [
    transition(':enter', [
      style({
        opacity: 0,
        transform: 'scale(0.5)'
      }),
      animate('250ms 125ms ease-out')
    ]),
    transition(':leave', [
      animate(125, style({
        opacity: 0,
        transform: 'scale(0.5)'
      }))
    ])
  ]);

  export const slideInOutAnimation = 
  trigger('routeSecondAnimations', [
    transition(':enter', [
      style({ transform: 'translateX({{direction}}%)' }),
      animate('400ms ease-in', style({ transform: 'translateX(0%)' })),
    ]),
  ]);