import {Component} from "@angular/core";

@Component({
  selector: 'loader',
  // templateUrl: './loader.component.html',
  // styleUrls:['./loader.component.scss']
  template:
    `
<div class="loader">
  <div class="inner one"></div>
  <div class="inner two"></div>
  <div class="inner three"></div>
</div>

`,
  styles: [
    `
    html {
      height: 100%;
    }
    
    body {
      /* background-image: radial-gradient(circle farthest-corner at center, #3C4B57 0%, rgb(255, 255, 255) 100%); */
    }
    
    .loader {
      position: relative;
      top: calc(50% - 32px);
      left: 0;
      width: 1rem;
      height: 1rem;
      border-radius: 50%;
      perspective: 800px;
    }
    
    .inner {
      position: absolute;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      border-radius: 50%;
    }
    
    .inner.one {
      left: 0%;
      top: 0%;
      animation: rotate-one 1s linear infinite;
      border-bottom: 3px solid rgb(153, 250, 193);
    }
    
    .inner.two {
      right: 0%;
      top: 0%;
      animation: rotate-two 1s linear infinite;
      border-right: 3px solid rgb(50, 241, 107);
    }
    
    .inner.three {
      right: 0%;
      bottom: 0%;
      animation: rotate-three 1s linear infinite;
      border-top: 3px solid rgb(29, 168, 29);
    }
    
    @keyframes rotate-one {
      0% {
        transform: rotateX(35deg) rotateY(-45deg) rotateZ(0deg);
      }
    
      100% {
        transform: rotateX(35deg) rotateY(-45deg) rotateZ(360deg);
      }
    }
    
    @keyframes rotate-two {
      0% {
        transform: rotateX(50deg) rotateY(10deg) rotateZ(0deg);
      }
    
      100% {
        transform: rotateX(50deg) rotateY(10deg) rotateZ(360deg);
      }
    }
    
    @keyframes rotate-three {
      0% {
        transform: rotateX(35deg) rotateY(55deg) rotateZ(0deg);
      }
    
      100% {
        transform: rotateX(35deg) rotateY(55deg) rotateZ(360deg);
      }
    }
    `
  ]
})
export class LoaderCustome {
}