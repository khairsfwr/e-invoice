import {Component} from "@angular/core";
import {randomString,cloneSimpleArray,log} from '@app/_helpers/function.general';
import {AccountService,AlertService} from '@app/_services';
import {first} from 'rxjs/operators';

@Component({selector: 'project-list',templateUrl: 'project-list.component.html',styleUrls: ['project-list.component.scss']})
export class ProjectList {
    loading: boolean=false;
    fetchList: any[]=[];
    cloneList: any[]=[];
    selectedList: string=''; // single selection
    selectedLists: any=[]; // multiple selection
    inputSearchList: string='';
    openFlag: boolean=false;

    constructor(
        private accountService: AccountService,
        private alertService: AlertService) {
    }

    /**@function set fetchList value */
    async fetchRequiredData() {
        this.loading=true;
        await new Promise((resolve,reject) => {
            this.accountService.getProjectCodes()
                .pipe(first())
                .subscribe({
                    next: (response) => {
                        this.fetchList=response.data;
                        // check fetchList data type before cloning - use for sorting, seaching etc
                        this.cloneList=cloneSimpleArray(this.fetchList);
                        this.loading=false;

                        // auto assign
                        if(this.fetchList.length===1){
                            this.accountService.setAccountProjectCode = this.fetchList[0]
                        }

                        resolve("done")
                    },
                    error: error => {
                        this.alertService.error(error);
                        this.loading=false;

                        reject(error)
                    }
                });
        });

    }

    filterList() {
    }

    changeFunction(ev: Event) {
    }

    selectFunction(item: any) {
    }

    clickFunction(item: any) {
        if(!item) return;

        if(typeof item==='string') {
            this.selectedList=item;
            this.accountService.setAccountProjectCode=item;
        }
        else
            alert('Check item format');
    }

    /**@function is use for searching list */
    async onEnterSearchList() {
        this.alertService.clear('list');

        if(this.openFlag===false) {
            this.openFlag=true;
            await this.fetchRequiredData();
        }

        if(this.fetchList.length===0) {
           return this.alertService.info(`Not found any...`,{id: "list",autoClose: false})
        }

        if(typeof this.fetchList[0]==='string') {
            log(`::::::::::::find one `+this.fetchList.find(v => v===this.inputSearchList)); // find only one
            this.cloneList=this.fetchList.filter((v: string) => v.includes(this.inputSearchList));
            
            if(this.cloneList&&this.cloneList.length===0) {
                return this.alertService.info(`Not found any...`,{id: "list",autoClose: false})
            }
        } else
            alert('Check item format');

        log(this.cloneList)

    }


}