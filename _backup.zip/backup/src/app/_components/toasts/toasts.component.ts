import {Component,OnInit} from '@angular/core';
import { Toast } from 'bootstrap';

@Component({
  selector: 'app-toasts',
  templateUrl: './toasts.component.html',
  styleUrls: ['./toasts.component.scss']
})
export class ToastsComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {
    const toastTrigger=document.getElementById('liveToastBtn')
    const toastLiveExample=document.getElementById('liveToast') as Element
    if(toastTrigger) {
      toastTrigger.addEventListener('click',() => {
        const toast=new Toast(toastLiveExample)

        toast.show()
      })
    }
  }

}
