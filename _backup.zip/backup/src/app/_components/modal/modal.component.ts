import {Component,TemplateRef,Input,ViewChild, Output, EventEmitter} from '@angular/core';
import {BsModalRef,BsModalService,ModalDirective} from 'ngx-bootstrap/modal';
import {Subscription} from 'rxjs';
import {Router} from '@angular/router';
import {ModalService} from '@app/_services/modal.service';
import {ToastrService} from 'ngx-toastr';
import {CommonService,setupService} from '@app/_services';

export class Modal {
  id!: string;
  size!: ModalSize;
  type!: ModalType;
  data!: {header: any,body: any};
  message!: string;
  autoClose!: boolean;
  fade!: boolean;
  cssClasses?: string;

  constructor(init?: Partial<Modal>) {
    Object.assign(this,init);
  }
}
export enum ModalId {
  Default='default-modal',
  Simple='simple-modal',
  Developer='developer-modal',
  Session='session-modal',
  Supplier='supplier-modal'
}

export enum ModalType {
  // General
  Static='staticModal'
}

export enum ModalSize {
  Small,
  Medium,
  Large,
  XtraLarge
}

@Component({
  selector: 'modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent {
  @Input() id=ModalId.Default;
  // @Input() type=ModalType.Default;

  @ViewChild(`${ModalType.Static}`,{static: false}) developer?: ModalDirective;
  @ViewChild(`${ModalType.Static}`,{static: false}) simple?: ModalDirective;
  @ViewChild(`${ModalType.Static}`,{static: false}) supplier?: ModalDirective;

  modals: Modal[]=[];
  modal!: Modal;
  modalSubscription!: Subscription;
  data: {header: any,body: any}={header: "This is header modal",body: 'This is body modal'}

  /** Start of modal ngx-bootstrap variable and method **/
  public modalRef?: BsModalRef;
  constructor(private router: Router,private modalService: ModalService,private bsModalService: BsModalService,private toastr: ToastrService, private common: CommonService, private setup: setupService) {}

  ngOnInit() {
    // subscribe to new modal 
    this.modalSubscription=this.modalService.onModal(this.id)
      .subscribe((modal: Modal) => {

        this.data = modal.data;

        // open child modals on condition
        this.openChildModal(modal);
      });
  }

  ngOnDestroy() {
    // unsubscribe to avoid memory leaks
    this.modalSubscription.unsubscribe();
  }

  openChildModal(modal: Modal) {
    if(!modal) return;
    this.modal=modal; //css
    this.simple&&modal.id===ModalId.Simple? this.simple.show()
      :this.developer&&modal.id===ModalId.Developer? this.developer.show()
        :this.supplier&&modal.id===ModalId.Supplier? this.supplier.show()
          : alert('Not configure view child yet!');

  }

  cssClasses(modal: Modal) {
    if(!modal) return;

    const classes=['modal-dialog','modal-dialog-centered','modal-dialog-scrollable'];
    /*const modalTypeClass = {
        [ModalType.Success]: '',
        [ModalType.Error]: '',
        [ModalType.Info]: '',
        [ModalType.Warning]: ''
    }*/
    const modalSizeClass={
      [ModalSize.Small]: 'modal-sm',
      [ModalSize.Medium]: 'modal-md',
      [ModalSize.Large]: 'modal-lg',
      [ModalSize.XtraLarge]: 'modal-xl'
    }
    /*classes.push(modalTypeClass[modal.type]);*/
    classes.push(modalSizeClass[modal.size]);

    return classes.join(' ');
  }

  /** End of modal ngx-bootstrap variable and method **/
  

  /****************************************** Supplier Method ******************************************/
 @Output() supplierDataata = new EventEmitter();
 @Input() allSupplierList:any[] = []
 @Input() copyOfAllSupplierList:any[] = []
 @Input() q!:number
 sample!:boolean;
 match:any;
 supplierCode:any;
 supplierName:any;
 supplierWatchListCheckbox:boolean = false;
 selectedSuppliers: any[] = [];
 checkList:any[] = [];
 saveButton: boolean = true;
 allSuppliersApiCalled:boolean = false;
 allSupplierListStorage:any[] = [];
 supplierWatchList:any[]=[];
 characters:any[]=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
 getSupplierObject() {
     return {
       "addressBooksCode": '',
       "companyName": ''
     }
 }
 resetSupplierSearchValues(){
   this.match = null;
   this.supplierCode = null;
   this.supplierName = null;
 }
 onSelectedCheckbox(item:any, event:any, index:any){
   console.log('selected supplier object:::::', item);
   console.log('selected checkbox event:::::', event);
   let obj = this.getSupplierObject();
   obj["addressBooksCode"] = item.addressBooksCode;
   obj["companyName"] = item.companyName;
   if(event.target.checked){
       console.log('entered into checked condition')
       this.selectedSuppliers.push(item);
       this.checkList[item.addressBooksCode] = true;
   }else{
       console.log('entered into un checked condition')
       this.checkList[item.addressBooksCode] = false;
       for(let i=0; i<this.selectedSuppliers.length; i++){
       if(this.selectedSuppliers[i].addressBooksCode === item.addressBooksCode)
           this.selectedSuppliers.splice(i--, 1);
       }
   }
   this.saveButton = (this.selectedSuppliers.length > 0) ? false : true;    
   console.log('supplier list::::::', this.selectedSuppliers);
}

 resetSelectedSuppliers(){
     this.q = 1;
     this.selectedSuppliers = [];
     this.checkList = [];
     this.saveButton = true;
 }

 filterStartsWith(letter:any){
     console.log('enetered into filterStartsWith method', letter)
     this.q = 1;
     this.allSupplierList = Array.from(this.copyOfAllSupplierList);
     this.allSupplierList = this.allSupplierList.filter(each => String(each.companyName).startsWith(letter))
     console.log('supplier list after filtered::::', this.allSupplierList)
 }

 searchSuppliers(){
   this.q = 1;
   if(this.match === null || this.match === '' || this.match === undefined){
     this.toastr.error('Please select match to search supplier')
   }else if(!this.supplierCode && !this.supplierName){
     this.allSupplierList = Array.from(this.copyOfAllSupplierList);
   }else if(this.supplierCode && this.supplierName){
     this.toastr.error('Please search with any one input')
   }else if(this.supplierCode && !this.supplierName){
     this.allSupplierList = Array.from(this.copyOfAllSupplierList);
     this.allSupplierList = (this.match === 'startsWith') ? this.allSupplierList.filter(each => String(each.addressBooksCode).startsWith(this.supplierCode)) :
                                   this.allSupplierList.filter(each => String(each.addressBooksCode).includes(this.supplierCode))
   }else if(!this.supplierCode && this.supplierName){
     this.allSupplierList = Array.from(this.copyOfAllSupplierList);
     this.allSupplierList = (this.match === 'startsWith') ? this.allSupplierList.filter(each => String(each.companyName).startsWith(this.supplierName)) :
                                   this.allSupplierList.filter(each => String(each.companyName).includes(this.supplierName))
   }
 }

 async saveSelectedSuppliers(){
   this.supplierWatchList=[];
   let count:number = 0;
   const response:any = await this.setup.getWatchlistCount();
   if(response.data){
     count = response.data.maxWatchListConfig;
   }
   for(let i=0; i<this.selectedSuppliers.length; i++){      
     if(this.supplierWatchList.length < count){
       this.supplierWatchList.push(this.selectedSuppliers[i]);
     }
   }
   this.supplierDataata.emit(this.supplierWatchList);
 }
  

}
