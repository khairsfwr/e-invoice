import {Component,OnInit,Input,Output,EventEmitter} from '@angular/core';
import {BehaviorSubject,Observable} from 'rxjs';

enum SortBy {
  Ascending='Ascending',
  Descending='Descending',
  InternalId='Internal Id',
  Status='Status'
}

interface INgModel {
  sortBy: ISortBy
}

interface ISortBy {
  main: string,
  child: string
}

@Component({
  selector: 'dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss','../share/share.scss']
})
export class DropdownComponent implements OnInit {
  @Input('id') id: string='default-dropdown';
  @Input('button') button: string='Click Here';
  @Input('mainList') mainList: any[]=[];
  @Output() outputSortBy = new EventEmitter<ISortBy>();
  @Output() outputRowDensity = new EventEmitter<string>();

  // private ngModelSubject: BehaviorSubject<INgModel>;
  // public ngModel: Observable<INgModel>
  // ngModel variable
  ngModelItems: INgModel;

  constructor() {
    // this.ngModelSubject=new BehaviorSubject<INgModel>({sortBy: {main: SortBy.InternalId,child: SortBy.Ascending}});
    // this.ngModel=this.ngModelSubject.asObservable();
    this.ngModelItems={sortBy: {main: SortBy.InternalId,child: SortBy.Ascending}}
  }

  ngOnInit(): void {
    // this.ngModel.subscribe(x => {
    // this.ngModelItems=x;
    // })
  }
  sortByNext() {
    // this.ngModelSubject.next()
  }
  setOutputSortBy(){
    this.outputSortBy.emit(this.ngModelItems.sortBy);
  }

  changeRowDensity(value:string):void {
    this.outputRowDensity.emit(value);
  }
}
