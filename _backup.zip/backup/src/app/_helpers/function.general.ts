//If you write your own code, remember hex color shortcuts (eg., #fff, #000)

export function hexToRgbA(hex: string) {
  let c: any;
  if(/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
    c=hex.substring(1).split('');
    if(c.length==3) {
      c=[c[0],c[0],c[1],c[1],c[2],c[2]];
    }
    c='0x'+c.join('');
    return 'rgba('+[(c>>16)&255,(c>>8)&255,c&255].join(',')+',1)';
  }
  throw new Error('Bad Hex');
}

hexToRgbA('#fbafff')

/*  returned value: (String)
rgba(251,175,255,1)
*/

export function randomString(length: number,chars: string|string[]) {
  var result='';
  for(var i=length;i>0;--i) result+=chars[Math.round(Math.random()*(chars.length-1))];
  return result;
}

randomString(8,'0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');


// If you do not use Dates, functions, undefined, Infinity, RegExps, Maps, Sets, Blobs, FileLists, 
// ImageDatas, sparse Arrays, Typed Arrays or other complex types within your object, a very simple one 
// liner to deep clone an object is: JSON.parse(JSON.stringify(object))

export function cloneSimpleObject(object: any) {
  return JSON.parse(JSON.stringify(object));
}

export function cloneSimpleArray(array: any) {
  // highest performance slice() or spread ...
  return [...array];
}

export function cloneDeepArrayOfObject(object: any) {
  // coming soon
}

export function log(value: any) {
  console.log(value);
}

export function wrapWithPromise(value:any){
   // in progress
  return new Promise((resolve,reject) => {
  });
}

export function debounce(func:Function, wait:number) {
  let timeout:any;
  return function executedFunction(...args: any[]) {
    const later = () => {
      timeout = null;
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};



