﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Data, CanLoad, Route, UrlSegment } from '@angular/router';

import { AccountService, CommonService } from '@app/_services';
import {LoggerService} from '@app/_services/logger.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate, CanLoad {
    constructor(
        private router: Router,
        private accountService: AccountService,
        private commonService:CommonService,
        private msg:LoggerService
    ) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        this.msg.log("auth.guard.ts canActivate()");
        const roles = (route.data as any).roles;

        const account = this.accountService.accountValue;
        if (account) {
            // check if route is restricted by role
            if (roles && !roles.includes(account.role)) {
                // role not authorized so redirect to home page
                this.router.navigate(['/']);
                return false;
            }

            // authorized so return true
            return true;
        }

        // not logged in so redirect to login page with the return url 
        this.router.navigate(['/security'], { queryParams: { returnUrl: state.url } });
        return false;
    }

    canLoad(route: Route, segments: UrlSegment[]){
        console.log(route);
        return true;
    }
}