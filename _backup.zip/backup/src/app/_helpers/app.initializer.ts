import { AccountService } from '@app/_services';

export function appInitializer(accountService: AccountService) {
    return () => new Promise(async resolve => {
        // attempt to refresh token on app start up to auto authenticate
        // accountService.refreshTokenTemp(sessionStorage.getItem('name') as string,sessionStorage.getItem('password')as string)
        if(!accountService.sessionId)return resolve('The user stil not login...');
        
        // await accountService.refreshTokenAndSetAccount().then(()=>{
        //     resolve('Refresh and Set Complete!');
        // });

        await accountService.refreshTokenAndSetAccountAsync().then(()=>{
            resolve('Refresh and Set Complete!');
        });
    });
}