import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AccountService, StorageService } from '@app/_services';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    constructor(private accountService: AccountService, private storage:StorageService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            if ([401, 403].includes(err.status) && this.accountService.accountValue) {
                // auto logout if 401 or 403 response returned from api
                this.accountService.logout();
            }
            this.expiredTokenDetect(err);
            this.changeErrorForUser(err);

            const error = (err && err.error && err.error.message) || (err && err.error && err.error.error_description) || err.statusText;
            
            return throwError(error);
        }))
    }

    changeErrorForUser(err:HttpErrorResponse){
        if(!(err && typeof err.error === 'object' && typeof err.error.error_description === 'string' && err.error.error_description === 'Bad credentials'))return;
        return err.error.error_description = 'Wrong username or password';
    }

    expiredTokenDetect(err:HttpErrorResponse){
        if(!(err && typeof err.error === 'object' && typeof err.error.error_description === 'string' && err.error.error_description === 'Invalid refresh token (expired)'))return;
        this.storage.clear();
        return; 
    }
}