// List of key use in the system for tracking purpose
export enum EKey {
  jwt = 'jwt', //access-token
  refresh_token = 'refresh_token',
  access_token = 'access_token',
  userKey = 'inv-user',
  loginUser = "loginUser",
  sessionId = "session-id",
  password = "password",
  userRole = "userRole",
  employeeId = "employeeId",
  email = "email",
  supplierInfo = "supplierInfo",
  userName = "userName"
}