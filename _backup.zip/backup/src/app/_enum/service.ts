// Enum on how the service data is return;

//  /login  //
export enum ELogin {

}

export interface IJwt {
  access_token:string
  refresh_token:string
}

// HTTP helpers
export enum EHTTP {
}

export enum EMIME {
  // format type/subtype;parameter=value
  application_octet_stream="application/octet-stream",
  application_json="application/json",
  text_plain="text/plain",
  text_css="text/css",
  text_html="text/html",
  text_javascript="text/javascript"
}